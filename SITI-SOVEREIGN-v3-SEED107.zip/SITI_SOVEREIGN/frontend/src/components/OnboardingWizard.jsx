/**
 * SITI Intelligence — CSV Onboarding Wizard
 * Step 1: Upload CSV for dry-run schema detection (POST /api/onboarding/detect-schema)
 * Step 2: Review column mapping with confidence score
 * Step 3: Confirm → triggers real upload (POST /api/kernel/upload)
 *
 * Zero impact on existing DataInjection flow — this is an opt-in wizard.
 */
import React, { useState, useCallback, useRef } from "react";
import axios from "axios";

const REQUIRED_COLS = ["Reached.on.Time_Y.N"];
const OPTIONAL_COLS = [
  "Warehouse_block", "Mode_of_Shipment", "Product_importance",
  "Cost_of_the_Product", "Customer_rating", "Customer_care_calls"
];

function StatusIcon({ status }) {
  if (status === "MAPPED")   return <span style={{ color: "#1ae87a" }}>✅</span>;
  if (status === "REQUIRED") return <span style={{ color: "#f0284a" }}>❌</span>;
  return                            <span style={{ color: "#4a5f82" }}>○</span>;
}

export default function OnboardingWizard({ apiBase, apiKey, onComplete, onClose }) {
  const [step, setStep]               = useState(1); // 1=upload, 2=review, 3=done
  const [schema, setSchema]           = useState(null);
  const [uploading, setUploading]     = useState(false);
  const [confirming, setConfirming]   = useState(false);
  const [error, setError]             = useState("");
  const [successMsg, setSuccessMsg]   = useState("");
  const fileRef                       = useRef(null);
  const [selectedFile, setSelectedFile] = useState(null);

  const api = useCallback((method, url, data, headers) =>
    axios({ method, url: `${apiBase}${url}`, data,
      headers: { "X-API-KEY": apiKey, ...headers } }), [apiBase, apiKey]);

  const handleFilePick = useCallback((e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setSelectedFile(file);
    setError("");
  }, []);

  const handleDetect = useCallback(async () => {
    if (!selectedFile) { setError("Pick a CSV file first"); return; }
    setUploading(true); setError("");
    try {
      const fd = new FormData();
      fd.append("file", selectedFile);
      const res = await api("post", "/onboarding/detect-schema", fd,
        { "Content-Type": "multipart/form-data" });
      setSchema({ ...res.data, _file: selectedFile });
      setStep(2);
    } catch (err) {
      setError(err.response?.data?.detail || err.message || "Detection failed");
    } finally {
      setUploading(false);
    }
  }, [selectedFile, api]);

  const handleConfirmUpload = useCallback(async () => {
    if (!schema?._file) return;
    setConfirming(true); setError("");
    try {
      const fd = new FormData();
      fd.append("file", schema._file);
      const res = await api("post", "/kernel/upload", fd,
        { "Content-Type": "multipart/form-data" });
      setSuccessMsg(
        `✅ GENIUS RESET COMPLETE — ${res.data.n_total?.toLocaleString()} records · ` +
        `ρ=${res.data.new_rho} · ρ_c=${res.data.new_critical_rho}`
      );
      setStep(3);
      if (onComplete) onComplete(res.data);
    } catch (err) {
      setError(err.response?.data?.detail || err.message || "Upload failed");
    } finally {
      setConfirming(false);
    }
  }, [schema, api, onComplete]);

  const confidencePct = schema ? Math.round((schema.confidence ?? 0) * 100) : 0;
  const confColor = confidencePct >= 80 ? "#1ae87a"
                  : confidencePct >= 50 ? "#e8a020" : "#f0284a";

  return (
    <div style={{
      position: "fixed", inset: 0, background: "#000000cc", zIndex: 999,
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 16,
    }}>
      <div className="siti-onboarding" style={{
        background: "#0c0f1e", border: "1px solid #1b2035",
        borderRadius: 8, fontFamily: "'JetBrains Mono', monospace",
        maxHeight: "90vh", overflowY: "auto",
        padding: 24, boxShadow: "0 0 60px #00000088",
      }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between",
          alignItems: "flex-start", marginBottom: 20 }}>
          <div>
            <div style={{ color: "#e8a020", fontWeight: 700, fontSize: 12,
              letterSpacing: "0.15em" }}>CSV ONBOARDING WIZARD</div>
            <div style={{ color: "#4a5f82", fontSize: 8, marginTop: 3,
              letterSpacing: "0.1em" }}>
              STEP {step} OF 3 · {step === 1 ? "UPLOAD" : step === 2 ? "REVIEW MAPPING" : "COMPLETE"}
            </div>
          </div>
          <button onClick={onClose} style={{
            background: "none", border: "1px solid #1b2035",
            color: "#4a5f82", cursor: "pointer", padding: "4px 10px",
            fontSize: 10, borderRadius: 3, fontFamily: "inherit",
          }}>✕</button>
        </div>

        {/* Progress bar */}
        <div style={{ background: "#141828", borderRadius: 2, height: 3,
          marginBottom: 20, overflow: "hidden" }}>
          <div style={{
            width: `${(step / 3) * 100}%`, height: "100%",
            background: "#e8a020", transition: "width 0.3s",
          }} />
        </div>

        {/* ── STEP 1: Pick file ──────────────────────────────────────────── */}
        {step === 1 && (
          <div>
            <div style={{ color: "#bfcce8", fontSize: 10, marginBottom: 16,
              lineHeight: 1.6 }}>
              Upload your CSV file for schema detection. SITI will auto-map your
              column names to the required format — no manual renaming needed.
            </div>

            <div style={{ marginBottom: 12 }}>
              <div style={{ color: "#4a5f82", fontSize: 8, letterSpacing: "0.1em",
                marginBottom: 6 }}>REQUIRED COLUMNS</div>
              {REQUIRED_COLS.map(c => (
                <div key={c} style={{ color: "#f0284a", fontSize: 9, marginBottom: 3 }}>
                  ⚡ {c}
                </div>
              ))}
            </div>
            <div style={{ marginBottom: 20 }}>
              <div style={{ color: "#4a5f82", fontSize: 8, letterSpacing: "0.1em",
                marginBottom: 6 }}>OPTIONAL (auto-detected)</div>
              {OPTIONAL_COLS.map(c => (
                <div key={c} style={{ color: "#4a5f82", fontSize: 9, marginBottom: 3 }}>
                  ○ {c}
                </div>
              ))}
            </div>

            <input type="file" accept=".csv" ref={fileRef}
              onChange={handleFilePick}
              style={{ display: "none" }} id="onboard-file-input" />
            <label htmlFor="onboard-file-input" style={{
              display: "block", width: "100%", boxSizing: "border-box",
              background: "#080d1a", border: "1px dashed #1b2035",
              borderRadius: 4, padding: "16px", textAlign: "center",
              cursor: "pointer", color: "#4a5f82", fontSize: 10,
              letterSpacing: "0.1em", marginBottom: 12,
              transition: "border-color 0.2s, color 0.2s",
            }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = "#e8a020";
                e.currentTarget.style.color = "#e8a020"; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = "#1b2035";
                e.currentTarget.style.color = "#4a5f82"; }}>
              {selectedFile ? `📄 ${selectedFile.name} (${(selectedFile.size/1024).toFixed(0)}KB)` : "📂 CLICK TO SELECT CSV"}
            </label>

            {error && <div style={{ color: "#f0284a", fontSize: 9, marginBottom: 10 }}>⛔ {error}</div>}

            <button onClick={handleDetect} disabled={!selectedFile || uploading}
              style={{
                width: "100%", padding: "10px",
                background: !selectedFile ? "#141828" : "#e8a020",
                border: "none", borderRadius: 4, cursor: !selectedFile ? "not-allowed" : "pointer",
                color: !selectedFile ? "#4a5f82" : "#06070d",
                fontFamily: "inherit", fontWeight: 700, fontSize: 11,
                letterSpacing: "0.12em",
              }}>
              {uploading ? "ANALYSING SCHEMA..." : "DETECT COLUMNS →"}
            </button>
          </div>
        )}

        {/* ── STEP 2: Review mapping ─────────────────────────────────────── */}
        {step === 2 && schema && (
          <div>
            <div style={{ display: "flex", gap: 12, marginBottom: 16,
              flexWrap: "wrap" }}>
              {[
                { label: "ROWS",       value: schema.rows?.toLocaleString() },
                { label: "MAPPED",     value: `${schema.mapped_count}/${REQUIRED_COLS.length + OPTIONAL_COLS.length}` },
                { label: "CONFIDENCE", value: `${confidencePct}%`, color: confColor },
                { label: "STATUS",     value: schema.can_upload ? "READY" : "BLOCKED",
                  color: schema.can_upload ? "#1ae87a" : "#f0284a" },
              ].map(({ label, value, color }) => (
                <div key={label} style={{ background: "#141828", borderRadius: 4,
                  padding: "8px 12px", flex: "1", minWidth: 70, textAlign: "center" }}>
                  <div style={{ color: "#4a5f82", fontSize: 7, letterSpacing: "0.1em" }}>{label}</div>
                  <div style={{ color: color || "#bfcce8", fontWeight: 700, fontSize: 13,
                    marginTop: 2 }}>{value}</div>
                </div>
              ))}
            </div>

            <div style={{ color: schema.can_upload ? "#1ae87a" : "#f0284a",
              fontSize: 9, marginBottom: 14, letterSpacing: "0.08em" }}>
              {schema.message}
            </div>

            {/* Column mapping table */}
            <div style={{ background: "#080d1a", borderRadius: 4, padding: 12,
              marginBottom: 16, maxHeight: 240, overflowY: "auto" }}>
              <div style={{ color: "#4a5f82", fontSize: 8, letterSpacing: "0.1em",
                marginBottom: 8 }}>COLUMN MAPPING</div>
              {schema.column_mapping?.map((row, i) => (
                <div key={i} className="column-mapping-row" style={{
                  display: "flex", gap: 8, marginBottom: 4, alignItems: "center",
                  padding: "3px 0", borderBottom: "1px solid #141828",
                }}>
                  <StatusIcon status={row.status} />
                  <span style={{ color: "#4a5f82", fontSize: 8, flex: 1,
                    fontFamily: "inherit" }}>{row.original}</span>
                  <span style={{ color: "#4a5f82", fontSize: 8 }}>→</span>
                  <span style={{
                    color: row.mapped_to ? "#bfcce8" : "#2a3550",
                    fontSize: 8, flex: 1,
                  }}>{row.mapped_to || "—unmapped—"}</span>
                </div>
              ))}
            </div>

            {schema.missing_required?.length > 0 && (
              <div style={{ background: "#1a0505", border: "1px solid #f0284a40",
                borderRadius: 4, padding: 10, marginBottom: 12 }}>
                <div style={{ color: "#f0284a", fontSize: 8, fontWeight: 700,
                  marginBottom: 4 }}>MISSING REQUIRED COLUMNS</div>
                {schema.missing_required.map(c => (
                  <div key={c} style={{ color: "#f0284a80", fontSize: 8 }}>• {c}</div>
                ))}
                <div style={{ color: "#4a5f82", fontSize: 7, marginTop: 6 }}>
                  Rename your column to one of the recognised aliases and re-upload.
                </div>
              </div>
            )}

            {error && <div style={{ color: "#f0284a", fontSize: 9, marginBottom: 10 }}>⛔ {error}</div>}

            <div style={{ display: "flex", gap: 8 }}>
              <button onClick={() => { setStep(1); setSchema(null); setError(""); }}
                style={{
                  flex: 1, padding: "9px",
                  background: "none", border: "1px solid #1b2035",
                  borderRadius: 4, color: "#4a5f82", cursor: "pointer",
                  fontFamily: "inherit", fontSize: 10, letterSpacing: "0.1em",
                }}>
                ← BACK
              </button>
              <button onClick={handleConfirmUpload}
                disabled={!schema.can_upload || confirming}
                style={{
                  flex: 2, padding: "9px",
                  background: !schema.can_upload ? "#141828" : "#1ae87a",
                  border: "none", borderRadius: 4,
                  cursor: !schema.can_upload ? "not-allowed" : "pointer",
                  color: !schema.can_upload ? "#4a5f82" : "#06070d",
                  fontFamily: "inherit", fontWeight: 700, fontSize: 10,
                  letterSpacing: "0.1em",
                }}>
                {confirming ? "LOADING INTO MIMI KERNEL..." : "CONFIRM UPLOAD →"}
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 3: Done ──────────────────────────────────────────────── */}
        {step === 3 && (
          <div style={{ textAlign: "center", padding: "20px 0" }}>
            <div style={{ fontSize: 36, marginBottom: 12 }}>✅</div>
            <div style={{ color: "#1ae87a", fontWeight: 700, fontSize: 13,
              letterSpacing: "0.12em", marginBottom: 8 }}>MIMI KERNEL LOADED</div>
            <div style={{ color: "#bfcce8", fontSize: 9, lineHeight: 1.8,
              marginBottom: 20 }}>{successMsg}</div>
            <button onClick={onClose} style={{
              padding: "10px 24px",
              background: "#e8a020", border: "none", borderRadius: 4,
              color: "#06070d", fontFamily: "inherit", fontWeight: 700,
              fontSize: 10, letterSpacing: "0.12em", cursor: "pointer",
            }}>
              OPEN DASHBOARD →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
