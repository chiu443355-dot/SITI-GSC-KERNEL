import React, { useState, useCallback, useRef, useMemo } from "react";
import axios from "axios";
import ExecutiveHUD from "./ExecutiveHUD";
import MIMIPanel from "./MIMIPanel";
import HubCharts from "./HubCharts";
import HubCard from "./HubCard";
import FailureTable from "./FailureTable";
import DataInjection from "./DataInjection";
import ApiDocsPanel from "./ApiDocsPanel";

/* ── Calibration Overlay ──────────────────────────────────────────────────── */
const KERNEL_LINES = Array.from({ length: 90 }, (_, i) => {
  const w1 = (Math.sin(i * 1.234 + 0.5) * 0.9).toFixed(7);
  const w2 = (Math.cos(i * 0.876 - 0.3) * 0.7).toFixed(7);
  const b  = (Math.sin(i * 2.345 + 1.1) * 0.1).toFixed(7);
  return `LR[${i % 10}][${(i * 3) % 7}] = ${w1}  |  BIAS: ${b}  |  ∇L = ${w2}`;
});
const KERNEL_LOOP = [...KERNEL_LINES, ...KERNEL_LINES];

function CalibrationOverlay() {
  return (
    <div data-testid="calibration-overlay"
      style={{ position: "fixed", inset: 0, background: "#000000",
        zIndex: 9999, display: "flex", alignItems: "center",
        justifyContent: "center", overflow: "hidden" }}>
      <div style={{ position: "absolute", inset: 0, opacity: 0.13, overflow: "hidden" }}>
        <div className="scroll-kernel-weights" style={{
          fontFamily: "JetBrains Mono", fontSize: 11, color: "#FFB340",
          lineHeight: 2.1, whiteSpace: "nowrap", padding: "0 32px" }}>
          {KERNEL_LOOP.map((line, i) => <div key={i}>{line}</div>)}
        </div>
      </div>
      <div style={{ textAlign: "center", zIndex: 1, padding: "0 32px" }}>
        <div style={{ display: "flex", justifyContent: "center", marginBottom: 28 }}>
          <svg width="52" height="52" viewBox="0 0 34 34" fill="none">
            <path d="M 24 7 C 30 7, 30 15, 17 17 C 4 19, 4 27, 10 27" stroke="#FFB340" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <circle cx="24" cy="7" r="2.8" fill="#FFB340" />
            <circle cx="10" cy="27" r="2.8" fill="#FFB340" opacity="0.7" />
          </svg>
        </div>
        <div className="calibrate-pulse-text" style={{
          color: "#FFB340", fontFamily: "Chivo, sans-serif", fontWeight: 900,
          fontSize: 22, letterSpacing: "0.28em", textTransform: "uppercase", marginBottom: 10 }}>
          MIMI INTELLIGENCE
        </div>
        <div style={{ color: "#FFB340", fontFamily: "JetBrains Mono", fontSize: 13,
          letterSpacing: "0.16em", marginBottom: 8, opacity: 0.9 }}>
          RE-CALIBRATING STATE OBSERVER...
        </div>
        <div style={{ width: 320, height: 2, background: "#1A1A1A", margin: "0 auto 14px", borderRadius: 1 }}>
          <div className="calibrate-progress-bar" style={{ height: "100%", background: "#FFB340", width: "0%", borderRadius: 1 }} />
        </div>
      </div>
    </div>
  );
}

/* ── Settings Gear Modal ──────────────────────────────────────────────────── */
function SettingsModal({ apiBase, apiKey, settings, onSaved, onClose }) {
  const [costPerFailure,   setCostPerFailure]   = useState(String(settings.cost_per_failure ?? 3.94));
  const [truckTransitCost, setTruckTransitCost] = useState(String(settings.truck_transit_cost ?? 1.20));
  const [webhookUrl,       setWebhookUrl]       = useState(String(settings.webhook_url ?? ""));
  const [saving,  setSaving]  = useState(false);
  const [saved,   setSaved]   = useState(false);
  const [error,   setError]   = useState("");

  const handleSave = async () => {
    const cpf = parseFloat(costPerFailure);
    const ttc = parseFloat(truckTransitCost);
    if (isNaN(cpf) || cpf <= 0) { setError("Cost per failure must be a positive number"); return; }
    if (isNaN(ttc) || ttc <= 0) { setError("Truck transit cost must be a positive number"); return; }
    setError(""); setSaving(true);
    try {
      const res = await axios.post(`${apiBase}/settings`,
        { cost_per_failure: cpf, truck_transit_cost: ttc, webhook_url: webhookUrl.trim() },
        { headers: { "X-API-KEY": apiKey } }
      );
      onSaved({ cost_per_failure: cpf, truck_transit_cost: ttc, webhook_url: webhookUrl.trim(), new_exposure: res.data.new_annualized_exposure });
      setSaved(true);
      setTimeout(() => { setSaved(false); onClose(); }, 900);
    } catch (e) {
      setError(e.response?.data?.detail || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={{
      position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)",
      zIndex: 10000, display: "flex", alignItems: "center", justifyContent: "center"
    }}>
      <div data-testid="settings-modal" style={{
        background: "#0D0D0D", border: "1px solid #FFB34066",
        width: 380, padding: "24px", fontFamily: "JetBrains Mono",
      }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
          <div>
            <div style={{ color: "#FFB340", fontWeight: 900, fontSize: 13, letterSpacing: "0.18em" }}>
              ⚙ COST CONFIGURATOR
            </div>
            <div style={{ color: "#555", fontSize: 9, letterSpacing: "0.12em", marginTop: 2 }}>
              ALL CALCULATIONS UPDATE IMMEDIATELY
            </div>
          </div>
          <button onClick={onClose} style={{
            background: "none", border: "1px solid #333", color: "#888",
            width: 28, height: 28, cursor: "pointer", fontSize: 14,
            display: "flex", alignItems: "center", justifyContent: "center",
          }}>✕</button>
        </div>

        {/* Cost per Failure */}
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 9, color: "#D4D4D8", letterSpacing: "0.12em", display: "block", marginBottom: 6 }}>
            COST PER DELIVERY FAILURE (₹)
          </label>
          <div style={{ fontSize: 9, color: "#555", marginBottom: 6 }}>
            Used in: Annualized Exposure · Revenue Saved · Leakage Total
          </div>
          <input
            type="number" value={costPerFailure} min="0.01" step="0.01"
            onChange={e => setCostPerFailure(e.target.value)}
            style={{
              width: "100%", background: "#111", border: "1px solid #333",
              color: "#FFB340", fontFamily: "JetBrains Mono", fontSize: 14,
              padding: "8px 10px", outline: "none", boxSizing: "border-box",
            }}
          />
          <div style={{ fontSize: 9, color: "#444", marginTop: 4 }}>
            Default: ₹3.94 (Wankhede 2026 §IV-C baseline)
          </div>
        </div>

        {/* Truck Transit Cost */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 9, color: "#D4D4D8", letterSpacing: "0.12em", display: "block", marginBottom: 6 }}>
            TRUCK TRANSIT COST PER UNIT (₹)
          </label>
          <div style={{ fontSize: 9, color: "#555", marginBottom: 6 }}>
            Used in: Recovery Value · Diversion Cost Estimate
          </div>
          <input
            type="number" value={truckTransitCost} min="0.01" step="0.01"
            onChange={e => setTruckTransitCost(e.target.value)}
            style={{
              width: "100%", background: "#111", border: "1px solid #333",
              color: "#64D2FF", fontFamily: "JetBrains Mono", fontSize: 14,
              padding: "8px 10px", outline: "none", boxSizing: "border-box",
            }}
          />
          <div style={{ fontSize: 9, color: "#444", marginTop: 4 }}>
            Default: ₹1.20 (recovery_value multiplier)
          </div>
        </div>

        {/* Webhook URL — MISSING 5 */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 9, color: "#D4D4D8", letterSpacing: "0.12em", display: "block", marginBottom: 6 }}>
            ALERT WEBHOOK URL (optional)
          </label>
          <div style={{ fontSize: 9, color: "#555", marginBottom: 6 }}>
            POST hub collapse alerts to your Slack / ERP / ops dashboard
          </div>
          <input
            type="text" value={webhookUrl} placeholder="https://hooks.slack.com/services/..."
            onChange={e => setWebhookUrl(e.target.value)}
            style={{
              width: "100%", background: "#111", border: "1px solid #333",
              color: "#FF9F0A", fontFamily: "JetBrains Mono", fontSize: 11,
              padding: "8px 10px", outline: "none", boxSizing: "border-box",
            }}
          />
          <div style={{ fontSize: 9, color: "#444", marginTop: 4 }}>
            Receives JSON: event, hub, rho, severity, timestamp, message
          </div>
        </div>

        {/* Preview */}
        <div style={{ background: "#0A0A0A", border: "1px solid #1A1A1A", padding: "10px", marginBottom: 16 }}>
          <div style={{ fontSize: 9, color: "#888", letterSpacing: "0.1em", marginBottom: 6 }}>LIVE PREVIEW</div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
            <div>
              <div style={{ fontSize: 8, color: "#555" }}>Cost × 10,000 failures/yr</div>
              <div style={{ fontSize: 14, color: "#39FF14", fontWeight: 700 }}>
                ₹{((parseFloat(costPerFailure) || 0) * 10000).toLocaleString("en-IN")}
              </div>
            </div>
            <div>
              <div style={{ fontSize: 8, color: "#555" }}>Truck divert × 1,000 units</div>
              <div style={{ fontSize: 14, color: "#64D2FF", fontWeight: 700 }}>
                ₹{((parseFloat(truckTransitCost) || 0) * 1000).toLocaleString("en-IN")}
              </div>
            </div>
          </div>
        </div>

        {error && (
          <div style={{ color: "#FF3B30", fontSize: 9, marginBottom: 10, letterSpacing: "0.08em" }}>
            ⚠ {error}
          </div>
        )}

        <button
          onClick={handleSave}
          disabled={saving || saved}
          data-testid="save-settings-btn"
          style={{
            width: "100%", padding: "10px",
            background: saved ? "#001A05" : saving ? "#1A1000" : "#FFB340",
            border: `1px solid ${saved ? "#32D74B" : "#FFB340"}`,
            color: saved ? "#32D74B" : saving ? "#FFB340" : "#000",
            fontFamily: "JetBrains Mono", fontWeight: 900, fontSize: 11,
            letterSpacing: "0.18em", cursor: saving || saved ? "default" : "pointer",
          }}>
          {saved ? "✓ SAVED — CALCULATIONS UPDATED" : saving ? "SAVING..." : "APPLY COST CONFIGURATION"}
        </button>
      </div>
    </div>
  );
}

/* ── CSV Export Button — MISSING 6 ───────────────────────────────────────── */
function CsvExportButton({ apiBase, apiKey }) {
  const [state, setState] = React.useState("idle");

  const handleExport = React.useCallback(async () => {
    setState("loading");
    try {
      const res = await axios.get(`${apiBase}/export/csv`, {
        headers:      { "X-API-KEY": apiKey },
        responseType: "blob",
      });
      const url  = URL.createObjectURL(new Blob([res.data], { type: "text/csv" }));
      const link = document.createElement("a");
      link.href     = url;
      link.download = `SITI_Analysis_${Date.now()}.csv`;
      link.click();
      URL.revokeObjectURL(url);
      setState("done");
      setTimeout(() => setState("idle"), 2000);
    } catch (e) {
      console.error("CSV export failed:", e);
      setState("error");
      setTimeout(() => setState("idle"), 3000);
    }
  }, [apiBase, apiKey]);

  return (
    <button onClick={handleExport} disabled={state === "loading"}
      title="Export analysis as CSV — open in Excel/Tableau"
      style={{
        background: "none",
        border: `1px solid ${state === "done" ? "#32D74B" : state === "error" ? "#FF3B30" : "#2A2A2A"}`,
        color: state === "done" ? "#32D74B" : state === "error" ? "#FF3B30" : "#555",
        height: 32, padding: "0 10px", cursor: state === "loading" ? "wait" : "pointer",
        fontSize: 9, borderRadius: 2, fontFamily: "JetBrains Mono",
        letterSpacing: "0.1em", whiteSpace: "nowrap",
        transition: "border-color 0.2s, color 0.2s",
      }}
      onMouseEnter={e => { if (state === "idle") { e.currentTarget.style.borderColor = "#32D74B"; e.currentTarget.style.color = "#32D74B"; } }}
      onMouseLeave={e => { if (state === "idle") { e.currentTarget.style.borderColor = "#2A2A2A"; e.currentTarget.style.color = "#555"; } }}>
      {state === "loading" ? "..." : state === "done" ? "✓ SAVED" : state === "error" ? "⛔ ERR" : "⬇ CSV"}
    </button>
  );
}


/* ── Email Report Button ──────────────────────────────────────────────────── */
function EmailReportButton({ apiBase, apiKey, kState }) {
  const [state, setState] = React.useState("idle"); // idle|loading|done|error
  const [email, setEmail] = React.useState("");
  const [showForm, setShowForm] = React.useState(false);
  const [msg, setMsg]     = React.useState("");

  const send = React.useCallback(async () => {
    if (!email.trim()) return;
    setState("loading");
    try {
      const res = await axios.post(`${apiBase}/report/email`,
        { recipient_email: email.trim(),
          tenant_label: kState?.dataset_name || "SITI Client" },
        { headers: { "X-API-KEY": apiKey } }
      );
      if (res.data.sent) {
        setMsg(`✅ Report sent to ${res.data.to}`);
      } else if (res.data.pdf_base64) {
        // No email configured — trigger browser download
        const link = document.createElement("a");
        link.href = `data:application/pdf;base64,${res.data.pdf_base64}`;
        link.download = `SITI_Report_${Date.now()}.pdf`;
        link.click();
        setMsg("✅ PDF downloaded (no email configured)");
      }
      setState("done");
      setTimeout(() => { setState("idle"); setShowForm(false); setMsg(""); }, 3000);
    } catch (e) {
      setMsg(`⛔ ${e.response?.data?.detail || e.message}`);
      setState("error");
      setTimeout(() => setState("idle"), 4000);
    }
  }, [email, apiBase, apiKey, kState]);

  if (!showForm) {
    return (
      <button onClick={() => setShowForm(true)}
        title="Email forensic report as PDF"
        style={{
          background: "none", border: "1px solid #2A2A2A",
          color: "#555", height: 32, padding: "0 10px", cursor: "pointer",
          fontSize: 9, borderRadius: 2, fontFamily: "JetBrains Mono",
          letterSpacing: "0.1em", whiteSpace: "nowrap",
          transition: "border-color 0.2s, color 0.2s",
        }}
        onMouseEnter={e => { e.currentTarget.style.borderColor = "#32D74B"; e.currentTarget.style.color = "#32D74B"; }}
        onMouseLeave={e => { e.currentTarget.style.borderColor = "#2A2A2A"; e.currentTarget.style.color = "#555"; }}>
        📧 REPORT
      </button>
    );
  }

  return (
    <div style={{ display: "flex", gap: 4, alignItems: "center" }}>
      <input value={email} onChange={e => setEmail(e.target.value)}
        placeholder="coo@company.com"
        onKeyDown={e => e.key === "Enter" && send()}
        style={{
          background: "#0A0A0A", border: "1px solid #2A2A2A",
          color: "#bfcce8", fontSize: 9, padding: "0 8px",
          height: 30, width: 160, borderRadius: 2,
          fontFamily: "JetBrains Mono", outline: "none",
        }} />
      <button onClick={send} disabled={state === "loading"}
        style={{
          background: state === "loading" ? "#141414" : "#32D74B20",
          border: `1px solid ${state === "done" ? "#32D74B" : state === "error" ? "#FF3B30" : "#32D74B"}`,
          color: state === "done" ? "#32D74B" : state === "error" ? "#FF3B30" : "#32D74B",
          height: 30, padding: "0 10px", cursor: "pointer",
          fontSize: 9, borderRadius: 2, fontFamily: "JetBrains Mono",
          letterSpacing: "0.1em",
        }}>
        {state === "loading" ? "..." : state === "done" ? "✓" : "SEND"}
      </button>
      <button onClick={() => setShowForm(false)} style={{
        background: "none", border: "none", color: "#555",
        cursor: "pointer", fontSize: 14, padding: "0 4px",
      }}>✕</button>
      {msg && <span style={{ fontSize: 8, color: state === "error" ? "#FF3B30" : "#32D74B",
        maxWidth: 140, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{msg}</span>}
    </div>
  );
}


/* ── Commander's Console ──────────────────────────────────────────────────── */
function CommanderConsole({ kState, apiBase, apiKey, settings }) {
  const msg      = kState?.commander_message ?? "";
  const level    = kState?.commander_level ?? "stable";
  const rho_t3   = kState?.rho_t3 ?? 0;
  const pvi      = kState?.pvi ?? 0;
  const pviAlert = kState?.pvi_alert ?? false;
  const cascade  = kState?.cascade_events ?? [];
  const hubs     = kState?.hubs ?? [];
  const alert    = kState?.alert;

  // Decision state per alert
  const [decision, setDecision]   = useState(null);   // "APPROVED" | "DISMISSED" | null
  const [deciding, setDeciding]   = useState(false);
  const [decisionMsg, setDecisionMsg] = useState("");

  // PDF generation state
  const [generating, setGenerating] = useState(false);
  const [pdfReady,   setPdfReady]   = useState(false);
  const pdfRef = useRef(null);

  const colorMap = { critical: "#FF3B30", efficiency: "#64D2FF", stable: "#32D74B" };
  const bgMap    = { critical: "#1A0000", efficiency: "#00101A", stable: "#001A05" };
  const labelMap = { critical: "CRITICAL", efficiency: "UNDER-UTILIZED", stable: "NOMINAL" };
  const statusColor = colorMap[level] ?? "#32D74B";
  const bgColor     = bgMap[level] ?? "#001A05";

  // Build directive text from live kernel state
  const buildDirective = useCallback(() => {
    const costPer = settings?.cost_per_failure ?? 3.94;
    const critHub = hubs.length > 0
      ? hubs.reduce((a, b) => a.rho > b.rho ? a : b)
      : null;
    const srcHub   = critHub?.name ?? "Alpha";
    const srcBlocks = critHub?.blocks?.join(", ") ?? "A, B";
    const rhoDot   = critHub?.kalman?.rho_dot ?? 0;

    let destHub = "Gamma";
    if (cascade.length > 0) {
      destHub = cascade[0].to_hub;
    } else {
      const lowestRho = hubs.reduce((a, b) => (a.rho < b.rho ? a : b), hubs[0]);
      if (lowestRho) destHub = lowestRho.name;
    }

    const divUnits   = kState?.diverted_units ?? 0;
    const savings    = (divUnits * costPer).toFixed(0);
    const velocityStr = rhoDot >= 0 ? `+${rhoDot.toFixed(4)}` : rhoDot.toFixed(4);

    const reason = cascade.length > 0
      ? `Cascade Overflow from ${srcHub}`
      : Math.abs(rhoDot) > 0.001
        ? `Velocity Spike (${velocityStr} ρ/hr)`
        : `ρ Threshold Breach (${(critHub?.rho ?? 0).toFixed(4)} > ${kState?.critical_rho ?? 0.85})`;

    const irp = kState?.inverse_reliability;
    const hiImpUnits = irp ? Math.round(irp.failure_count * 0.4) : 42;

    return {
      srcHub, srcBlocks, destHub, divUnits, savings, reason,
      hiImpUnits, rhoDot: velocityStr, rho: critHub?.rho ?? 0,
      timestamp: new Date().toISOString(),
      dataset: kState?.dataset_name ?? "SAFEXPRESS_CASE_02028317",
    };
  }, [kState, hubs, cascade, settings]);

  const handleGeneratePDF = useCallback(async () => {
    setGenerating(true);
    try {
      const d = buildDirective();
      const now = new Date();
      const dateStr = now.toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"numeric" });
      const timeStr = now.toLocaleTimeString("en-IN", { hour12: false });

      // Use jsPDF from window (loaded via CDN) or dynamic import
      const { jsPDF } = await import("jspdf");
      const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });

      const W = 210;
      let y = 18;

      // ── Header bar
      doc.setFillColor(10, 10, 10);
      doc.rect(0, 0, W, 22, "F");
      doc.setTextColor(255, 179, 64);
      doc.setFont("helvetica", "bold");
      doc.setFontSize(13);
      doc.text("SITI INTELLIGENCE — OPERATIONAL DIRECTIVE", 14, 13);
      doc.setFontSize(8);
      doc.setTextColor(120, 120, 120);
      doc.text(`MIMI Kernel v2.1 · Case #02028317 · ${dateStr} ${timeStr}`, 14, 19);

      y = 32;

      // ── Status banner
      const isUrgent = (kState?.catastrophe || kState?.collapse);
      doc.setFillColor(isUrgent ? 50 : 0, isUrgent ? 0 : 26, 0);
      doc.setDrawColor(isUrgent ? 255 : 50, isUrgent ? 59 : 215, isUrgent ? 48 : 75);
      doc.rect(14, y - 5, W - 28, 12, "FD");
      doc.setTextColor(isUrgent ? 255 : 50, isUrgent ? 59 : 215, isUrgent ? 48 : 75);
      doc.setFontSize(10);
      doc.setFont("helvetica", "bold");
      doc.text(
        isUrgent ? "⚠  URGENT ACTION REQUIRED — NETWORK SATURATION DETECTED"
                 : "✓  ROUTINE DIVERSION DIRECTIVE — PREVENTIVE ACTION",
        16, y + 2
      );
      y += 16;

      // ── Section: THE ACTION
      doc.setTextColor(255, 179, 64);
      doc.setFontSize(9);
      doc.setFont("helvetica", "bold");
      doc.text("THE ACTION", 14, y); y += 6;

      doc.setFillColor(15, 15, 15);
      doc.rect(14, y - 4, W - 28, 22, "F");

      doc.setTextColor(220, 220, 220);
      doc.setFontSize(12);
      doc.setFont("helvetica", "bold");
      const actionText = `Divert ${d.hiImpUnits} High-Importance units from ${d.srcHub} (Blocks ${d.srcBlocks})`;
      doc.text(actionText, 16, y + 4);
      doc.setFontSize(12);
      doc.setTextColor(100, 210, 255);
      doc.text(`→  to ${d.destHub} Hub`, 16, y + 12);
      y += 28;

      // ── 3-col metrics
      const metrics = [
        { label: "REASON", value: d.reason, color: [255, 179, 64] },
        { label: "ρ AT TRIGGER", value: `${d.rho.toFixed(4)}  (threshold: ${kState?.critical_rho ?? 0.85})`, color: [255, 59, 48] },
        { label: "T+3 FORECAST", value: `ρ = ${rho_t3.toFixed(4)}  (45-min horizon)`, color: rho_t3 >= 0.85 ? [255,59,48] : [50,215,75] },
        { label: "PREDICTED SAVINGS", value: `₹${parseInt(d.savings).toLocaleString("en-IN")}`, color: [57, 255, 20] },
        { label: "UNITS TO DIVERT", value: `${d.hiImpUnits} high-importance shipments`, color: [220, 220, 220] },
        { label: "DIVERSION WINDOW", value: "Execute within T-45 minutes", color: [255, 159, 10] },
      ];

      metrics.forEach((m, i) => {
        const col = i % 2 === 0 ? 14 : W / 2 + 4;
        const row = Math.floor(i / 2);
        const ry  = y + row * 18;
        doc.setFillColor(12, 12, 12);
        doc.rect(col, ry - 4, W / 2 - 8, 15, "F");
        doc.setTextColor(100, 100, 100);
        doc.setFontSize(7);
        doc.setFont("helvetica", "normal");
        doc.text(m.label, col + 3, ry + 1);
        doc.setTextColor(...m.color);
        doc.setFontSize(9);
        doc.setFont("helvetica", "bold");
        doc.text(m.value, col + 3, ry + 8);
      });
      y += Math.ceil(metrics.length / 2) * 18 + 10;

      // ── Kalman state
      doc.setTextColor(255, 179, 64);
      doc.setFontSize(9);
      doc.setFont("helvetica", "bold");
      doc.text("KALMAN STATE VECTOR", 14, y); y += 6;
      doc.setFillColor(10, 10, 10);
      doc.rect(14, y - 3, W - 28, 20, "F");
      doc.setTextColor(100, 210, 255);
      doc.setFontSize(8);
      doc.setFont("courier", "normal");
      const k = kState?.kalman ?? {};
      doc.text(`x̂ = [ρ=${k.x_hat?.toFixed(4) ?? "—"}, ρ̇=${k.rho_dot?.toFixed(6) ?? "—"}]   T+1=${k.rho_t1?.toFixed(4) ?? "—"}   T+3=${k.rho_t3?.toFixed(4) ?? "—"}`, 17, y + 5);
      doc.text(`P(trace)=${k.P?.toFixed(6) ?? "—"}   K=[${k.K?.[0]?.toFixed(4) ?? "—"}, ${k.K?.[1]?.toFixed(4) ?? "—"}]   PVI=${pvi.toFixed(1)}%`, 17, y + 13);
      y += 28;

      // ── Dataset info
      doc.setTextColor(255, 179, 64);
      doc.setFontSize(9);
      doc.setFont("helvetica", "bold");
      doc.text("DATA SOURCE", 14, y); y += 6;
      doc.setFillColor(10, 10, 10);
      doc.rect(14, y - 3, W - 28, 16, "F");
      doc.setTextColor(160, 160, 160);
      doc.setFontSize(8);
      doc.setFont("helvetica", "normal");
      doc.text(`Dataset: ${d.dataset}   |   Shipments analyzed: ${kState?.n_total?.toLocaleString() ?? "—"}`, 17, y + 4);
      doc.text(`Cost per failure: ₹${settings?.cost_per_failure ?? 3.94}   |   Method: Wankhede (2026) §IV-C, Eq. (7)`, 17, y + 11);
      y += 24;

      // ── Approval section
      doc.setFillColor(8, 8, 8);
      doc.setDrawColor(80, 80, 80);
      doc.rect(14, y, W - 28, 28, "FD");
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(8);
      doc.text("HUMAN APPROVAL", 17, y + 7);
      doc.setTextColor(200, 200, 200);
      doc.setFontSize(9);
      doc.text("Approved by: ____________________________", 17, y + 16);
      doc.text("Timestamp: ____________________________", 105, y + 16);
      doc.text("Decision: [ ] APPROVE    [ ] DISMISS    [ ] ESCALATE", 17, y + 24);
      y += 38;

      // ── Footer
      doc.setDrawColor(30, 30, 30);
      doc.line(14, y, W - 14, y);
      y += 5;
      doc.setTextColor(60, 60, 60);
      doc.setFontSize(7);
      doc.text("SITI Intelligence · MIMI Kernel v3.0 Diamond · Traceable to Wankhede (2026) IEEE · Case #02028317", 14, y);
      doc.text(`Generated: ${d.timestamp}`, W - 14, y, { align: "right" });
      y += 5;
      // DIAMOND PROTOCOL 5: Operator ID + MongoDB reference hash in every PDF
      const mongoRef = pdfRef.current?.mongoRef || "PENDING-APPROVAL";
      const operatorId = pdfRef.current?.operatorId || "ops-dashboard";
      doc.setTextColor(80, 80, 80);
      doc.text(`Operator: ${operatorId}  ·  MongoDB Ref: ${mongoRef}`, 14, y);

      // ── Save
      const filename = `SITI_Directive_${d.srcHub}_${now.toISOString().slice(0,10)}.pdf`;
      doc.save(filename);
      pdfRef.current = { filename, directive: d };
      setPdfReady(true);
      setTimeout(() => setPdfReady(false), 3000);
    } catch (err) {
      console.error("PDF generation failed:", err);
    } finally {
      setGenerating(false);
    }
  }, [buildDirective, kState, pvi, rho_t3, settings]);

  // Human decision handler
  const handleDecision = useCallback(async (action) => {
    if (!alert?.sent && action === "APPROVED") return;
    setDeciding(true);
    const d = buildDirective();
    const directiveText = `Divert ${d.hiImpUnits} high-importance units from ${d.srcHub} to ${d.destHub}. Reason: ${d.reason}. Savings: ₹${d.savings}`;
    try {
      const resp = await axios.post(`${apiBase}/decisions/log`, {
        hub:        alert?.hub ?? d.srcHub,
        rho:        alert?.rho ?? d.rho,
        action:     action,
        directive:  directiveText,
        operator_id: "ops-dashboard",
      }, { headers: { "X-API-KEY": apiKey } });
      setDecision(action);
      const mongoRef = resp.data?.record_id || "logged";
      pdfRef.current = { ...pdfRef.current, mongoRef, operatorId: "ops-dashboard" };
      setDecisionMsg(action === "APPROVED"
        ? `✓ DIVERSION APPROVED — Decision logged to MongoDB at ${new Date().toLocaleTimeString()}`
        : `✕ DISMISSED — No action taken. Logged at ${new Date().toLocaleTimeString()}`
      );
    } catch (err) {
      setDecisionMsg("⚠ Could not log decision — check API connection");
    } finally {
      setDeciding(false);
    }
  }, [alert, buildDirective, apiBase, apiKey]);

  return (
    <div data-testid="commander-console"
      style={{ background: "#0A0A0A", border: `1px solid ${statusColor}55`, padding: "12px" }}>

      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
        <div style={{ fontSize: 9, color: "#D4D4D8", letterSpacing: "0.14em", textTransform: "uppercase" }}>
          COMMANDER'S CONSOLE
        </div>
        <div style={{ fontSize: 8, color: statusColor, fontWeight: 700, letterSpacing: "0.1em" }}>
          {labelMap[level] ?? "ACTIVE"}
        </div>
      </div>

      {/* PVI alert */}
      {pviAlert && (
        <div data-testid="pvi-alert" className="blink-critical"
          style={{ fontSize: 8, color: "#FF3B30", letterSpacing: "0.1em", marginBottom: 6,
            padding: "3px 8px", background: "#200000", border: "1px solid #FF3B3066" }}>
          PVI = {pvi.toFixed(1)}% — VOLATILITY &gt; 15% THRESHOLD
        </div>
      )}

      {/* Message */}
      <div style={{ background: bgColor, border: `1px solid ${statusColor}33`, padding: "9px 10px", marginBottom: 8 }}>
        {msg.split("\n").map((line, i) => (
          <div key={i} style={{
            fontSize: 9.5, color: statusColor, fontFamily: "JetBrains Mono",
            fontWeight: 700, letterSpacing: "0.08em", lineHeight: 1.9 }}>
            {line}
          </div>
        ))}
      </div>

      {/* Cascade events */}
      {cascade.length > 0 && (
        <div style={{ marginBottom: 8 }}>
          {cascade.map((ev, i) => (
            <div key={i} style={{
              fontSize: 8, color: "#FFD60A", letterSpacing: "0.08em",
              padding: "3px 8px", background: "#1A1500", border: "1px solid #FFD60A33",
              marginBottom: 2 }}>
              {ev.from_hub} → {ev.to_hub}: {ev.excess_lambda} units/hr diverted
            </div>
          ))}
        </div>
      )}

      {/* Projections */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6, marginBottom: 8 }}>
        <div style={{ background: "#111", padding: "5px 8px", border: "1px solid #1A1A1A" }}>
          <div style={{ fontSize: 8, color: "#888", letterSpacing: "0.08em" }}>T+3 PROJ (45-MIN)</div>
          <div style={{ fontSize: 13, color: rho_t3 >= 0.85 ? "#FF3B30" : "#39FF14",
            fontWeight: 700, fontFamily: "JetBrains Mono" }}>
            ρ={rho_t3.toFixed(4)}
          </div>
        </div>
        <div style={{ background: "#111", padding: "5px 8px", border: "1px solid #1A1A1A" }}>
          <div style={{ fontSize: 8, color: "#888", letterSpacing: "0.08em" }}>PVI (VOLATILITY)</div>
          <div style={{ fontSize: 13,
            color: pvi > 15 ? "#FF3B30" : pvi > 8 ? "#FFB340" : "#32D74B",
            fontWeight: 700, fontFamily: "JetBrains Mono" }}>
            {pvi.toFixed(1)}%
          </div>
        </div>
      </div>

      {/* ── HUMAN-IN-THE-LOOP: Alert + Approve/Dismiss ── */}
      {alert?.sent && (
        <div data-testid="alert-sent-badge"
          style={{ background: "#200A00", border: "1px solid #FF6B00", padding: "8px 10px", marginBottom: 8 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
            <span style={{ width: 7, height: 7, borderRadius: "50%", background: "#FF6B00",
              boxShadow: "0 0 6px #FF6B00", display: "inline-block" }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 8, color: "#FF6B00", fontWeight: 700, letterSpacing: "0.12em" }}>
                ALERT: HUB {alert.hub?.toUpperCase()} SATURATION
              </div>
              <div style={{ fontSize: 8, color: "#AA5500", letterSpacing: "0.08em", marginTop: 1 }}>
                ρ={alert.rho?.toFixed(4)} · Alert #{alert.alert_count}
              </div>
            </div>
          </div>

          {/* Decision buttons or result */}
          {!decision ? (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
              <button
                data-testid="btn-approve-diversion"
                onClick={() => handleDecision("APPROVED")}
                disabled={deciding}
                style={{
                  background: "#001A05", border: "1px solid #32D74B",
                  color: "#32D74B", fontFamily: "JetBrains Mono",
                  fontSize: 9, fontWeight: 700, letterSpacing: "0.12em",
                  padding: "7px 4px", cursor: deciding ? "wait" : "pointer",
                }}>
                {deciding ? "..." : "✓ APPROVE DIVERSION"}
              </button>
              <button
                data-testid="btn-dismiss-diversion"
                onClick={() => handleDecision("DISMISSED")}
                disabled={deciding}
                style={{
                  background: "#1A0000", border: "1px solid #FF3B30",
                  color: "#FF3B30", fontFamily: "JetBrains Mono",
                  fontSize: 9, fontWeight: 700, letterSpacing: "0.12em",
                  padding: "7px 4px", cursor: deciding ? "wait" : "pointer",
                }}>
                {deciding ? "..." : "✕ DISMISS"}
              </button>
            </div>
          ) : (
            <div data-testid="decision-result" style={{
              padding: "6px 8px",
              background: decision === "APPROVED" ? "#001A05" : "#1A0000",
              border: `1px solid ${decision === "APPROVED" ? "#32D74B33" : "#FF3B3033"}`,
              fontSize: 8,
              color: decision === "APPROVED" ? "#32D74B" : "#FF3B30",
              letterSpacing: "0.08em",
            }}>
              {decisionMsg}
            </div>
          )}
        </div>
      )}

      {/* ── GENERATE OPERATIONAL DIRECTIVE (PDF) ── */}
      <button
        data-testid="btn-generate-directive"
        onClick={handleGeneratePDF}
        disabled={generating}
        style={{
          width: "100%",
          background: pdfReady ? "#001A05" : generating ? "#0D0800" : "#1A0F00",
          border: `1px solid ${pdfReady ? "#32D74B" : "#FFB340"}`,
          color: pdfReady ? "#32D74B" : "#FFB340",
          fontFamily: "JetBrains Mono", fontWeight: 900,
          fontSize: 9, letterSpacing: "0.14em",
          padding: "9px 8px", cursor: generating ? "wait" : "pointer",
          textAlign: "center", marginBottom: 0,
          transition: "all 0.2s",
        }}>
        {pdfReady
          ? "✓ DIRECTIVE SAVED — CHECK DOWNLOADS"
          : generating
            ? "⟳ GENERATING DIRECTIVE..."
            : "⬇ GENERATE OPERATIONAL DIRECTIVE"}
      </button>
    </div>
  );
}

/* ── Main Dashboard ───────────────────────────────────────────────────────── */
export default function Dashboard({
  kState, ticker, loading, apiBase, apiKey, authStatus, onRefresh,
  isCalibrating, setCalibrating,
  isStreaming, onStreamStart, onStreamStop,
  isGhostMode, ghostEndingSoon, ghostComplete, onGhostStart, onGhostStop,
  mu, onMuChange, activeTab, setActiveTab,
  sessionRole, onOpenOnboarding, onOpenAdmin, onLogout,
}) {
  const catastrophe = kState?.catastrophe;
  const collapse    = kState?.collapse;
  const hubs        = kState?.hubs ?? [];
  const bgColor     = collapse ? "#140000" : catastrophe ? "#0D0000" : "#050505";

  // ── Settings state ──────────────────────────────────────────────────────────
  const [showSettings, setShowSettings] = useState(false);
  const [settings, setSettings] = useState({
    cost_per_failure:   3.94,
    truck_transit_cost: 1.20,
  });

  const handleSettingsSaved = useCallback(({ cost_per_failure, truck_transit_cost }) => {
    setSettings({ cost_per_failure, truck_transit_cost });
  }, []);

  // ── Live annualized exposure using user-configured cost ─────────────────────
  const annualizedDisplay = useMemo(() => {
    // Use backend-computed value if available (it already uses _settings_cache),
    // but also recompute client-side so the preview is instant before next poll.
    if (kState?.annualized_exposure) {
      return kState.annualized_exposure;
    }
    return 0;
  }, [kState]);

  if (loading && !kState) {
    return (
      <div style={{ background: "#050505", minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <div style={{ textAlign: "center" }}>
          <div style={{ display: "flex", justifyContent: "center", marginBottom: 16 }}>
            <svg width="40" height="40" viewBox="0 0 34 34" fill="none">
              <path d="M 24 7 C 30 7, 30 15, 17 17 C 4 19, 4 27, 10 27" stroke="#FFB340" strokeWidth="2.2" strokeLinecap="round" fill="none" />
              <circle cx="24" cy="7" r="2.4" fill="#FFB340" />
              <circle cx="10" cy="27" r="2.4" fill="#FFB340" opacity="0.7" />
            </svg>
          </div>
          <div style={{ color: "#FFB340", fontFamily: "Chivo, sans-serif", fontWeight: 900, fontSize: 16, letterSpacing: "0.2em" }}>
            SITI INTELLIGENCE
          </div>
          <div style={{ color: "#CCCCCC", fontFamily: "JetBrains Mono", fontSize: 11, marginTop: 16, letterSpacing: "0.12em" }}>
            INITIALIZING 3-HUB NETWORK...
          </div>
        </div>
      </div>
    );
  }

  return (
    <>
      {collapse && <div className="collapse-screen-border" />}
      {isCalibrating && <CalibrationOverlay />}
      {showSettings && (
        <SettingsModal
          apiBase={apiBase} apiKey={apiKey}
          settings={settings}
          onSaved={handleSettingsSaved}
          onClose={() => setShowSettings(false)}
        />
      )}

      <div data-testid="main-dashboard"
        className={catastrophe ? "catastrophe-mode" : ""}
        style={{ background: bgColor, minHeight: "100vh", transition: "background 0.5s ease",
          fontFamily: "JetBrains Mono, monospace" }}>

        {/* Executive HUD */}
        <ExecutiveHUD kState={kState} ticker={ticker} catastrophe={catastrophe}
          isStreaming={isStreaming} isGhostMode={isGhostMode} authStatus={authStatus}
          settings={settings} />

        {/* ── HERO METRIC + Settings Gear ─────────────────────── */}
        <div data-testid="hero-metric" style={{
          textAlign: "center", padding: "20px 16px 14px",
          borderBottom: "1px solid #1A1A1A", position: "relative",
        }}>
          {/* Settings Gear — top right of hero */}
          <div style={{ position: "absolute", top: 14, right: 16,
            display: "flex", gap: 6, alignItems: "center" }}>
            {/* ONBOARDING WIZARD */}
            {onOpenOnboarding && (
              <button onClick={onOpenOnboarding}
                title="CSV Onboarding Wizard — auto-detect column mapping"
                style={{
                  background: "none", border: "1px solid #2A2A2A",
                  color: "#555", height: 32, padding: "0 10px", cursor: "pointer",
                  fontSize: 9, borderRadius: 2, fontFamily: "JetBrains Mono",
                  letterSpacing: "0.1em", whiteSpace: "nowrap",
                  transition: "border-color 0.2s, color 0.2s",
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "#64D2FF"; e.currentTarget.style.color = "#64D2FF"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "#2A2A2A"; e.currentTarget.style.color = "#555"; }}>
                📂 IMPORT
              </button>
            )}
            {/* CSV EXPORT — MISSING 6 */}
            <CsvExportButton apiBase={apiBase} apiKey={apiKey} />
            {/* EMAIL REPORT */}
            <EmailReportButton apiBase={apiBase} apiKey={apiKey} kState={kState} />
            {/* ADMIN DASHBOARD — MISSING 3, only shown to ADMIN role */}
            {onOpenAdmin && sessionRole === "ADMIN" && (
              <button onClick={onOpenAdmin} title="Admin dashboard — manage clients"
                style={{
                  background: "none", border: "1px solid #2A2A2A",
                  color: "#555", height: 32, padding: "0 10px", cursor: "pointer",
                  fontSize: 9, borderRadius: 2, fontFamily: "JetBrains Mono",
                  letterSpacing: "0.1em", whiteSpace: "nowrap",
                  transition: "border-color 0.2s, color 0.2s",
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "#FF9F0A"; e.currentTarget.style.color = "#FF9F0A"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "#2A2A2A"; e.currentTarget.style.color = "#555"; }}>
                ⚙ ADMIN
              </button>
            )}
            {/* SETTINGS GEAR */}
            <button
              data-testid="btn-settings-gear"
              onClick={() => setShowSettings(true)}
              title="Configure cost parameters"
              style={{
                background: "none", border: "1px solid #2A2A2A",
                color: "#555", width: 32, height: 32, cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: 16, borderRadius: 2,
                transition: "border-color 0.2s, color 0.2s",
              }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = "#FFB340"; e.currentTarget.style.color = "#FFB340"; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = "#2A2A2A"; e.currentTarget.style.color = "#555"; }}>
              ⚙
            </button>
            {/* LOGOUT (only if real session) */}
            {onLogout && (
              <button onClick={onLogout} title="Sign out"
                style={{
                  background: "none", border: "1px solid #2A2A2A",
                  color: "#555", width: 32, height: 32, cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  fontSize: 14, borderRadius: 2,
                  transition: "border-color 0.2s, color 0.2s",
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = "#FF3B30"; e.currentTarget.style.color = "#FF3B30"; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = "#2A2A2A"; e.currentTarget.style.color = "#555"; }}>
                ⏏
              </button>
            )}
          </div>

          <div style={{ fontSize: 10, color: "#888", letterSpacing: "0.25em", textTransform: "uppercase", marginBottom: 4 }}>
            ANNUALIZED REVENUE RECOVERY
          </div>
          <div className="hero-neon-text" style={{
            fontSize: 48, fontWeight: 900, fontFamily: "JetBrains Mono",
            color: "#39FF14", lineHeight: 1,
            textShadow: "0 0 20px #39FF1466, 0 0 40px #39FF1433, 0 0 80px #39FF1420",
          }}>
            ₹{annualizedDisplay
              ? (annualizedDisplay / 1_000_000).toFixed(2) + "M"
              : "2.81M"}
          </div>
          <div style={{ fontSize: 9, color: "#555", letterSpacing: "0.15em", marginTop: 4 }}>
            MIMI KERNEL v2.1 · ₹{settings.cost_per_failure}/failure · CLICK ⚙ TO CONFIGURE
          </div>
        </div>

        {/* ── 3-HUB NETWORK CARDS ─────────────────────────── */}
        <div data-testid="hub-cards-row" className="hub-cards-grid"
          style={{ gap: 10, padding: "10px 16px" }}>
          {hubs.map(hub => (
            <HubCard key={hub.name} hub={hub} criticalRho={kState?.critical_rho ?? 0.85} />
          ))}
        </div>

        {/* PVI Alert */}
        {kState?.pvi_alert && !collapse && (
          <div data-testid="pvi-alert-banner"
            style={{ background: "#1A0A00", border: "1px solid #FF9F0A",
              padding: "8px 24px", display: "flex", alignItems: "center", gap: 12,
              margin: "0 16px 4px" }}>
            <span className="blink-critical" style={{ color: "#FF9F0A", fontSize: 10,
              fontWeight: 700, letterSpacing: "0.12em", fontFamily: "JetBrains Mono" }}>
              PREDICTIVE VOLATILITY INDEX: {(kState?.pvi ?? 0).toFixed(1)}% — T+3 RISING UNCERTAINTY
            </span>
          </div>
        )}

        {/* Collapse Banner */}
        {collapse && (
          <div data-testid="collapse-banner"
            style={{ background: "#200000", border: "2px solid #FF3B30",
              padding: "14px 24px", display: "flex", alignItems: "center", gap: 12,
              margin: "0 16px 4px" }}>
            <span style={{ display: "inline-block", width: 8, height: 8, borderRadius: "50%", background: "#FF3B30" }} />
            <span className="blink-critical" style={{
              color: "#FF3B30", fontFamily: "Chivo, sans-serif", fontWeight: 900,
              fontSize: 15, letterSpacing: "0.2em" }}>
              NETWORK COLLAPSE: SIGMOIDAL DECAY TRIGGERED
            </span>
          </div>
        )}

        {/* Catastrophe banner */}
        {catastrophe && !collapse && (
          <div data-testid="catastrophe-banner"
            style={{ background: "#1A0000", border: "1px solid #FF9F0A",
              padding: "10px 24px", display: "flex", alignItems: "center", gap: 12,
              margin: "0 16px" }}>
            <span className="blink-critical" style={{
              color: "#FF9F0A", fontFamily: "Chivo, sans-serif", fontWeight: 900,
              fontSize: 13, letterSpacing: "0.15em" }}>
              PREEMPTIVE DIVERSION PROTOCOL INITIATED
            </span>
          </div>
        )}

        {/* ── MAIN 3-COL GRID ──────────────────────────────── */}
        <div className="main-content-grid"
          style={{ padding: "12px 16px", gap: 12 }}>

          {/* LEFT: KPI Cards */}
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <KPICard label="NETWORK ρ (λ/μ)" value={kState?.global_rho?.toFixed(4)}
              color={collapse ? "#FF3B30" : catastrophe ? "#FF9F0A" : "#FFB340"} testId="kpi-rho" />
            <KPICard label="TOTAL ARRIVAL λ" value={`${kState?.total_lambda?.toFixed(1) ?? "—"}/hr`}
              color="#64D2FF" testId="kpi-lambda" />
            <KPICard label="SERVICE CAPACITY μ" value={`${kState?.mu?.toFixed(0) ?? "150"}/hr`}
              unit="per hub" color="#32D74B" testId="kpi-mu" />
            <KPICard label="INSTABILITY Φ(ρ)" value={kState?.phi?.toFixed(4)}
              unit={`k=${kState?.k_decay ?? 20} · ρ_c=${kState?.critical_rho?.toFixed(2) ?? "0.85"}`}
              color={kState?.phi > 0.5 ? "#FF3B30" : kState?.phi > 0.3 ? "#FF9F0A" : "#32D74B"} testId="kpi-phi" />
            <KPICard label="QUEUE DEPTH W_q" value={kState?.wq?.toFixed(3)} unit="norm. units"
              color={kState?.wq > 4 ? "#FF3B30" : "#64D2FF"} testId="kpi-wq" />
            <KPICard label="HIGH-IMP FAILURE RATE"
              value={`${((kState?.inverse_reliability?.failure_rate ?? 0.817) * 100).toFixed(1)}%`}
              unit={`Audit Baseline: 81.7% · ${kState?.inverse_reliability?.failure_count ?? 0} of ${kState?.inverse_reliability?.total_high ?? 0}`}
              color="#FF3B30" testId="kpi-high-imp" />
            <KPICard label={`LEAKAGE ₹${settings.cost_per_failure}/unit`}
              value={`₹${kState?.inverse_reliability?.leakage_total?.toLocaleString("en-IN", { minimumFractionDigits: 0 }) ?? "0"}`}
              color="#FF9F0A" testId="kpi-leakage" />
          </div>

          {/* CENTER */}
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <MIMIPanel kState={kState} catastrophe={catastrophe} />
            <HubCharts kState={kState} />
          </div>

          {/* RIGHT: Commander Console + Widgets */}
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <CommanderConsole
              kState={kState}
              apiBase={apiBase}
              apiKey={apiKey}
              settings={settings}
            />
            <RecoveryWidget ticker={ticker} kState={kState} settings={settings} />
            <KalmanWidget kState={kState} />
            <FailureTable kState={kState} />
          </div>
        </div>

        {/* ── BOTTOM TABS ─────────────────────────────────── */}
        <div style={{ padding: "0 16px 4px" }}>
          <div data-testid="bottom-tabs" style={{ display: "flex", gap: 0, borderBottom: "1px solid #1F1F1F" }}>
            {[
              { id: "network", label: "NETWORK CONTROL" },
              { id: "api-docs", label: "API INTEGRATION" },
              { id: "audit",   label: "⬡ AUDIT: DECISION HISTORY" },
            ].map(tab => (
              <button key={tab.id} data-testid={`tab-${tab.id}`}
                onClick={() => setActiveTab?.(tab.id)}
                style={{
                  background: activeTab === tab.id ? "#0A0A0A" : "transparent",
                  border: "none", borderBottom: activeTab === tab.id ? "2px solid #FFB340" : "2px solid transparent",
                  color: activeTab === tab.id ? "#FFB340" : "#555",
                  fontFamily: "JetBrains Mono", fontSize: 10, fontWeight: 700,
                  letterSpacing: "0.15em", padding: "10px 20px",
                  cursor: "pointer", transition: "all 0.2s",
                }}>
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {activeTab === "api-docs" ? (
          <div style={{ padding: "0 16px 16px" }}>
            <ApiDocsPanel />
          </div>
        ) : activeTab === "audit" ? (
          <div style={{ padding: "0 16px 16px" }}>
            <AuditLedger apiBase={apiBase} apiKey={apiKey} />
          </div>
        ) : (
          <DataInjection
            apiBase={apiBase} onRefresh={onRefresh} kState={kState} ticker={ticker}
            onCalibrating={setCalibrating}
            isStreaming={isStreaming} onStreamStart={onStreamStart} onStreamStop={onStreamStop}
            isGhostMode={isGhostMode} onGhostStart={onGhostStart} onGhostStop={onGhostStop}
            mu={mu} onMuChange={onMuChange}
          />
        )}
      </div>
    </>
  );
}

/* ── Sub-components ──────────────────────────────────────────────────────── */

function KPICard({ label, value, unit, color, testId }) {
  return (
    <div data-testid={testId} style={{ background: "#0A0A0A", border: "1px solid #1F1F1F", padding: "10px 12px" }}>
      <div style={{ color: "#D4D4D8", fontSize: 9, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 4 }}>
        {label}
      </div>
      <div style={{ color, fontSize: 22, fontWeight: 700, fontFamily: "JetBrains Mono", lineHeight: 1 }}>
        {value ?? "—"}
      </div>
      {unit && <div style={{ color: "#888", fontSize: 9, marginTop: 2, letterSpacing: "0.1em" }}>{unit}</div>}
    </div>
  );
}

function RecoveryWidget({ ticker, kState, settings }) {
  const costPer = settings?.cost_per_failure ?? 3.94;
  const annualized = kState?.annualized_exposure
    ? `₹${(kState.annualized_exposure / 1_000_000).toFixed(2)}M Mitigated Exposure`
    : "—";

  return (
    <div data-testid="recovery-counter" style={{ background: "#0A0A0A", border: "1px solid #1F1F1F", padding: "12px" }}>
      <div style={{ color: "#D4D4D8", fontSize: 9, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 8 }}>
        REVENUE SAVED · RECOVERY COUNTER
      </div>
      <div style={{ color: "#32D74B", fontSize: 28, fontWeight: 700, fontFamily: "JetBrains Mono", lineHeight: 1 }}>
        ₹{ticker?.revenue_saved?.toLocaleString("en-IN", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) ?? "0.00"}
      </div>
      <div style={{ color: "#CCCCCC", fontSize: 10, marginTop: 6, display: "flex", justifyContent: "space-between" }}>
        <span>{ticker?.total_diverted?.toLocaleString() ?? 0} units diverted</span>
        <span style={{ color: "#32D74B" }}>× ₹{costPer}/unit</span>
      </div>
      <div style={{ fontSize: 8, color: "#32D74B", letterSpacing: "0.1em", marginTop: 6, lineHeight: 1.5 }}>
        Session Recovery · Annualized: <span style={{ color: "#39FF14", fontWeight: 700 }}>{annualized}</span>
      </div>
      <div style={{ marginTop: 8, height: 2, background: "#1F1F1F" }}>
        <div style={{
          height: "100%", background: "#32D74B",
          width: `${Math.min(100, (ticker?.refresh_count ?? 0) * 3.33)}%`,
          transition: "width 0.4s",
        }} />
      </div>
    </div>
  );
}

function KalmanWidget({ kState }) {
  const k = kState?.kalman;
  const rhoDot = k?.rho_dot ?? 0;
  return (
    <div data-testid="kalman-widget" style={{ background: "#0A0A0A", border: "1px solid #1F1F1F", padding: "12px" }}>
      <div style={{ color: "#D4D4D8", fontSize: 9, letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 8 }}>
        2D KALMAN STATE · x = [ρ, ρ̇]
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 6 }}>
        {[
          { label: "x[0] = ρ",    value: k?.x_hat?.toFixed(4), color: "#64D2FF" },
          { label: "x[1] = ρ̇",   value: rhoDot !== 0 ? (rhoDot > 0 ? "+" : "") + rhoDot.toFixed(6) : "0.000000",
            color: rhoDot > 0 ? "#FF9F0A" : "#64D2FF" },
          { label: "T+1 (15m)",  value: k?.rho_t1?.toFixed(4), color: k?.rho_t1 >= 0.85 ? "#FF3B30" : "#32D74B" },
          { label: "T+3 (45m)",  value: k?.rho_t3?.toFixed(4), color: k?.rho_t3 >= 0.85 ? "#FF3B30" : "#32D74B" },
        ].map(({ label, value, color }) => (
          <div key={label} style={{ background: "#111", padding: "6px 8px", border: "1px solid #161616" }}>
            <div style={{ color: "#888", fontSize: 9, letterSpacing: "0.1em" }}>{label}</div>
            <div style={{ color, fontSize: 13, fontWeight: 700 }}>{value ?? "—"}</div>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 8, color: "#888", fontSize: 9, letterSpacing: "0.08em" }}>
        F=[[1,dt],[0,1]] · H=[[1,0]] · Q=diag(0.002,0.001) · R=0.005
      </div>
    </div>
  );
}

/* ── DIAMOND PROTOCOL 4: FORENSIC LEDGER — AUDIT DECISION HISTORY ─────────── */
function AuditLedger({ apiBase, apiKey }) {
  const [decisions, setDecisions] = React.useState([]);
  const [loading,   setLoading]   = React.useState(true);
  const [error,     setError]     = React.useState("");
  const [limit,     setLimit]     = React.useState(50);

  const fetchDecisions = React.useCallback(async () => {
    setLoading(true); setError("");
    try {
      const res = await axios.get(`${apiBase}/decisions/history?limit=${limit}`,
        { headers: { "X-API-KEY": apiKey } });
      setDecisions((res.data.decisions || []).slice().reverse());
    } catch (e) {
      setError(e.response?.data?.detail || "Failed to fetch decision history");
    } finally {
      setLoading(false);
    }
  }, [apiBase, apiKey, limit]);

  React.useEffect(() => { fetchDecisions(); }, [fetchDecisions]);

  const actionColor  = (a) => a === "APPROVED" ? "#32D74B" : "#FF3B30";
  const actionBg     = (a) => a === "APPROVED" ? "#001A05" : "#1A0000";
  const actionSymbol = (a) => a === "APPROVED" ? "✓" : "✕";

  const fmtTs = (ts) => {
    try {
      const d = new Date(ts);
      return d.toLocaleDateString("en-IN", { day:"2-digit", month:"short", year:"numeric" })
        + "  " + d.toLocaleTimeString("en-IN", { hour12: false });
    } catch { return ts || "—"; }
  };

  const COL_WIDTHS = ["14%", "10%", "8%", "7%", "37%", "24%"];
  const HEADERS    = ["TIMESTAMP", "HUB", "ρ", "ACTION", "DIRECTIVE", "OPERATOR · REF"];

  return (
    <div data-testid="audit-ledger"
      style={{ background: "#080808", border: "1px solid #1A1A1A", padding: "16px", fontFamily: "JetBrains Mono" }}>

      {/* ── Header ── */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
        <div>
          <div style={{ color: "#FFB340", fontWeight: 900, fontSize: 12, letterSpacing: "0.2em" }}>
            ⬡ FORENSIC LEDGER — DECISION AUDIT TRAIL
          </div>
          <div style={{ color: "#444", fontSize: 9, letterSpacing: "0.12em", marginTop: 2 }}>
            PROOF OF WORK · EVERY APPROVE/DISMISS LOGGED TO MONGODB · BOARD-READY
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <select
            value={limit}
            onChange={e => setLimit(Number(e.target.value))}
            style={{ background: "#111", border: "1px solid #333", color: "#888",
              fontFamily: "JetBrains Mono", fontSize: 9, padding: "4px 8px", cursor: "pointer" }}>
            {[25, 50, 100, 200].map(n => <option key={n} value={n}>Last {n}</option>)}
          </select>
          <button
            onClick={fetchDecisions}
            style={{ background: "#111", border: "1px solid #333", color: "#FFB340",
              fontFamily: "JetBrains Mono", fontSize: 9, letterSpacing: "0.1em",
              padding: "5px 12px", cursor: "pointer" }}>
            ⟳ REFRESH
          </button>
        </div>
      </div>

      {/* ── Stats bar ── */}
      {!loading && decisions.length > 0 && (() => {
        const approved  = decisions.filter(d => d.action === "APPROVED").length;
        const dismissed = decisions.filter(d => d.action === "DISMISSED").length;
        return (
          <div style={{ display: "flex", gap: 16, marginBottom: 12 }}>
            <div style={{ background: "#001A05", border: "1px solid #32D74B33", padding: "6px 14px" }}>
              <span style={{ color: "#32D74B", fontSize: 18, fontWeight: 900 }}>{approved}</span>
              <span style={{ color: "#555", fontSize: 9, marginLeft: 6, letterSpacing: "0.1em" }}>APPROVED</span>
            </div>
            <div style={{ background: "#1A0000", border: "1px solid #FF3B3033", padding: "6px 14px" }}>
              <span style={{ color: "#FF3B30", fontSize: 18, fontWeight: 900 }}>{dismissed}</span>
              <span style={{ color: "#555", fontSize: 9, marginLeft: 6, letterSpacing: "0.1em" }}>DISMISSED</span>
            </div>
            <div style={{ background: "#0A0A0A", border: "1px solid #1A1A1A", padding: "6px 14px" }}>
              <span style={{ color: "#FFB340", fontSize: 18, fontWeight: 900 }}>{decisions.length}</span>
              <span style={{ color: "#555", fontSize: 9, marginLeft: 6, letterSpacing: "0.1em" }}>TOTAL DECISIONS</span>
            </div>
          </div>
        );
      })()}

      {/* ── Table ── */}
      {loading ? (
        <div style={{ color: "#555", fontSize: 9, letterSpacing: "0.1em", padding: "20px 0", textAlign: "center" }}>
          LOADING DECISION HISTORY...
        </div>
      ) : error ? (
        <div style={{ color: "#FF3B30", fontSize: 9, padding: "12px", background: "#1A0000",
          border: "1px solid #FF3B3033", letterSpacing: "0.08em" }}>
          ⚠ {error}
        </div>
      ) : decisions.length === 0 ? (
        <div style={{ color: "#555", fontSize: 9, letterSpacing: "0.1em", padding: "24px 0", textAlign: "center" }}>
          NO DECISIONS RECORDED YET.<br />
          <span style={{ color: "#333" }}>APPROVE or DISMISS an alert to begin the audit trail.</span>
        </div>
      ) : (
        <div style={{ overflowX: "auto" }}>
          {/* Table header */}
          <div style={{ display: "grid", gridTemplateColumns: COL_WIDTHS.join(" "),
            borderBottom: "1px solid #1A1A1A", paddingBottom: 6, marginBottom: 4 }}>
            {HEADERS.map((h, i) => (
              <div key={i} style={{ fontSize: 8, color: "#444", letterSpacing: "0.12em",
                paddingRight: 8, textTransform: "uppercase" }}>
                {h}
              </div>
            ))}
          </div>

          {/* Table rows */}
          {decisions.map((d, idx) => (
            <div key={idx} data-testid="audit-row"
              style={{ display: "grid", gridTemplateColumns: COL_WIDTHS.join(" "),
                padding: "7px 0", borderBottom: "1px solid #111",
                background: idx % 2 === 0 ? "transparent" : "#050505",
                alignItems: "start" }}>

              {/* Timestamp */}
              <div style={{ fontSize: 8, color: "#888", paddingRight: 8, lineHeight: 1.6 }}>
                {fmtTs(d.timestamp)}
              </div>

              {/* Hub */}
              <div style={{ fontSize: 10, color: "#FFB340", fontWeight: 700, paddingRight: 8 }}>
                {(d.hub || "—").toUpperCase()}
              </div>

              {/* rho */}
              <div style={{ fontSize: 10, color: "#64D2FF", fontWeight: 700, paddingRight: 8 }}>
                {d.rho_at_decision != null ? d.rho_at_decision.toFixed(4) : "—"}
              </div>

              {/* Action badge */}
              <div style={{ paddingRight: 8 }}>
                <span style={{
                  background: actionBg(d.action),
                  border: `1px solid ${actionColor(d.action)}44`,
                  color: actionColor(d.action),
                  fontSize: 8, fontWeight: 900, letterSpacing: "0.1em",
                  padding: "2px 6px", display: "inline-block",
                }}>
                  {actionSymbol(d.action)} {(d.action || "—").toUpperCase()}
                </span>
              </div>

              {/* Directive */}
              <div style={{ fontSize: 8, color: "#D4D4D8", lineHeight: 1.6, paddingRight: 8,
                overflow: "hidden", textOverflow: "ellipsis" }}>
                {d.directive || <span style={{ color: "#444" }}>—</span>}
              </div>

              {/* Operator + dataset ref */}
              <div style={{ fontSize: 8, color: "#555", lineHeight: 1.6 }}>
                <div style={{ color: "#888" }}>{d.operator_id || "ops"}</div>
                <div style={{ color: "#333", fontSize: 7, marginTop: 2 }}>
                  {d.dataset || "—"}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── Export note ── */}
      <div style={{ marginTop: 12, padding: "6px 10px", background: "#050505",
        border: "1px solid #111", fontSize: 8, color: "#333", letterSpacing: "0.08em" }}>
        DIAMOND AUDIT: All decisions written to MongoDB <code style={{ color: "#555" }}>human_decisions</code> collection ·
        Fetch via <code style={{ color: "#555" }}>GET /api/decisions/history</code> ·
        Each record includes timestamp, hub, ρ, action, directive, operator_id
      </div>

      {/* BUG 6 FIX: Ghost mode ending countdown */}
      {ghostEndingSoon && isGhostMode && (
        <div style={{
          position: "fixed", bottom: 24, right: 24, zIndex: 999,
          background: "#1A0D00", border: "1px solid #FF9F0A",
          padding: "10px 18px", fontFamily: "JetBrains Mono",
          fontSize: 11, color: "#FF9F0A", letterSpacing: "0.1em",
          boxShadow: "0 0 20px #FF9F0A33",
        }}>
          ⚡ GHOST MODE ENDING IN ~10s
        </div>
      )}
      {/* BUG 6 FIX: Ghost mode completed notification */}
      {ghostComplete && (
        <div style={{
          position: "fixed", bottom: 24, right: 24, zIndex: 999,
          background: "#001A05", border: "1px solid #32D74B",
          padding: "10px 18px", fontFamily: "JetBrains Mono",
          fontSize: 11, color: "#32D74B", letterSpacing: "0.1em",
          boxShadow: "0 0 20px #32D74B33",
          animation: "fadeInUp 0.3s ease",
        }}>
          ✓ GHOST MODE COMPLETE — LIVE DATA ACTIVE
        </div>
      )}
    </div>
  );
}
