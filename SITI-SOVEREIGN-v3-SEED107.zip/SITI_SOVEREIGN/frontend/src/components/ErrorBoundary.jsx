/**
 * SITI Intelligence — Error Boundary
 * Catches React render crashes and shows a professional recovery screen.
 * Prevents white-screen-of-death during demos.
 */
import React from "react";

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null, errorInfo: null, retryCount: 0 };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    this.setState({ errorInfo });
    console.error("[SITI] Render error caught by ErrorBoundary:", error, errorInfo);
  }

  handleRetry = () => {
    this.setState(s => ({
      hasError: false, error: null, errorInfo: null,
      retryCount: s.retryCount + 1
    }));
  };

  render() {
    if (!this.state.hasError) return this.props.children;

    const err = this.state.error?.toString() || "Unknown render error";
    return (
      <div style={{
        minHeight: "100vh", background: "#06070d",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "'JetBrains Mono', monospace", padding: 24,
      }}>
        <div style={{
          maxWidth: 480, width: "100%",
          background: "#0c0f1e", border: "1px solid #f0284a40",
          borderRadius: 8, padding: 32, textAlign: "center",
        }}>
          <div style={{ fontSize: 36, marginBottom: 12 }}>⚠️</div>
          <div style={{ color: "#f0284a", fontWeight: 700, fontSize: 14,
            letterSpacing: "0.15em", marginBottom: 8 }}>
            MIMI KERNEL UI ERROR
          </div>
          <div style={{ color: "#4a5f82", fontSize: 9, letterSpacing: "0.1em",
            marginBottom: 20 }}>
            The dashboard encountered a render error. Backend data is unaffected.
          </div>

          <div style={{
            background: "#080d1a", borderRadius: 4, padding: 12,
            marginBottom: 20, textAlign: "left", maxHeight: 120,
            overflowY: "auto",
          }}>
            <div style={{ color: "#f0284a", fontSize: 8, marginBottom: 4,
              letterSpacing: "0.1em" }}>ERROR DETAIL</div>
            <div style={{ color: "#4a5f82", fontSize: 8, wordBreak: "break-all",
              lineHeight: 1.6 }}>{err}</div>
          </div>

          <div style={{ display: "flex", gap: 8, justifyContent: "center" }}>
            <button onClick={this.handleRetry} style={{
              background: "#e8a020", border: "none", borderRadius: 4,
              color: "#06070d", fontFamily: "inherit", fontWeight: 700,
              fontSize: 10, letterSpacing: "0.12em",
              padding: "10px 20px", cursor: "pointer",
            }}>
              ↺ RETRY ({this.state.retryCount} attempt{this.state.retryCount !== 1 ? "s" : ""})
            </button>
            <button onClick={() => window.location.reload()} style={{
              background: "none", border: "1px solid #1b2035",
              borderRadius: 4, color: "#4a5f82", fontFamily: "inherit",
              fontSize: 10, letterSpacing: "0.12em",
              padding: "10px 20px", cursor: "pointer",
            }}>
              ⟳ FULL RELOAD
            </button>
          </div>

          <div style={{ marginTop: 20, color: "#2a3550", fontSize: 8 }}>
            SITI Intelligence · Backend API continues running · Case #02028317
          </div>
        </div>
      </div>
    );
  }
}
