/**
 * SITI Intelligence — JWT Login Screen
 * POST /api/auth/login → stores JWT in memory (no localStorage)
 * Falls back gracefully to direct API key mode if JWT endpoint is unavailable.
 */
import React, { useState, useCallback } from "react";
import axios from "axios";

function SITILogo({ size = 40 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 34 34" fill="none">
      <path d="M 24 7 C 30 7, 30 15, 17 17 C 4 19, 4 27, 10 27"
        stroke="#FFB340" strokeWidth="2.2" strokeLinecap="round" fill="none" />
      <circle cx="24" cy="7" r="2.4" fill="#FFB340" />
      <circle cx="10" cy="27" r="2.4" fill="#FFB340" opacity="0.7" />
      <circle cx="17" cy="17" r="1.2" fill="#FFB34055" />
    </svg>
  );
}

export default function LoginScreen({ apiBase, onLogin }) {
  const [apiKey, setApiKey]     = useState("");
  const [status, setStatus]     = useState("idle"); // idle | loading | error | success
  const [errMsg, setErrMsg]     = useState("");
  const [showKey, setShowKey]   = useState(false);

  const handleLogin = useCallback(async (e) => {
    e?.preventDefault();
    if (!apiKey.trim()) { setErrMsg("API key required"); setStatus("error"); return; }
    setStatus("loading"); setErrMsg("");
    try {
      // Attempt JWT login
      const res = await axios.post(`${apiBase}/auth/login`, { api_key: apiKey.trim() });
      onLogin({
        token:    res.data.token,
        role:     res.data.role,
        tenantId: res.data.tenant_id,
        apiKey:   apiKey.trim(),
        mode:     "jwt",
      });
      setStatus("success");
    } catch (err) {
      if (err.response?.status === 403) {
        setErrMsg("Invalid API key — check with your SITI admin");
        setStatus("error");
      } else if (err.response?.status === 404 || err.code === "ERR_NETWORK") {
        // JWT endpoint not available — fall back to direct API key mode
        onLogin({ token: null, role: "OPERATOR", apiKey: apiKey.trim(), mode: "apikey" });
        setStatus("success");
      } else {
        setErrMsg(err.response?.data?.message || err.message || "Login failed");
        setStatus("error");
      }
    }
  }, [apiKey, apiBase, onLogin]);

  return (
    <div style={{
      minHeight: "100vh", background: "#06070d",
      display: "flex", alignItems: "center", justifyContent: "center",
      fontFamily: "'JetBrains Mono', 'Courier New', monospace",
      padding: "16px",
      /* Prevent any child from causing horizontal scroll */
      overflow: "hidden",
      width: "100%",
      boxSizing: "border-box",
    }}>
      {/* Subtle grid */}
      <div style={{
        position: "fixed", inset: 0, pointerEvents: "none",
        backgroundImage: "linear-gradient(#1b2035 1px, transparent 1px), linear-gradient(90deg, #1b2035 1px, transparent 1px)",
        backgroundSize: "32px 32px", opacity: 0.35,
      }} />

      <div className="siti-login-card" style={{
        background: "#0c0f1e", border: "1px solid #1b2035",
        borderRadius: 8, position: "relative", zIndex: 1,
        boxShadow: "0 0 60px #e8a02015",
      }}>
        {/* Logo + title */}
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <SITILogo size={48} />
          <h1 style={{ color: "#FFB340", fontSize: 22, fontWeight: 900,
            letterSpacing: "0.18em", margin: "12px 0 4px" }}>
            SITI INTELLIGENCE
          </h1>
          <div style={{ color: "#4a5f82", fontSize: 9, letterSpacing: "0.12em" }}>
            LOGIC FOR THE PARADOX // POWERED BY MIMI
          </div>
          <div style={{ marginTop: 12, padding: "4px 12px",
            background: "#141828", borderRadius: 4, display: "inline-block" }}>
            <span style={{ color: "#4a5f82", fontSize: 8, letterSpacing: "0.1em" }}>
              SECURE ENTERPRISE LOGIN
            </span>
          </div>
        </div>

        {/* Form */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ color: "#4a5f82", fontSize: 8, letterSpacing: "0.12em",
            display: "block", marginBottom: 6 }}>
            API KEY
          </label>
          <div style={{ position: "relative" }}>
            <input
              type={showKey ? "text" : "password"}
              value={apiKey}
              onChange={e => { setApiKey(e.target.value); setErrMsg(""); }}
              onKeyDown={e => e.key === "Enter" && handleLogin()}
              placeholder="siti-admin-key-001"
              autoComplete="off"
              autoFocus
              style={{
                width: "100%", boxSizing: "border-box",
                background: "#080d1a", border: `1px solid ${status === "error" ? "#f0284a" : "#1b2035"}`,
                borderRadius: 4, color: "#bfcce8", fontSize: 12,
                padding: "10px 40px 10px 12px", outline: "none",
                fontFamily: "inherit", letterSpacing: "0.05em",
                transition: "border-color 0.2s",
              }}
              onFocus={e => e.target.style.borderColor = "#e8a020"}
              onBlur={e => e.target.style.borderColor = status === "error" ? "#f0284a" : "#1b2035"}
            />
            <button onClick={() => setShowKey(v => !v)} style={{
              position: "absolute", right: 8, top: "50%", transform: "translateY(-50%)",
              background: "none", border: "none", color: "#4a5f82", cursor: "pointer",
              padding: "4px", fontSize: 12,
            }}>{showKey ? "🙈" : "👁"}</button>
          </div>

          {errMsg && (
            <div style={{ color: "#f0284a", fontSize: 9, marginTop: 6,
              letterSpacing: "0.08em" }}>
              ⛔ {errMsg}
            </div>
          )}
        </div>

        {/* Login button */}
        <button
          onClick={handleLogin}
          disabled={status === "loading"}
          style={{
            width: "100%", padding: "11px",
            background: status === "loading" ? "#141828" : "#e8a020",
            border: "none", borderRadius: 4,
            color: status === "loading" ? "#4a5f82" : "#06070d",
            fontFamily: "inherit", fontWeight: 700, fontSize: 11,
            letterSpacing: "0.15em", cursor: status === "loading" ? "wait" : "pointer",
            transition: "background 0.2s, color 0.2s",
          }}>
          {status === "loading" ? "AUTHENTICATING..." : "AUTHENTICATE →"}
        </button>

        {/* Role info */}
        <div style={{ marginTop: 20, padding: "12px", background: "#080d1a",
          borderRadius: 4, border: "1px solid #141828" }}>
          <div style={{ color: "#4a5f82", fontSize: 8, letterSpacing: "0.1em",
            marginBottom: 8 }}>AVAILABLE ROLES</div>
          {[
            { role: "ADMIN",      desc: "Full access — 18 endpoints, hub CRUD, system logs" },
            { role: "OPERATOR",   desc: "Diversion approve/dismiss, all reads" },
            { role: "INTEGRATOR", desc: "POST /v1/intercept + GET state only" },
          ].map(({ role, desc }) => (
            <div key={role} style={{ display: "flex", gap: 8, marginBottom: 4,
              alignItems: "flex-start" }}>
              <span style={{ color: "#e8a020", fontSize: 8, fontWeight: 700,
                minWidth: 70, letterSpacing: "0.08em" }}>{role}</span>
              <span style={{ color: "#4a5f82", fontSize: 8 }}>{desc}</span>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div style={{ marginTop: 16, textAlign: "center", color: "#2a3550",
          fontSize: 7, letterSpacing: "0.1em" }}>
          SITI INTELLIGENCE v2 · MIMI LOGIC KERNEL · CASE #02028317
        </div>
      </div>
    </div>
  );
}
