/**
 * SITI Intelligence — Admin Dashboard
 * Shows all provisioned clients, their live IRP status, last activity, usage stats.
 * Endpoint: GET /api/admin/clients
 * Also: provision new keys inline, revoke keys, export usage to CSV.
 */
import React, { useState, useEffect, useCallback } from "react";
import axios from "axios";

function StatusDot({ active }) {
  return (
    <span style={{
      display: "inline-block", width: 7, height: 7, borderRadius: "50%",
      background: active ? "#1ae87a" : "#f0284a",
      boxShadow: active ? "0 0 6px #1ae87a" : "none",
      marginRight: 5, verticalAlign: "middle",
    }} />
  );
}

function RhoBadge({ rho }) {
  if (rho == null) return <span style={{ color: "#2a3550", fontSize: 9 }}>—</span>;
  const col = rho >= 0.85 ? "#f0284a" : rho >= 0.75 ? "#e8a020" : "#1ae87a";
  return <span style={{ color: col, fontWeight: 700, fontSize: 10 }}>{rho.toFixed(4)}</span>;
}

export default function AdminDashboard({ apiBase, apiKey, onClose }) {
  const [clients, setClients]     = useState([]);
  const [usage, setUsage]         = useState([]);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState("");
  const [tab, setTab]             = useState("clients"); // clients | provision | usage
  const [newClient, setNewClient] = useState({ client_name: "", role: "OPERATOR", notes: "" });
  const [provResult, setProvResult] = useState(null);
  const [provisioning, setProvisioning] = useState(false);
  const [revoking, setRevoking]   = useState("");

  const api = useCallback((method, url, data) =>
    axios({ method, url: `${apiBase}${url}`, data, headers: { "X-API-KEY": apiKey } }),
    [apiBase, apiKey]);

  const load = useCallback(async () => {
    setLoading(true); setError("");
    try {
      const [clientsRes, usageRes] = await Promise.all([
        api("get", "/admin/clients"),
        api("get", "/admin/usage").catch(() => ({ data: { usage: [] } })),
      ]);
      setClients(clientsRes.data.clients || []);
      setUsage(usageRes.data.usage || []);
    } catch (e) {
      setError(e.response?.data?.detail || e.message || "Load failed");
    } finally {
      setLoading(false);
    }
  }, [api]);

  useEffect(() => { load(); }, [load]);

  const handleProvision = useCallback(async () => {
    if (!newClient.client_name.trim()) return;
    setProvisioning(true);
    try {
      const res = await api("post", "/admin/create-key", newClient);
      setProvResult(res.data);
      setNewClient({ client_name: "", role: "OPERATOR", notes: "" });
      load();
    } catch (e) {
      setError(e.response?.data?.detail || e.message);
    } finally {
      setProvisioning(false);
    }
  }, [newClient, api, load]);

  const handleRevoke = useCallback(async (keyPrefix) => {
    if (!window.confirm(`Revoke key ${keyPrefix}? This is immediate and irreversible.`)) return;
    setRevoking(keyPrefix);
    try {
      await api("delete", `/admin/revoke-key/${keyPrefix}`);
      load();
    } catch (e) {
      setError(e.response?.data?.detail || e.message);
    } finally {
      setRevoking("");
    }
  }, [api, load]);

  const exportUsageCSV = () => {
    const rows = [
      ["Key Prefix", "Last Seen", "State Views", "CSV Uploads", "First Seen"],
      ...usage.map(u => [u.api_key_prefix, u.last_seen || "never", u.counts?.state_view || 0,
        u.counts?.csv_upload || 0, u.first_seen || "unknown"]),
    ];
    const csv = rows.map(r => r.join(",")).join("\n");
    const a = document.createElement("a");
    a.href = "data:text/csv;charset=utf-8," + encodeURIComponent(csv);
    a.download = `SITI_Usage_${Date.now()}.csv`;
    a.click();
  };

  const TABS = ["clients", "provision", "usage"];

  return (
    <div style={{
      position: "fixed", inset: 0, background: "#000000dd", zIndex: 1000,
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 16, fontFamily: "'JetBrains Mono', monospace",
    }}>
      <div style={{
        background: "#0c0f1e", border: "1px solid #1b2035",
        borderRadius: 8, width: "min(900px, 96vw)",
        maxHeight: "92vh", display: "flex", flexDirection: "column",
        boxShadow: "0 0 80px #00000099",
      }}>
        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between",
          alignItems: "center", padding: "16px 20px",
          borderBottom: "1px solid #1b2035" }}>
          <div>
            <div style={{ color: "#e8a020", fontWeight: 700, fontSize: 13,
              letterSpacing: "0.15em" }}>⚙ ADMIN DASHBOARD</div>
            <div style={{ color: "#4a5f82", fontSize: 8, marginTop: 2,
              letterSpacing: "0.1em" }}>
              {clients.length} CLIENT{clients.length !== 1 ? "S" : ""} ·
              {clients.filter(c => c.active).length} ACTIVE
            </div>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={load} style={{
              background: "none", border: "1px solid #1b2035",
              color: "#4a5f82", padding: "5px 12px", cursor: "pointer",
              fontSize: 9, borderRadius: 3, fontFamily: "inherit",
              letterSpacing: "0.1em",
            }}>↺ REFRESH</button>
            <button onClick={onClose} style={{
              background: "none", border: "1px solid #1b2035",
              color: "#4a5f82", padding: "5px 12px", cursor: "pointer",
              fontSize: 10, borderRadius: 3, fontFamily: "inherit",
            }}>✕</button>
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 0, borderBottom: "1px solid #1b2035" }}>
          {TABS.map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              background: tab === t ? "#141828" : "none",
              border: "none", borderBottom: tab === t ? "2px solid #e8a020" : "2px solid transparent",
              color: tab === t ? "#e8a020" : "#4a5f82",
              fontFamily: "inherit", fontSize: 9, letterSpacing: "0.12em",
              padding: "10px 20px", cursor: "pointer",
              textTransform: "uppercase",
            }}>{t}</button>
          ))}
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflowY: "auto", padding: 20 }}>
          {loading && (
            <div style={{ color: "#4a5f82", textAlign: "center", padding: 40, fontSize: 10 }}>
              LOADING...
            </div>
          )}
          {error && (
            <div style={{ color: "#f0284a", fontSize: 9, marginBottom: 12,
              background: "#1a0505", padding: "8px 12px", borderRadius: 4 }}>
              ⛔ {error}
            </div>
          )}

          {/* ── CLIENTS TAB ──────────────────────────────────────────────────── */}
          {!loading && tab === "clients" && (
            <div>
              <div style={{ overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 9 }}>
                  <thead>
                    <tr style={{ borderBottom: "1px solid #1b2035" }}>
                      {["STATUS","CLIENT","ROLE","DATASET","ρ NOW","IRP GAP","VIEWS","UPLOADS","LAST SEEN",""].map(h => (
                        <th key={h} style={{ color: "#4a5f82", padding: "6px 10px",
                          textAlign: "left", letterSpacing: "0.1em", fontSize: 8,
                          whiteSpace: "nowrap" }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {clients.map((c, i) => (
                      <tr key={i} style={{
                        borderBottom: "1px solid #141828",
                        background: i % 2 === 0 ? "#080d1a" : "transparent",
                      }}>
                        <td style={{ padding: "8px 10px" }}>
                          <StatusDot active={c.active} />
                        </td>
                        <td style={{ padding: "8px 10px", color: "#bfcce8",
                          maxWidth: 120, overflow: "hidden", textOverflow: "ellipsis",
                          whiteSpace: "nowrap" }}>
                          {c.client_name}
                          {c.notes && (
                            <div style={{ color: "#2a3550", fontSize: 7 }}>{c.notes.slice(0,40)}</div>
                          )}
                        </td>
                        <td style={{ padding: "8px 10px" }}>
                          <span style={{
                            color: c.role === "ADMIN" ? "#f0284a" :
                                   c.role === "OPERATOR" ? "#e8a020" : "#64d2ff",
                            fontSize: 8, fontWeight: 700,
                          }}>{c.role}</span>
                        </td>
                        <td style={{ padding: "8px 10px", color: "#4a5f82",
                          fontSize: 8, maxWidth: 100, overflow: "hidden",
                          textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {c.dataset_name || "—"}
                        </td>
                        <td style={{ padding: "8px 10px" }}>
                          <RhoBadge rho={c.current_rho} />
                        </td>
                        <td style={{ padding: "8px 10px" }}>
                          {c.irp_gap_pp != null
                            ? <span style={{ color: "#f0284a", fontSize: 9 }}>+{c.irp_gap_pp}pp</span>
                            : <span style={{ color: "#2a3550" }}>—</span>}
                        </td>
                        <td style={{ padding: "8px 10px", color: "#4a5f82" }}>{c.state_views}</td>
                        <td style={{ padding: "8px 10px", color: "#4a5f82" }}>{c.csv_uploads}</td>
                        <td style={{ padding: "8px 10px", color: "#4a5f82", fontSize: 8,
                          whiteSpace: "nowrap" }}>
                          {c.last_seen ? new Date(c.last_seen).toLocaleDateString() : "never"}
                        </td>
                        <td style={{ padding: "8px 10px" }}>
                          {c.active && !c.key_prefix?.startsWith("[env]") && (
                            <button onClick={() => handleRevoke(c.key_prefix)}
                              disabled={revoking === c.key_prefix}
                              style={{
                                background: "none", border: "1px solid #f0284a40",
                                color: "#f0284a80", fontSize: 8, padding: "3px 8px",
                                cursor: "pointer", borderRadius: 3, fontFamily: "inherit",
                              }}>REVOKE</button>
                          )}
                        </td>
                      </tr>
                    ))}
                    {clients.length === 0 && !loading && (
                      <tr><td colSpan={10} style={{ padding: 24, color: "#2a3550",
                        textAlign: "center", fontSize: 9 }}>
                        No clients yet — provision your first key in the PROVISION tab.
                      </td></tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* ── PROVISION TAB ────────────────────────────────────────────────── */}
          {!loading && tab === "provision" && (
            <div style={{ maxWidth: 480 }}>
              <div style={{ color: "#bfcce8", fontSize: 9, lineHeight: 1.7,
                marginBottom: 20 }}>
                Create a new API key for a client instantly. The key is live in
                memory and persisted to MongoDB — no .env edit, no restart needed.
              </div>

              {[
                { label: "CLIENT NAME", key: "client_name", placeholder: "Porter Logistics" },
                { label: "NOTES (optional)", key: "notes", placeholder: "₹80L/yr deal — Safexpress pilot" },
              ].map(({ label, key, placeholder }) => (
                <div key={key} style={{ marginBottom: 14 }}>
                  <div style={{ color: "#4a5f82", fontSize: 8, letterSpacing: "0.1em",
                    marginBottom: 5 }}>{label}</div>
                  <input value={newClient[key]}
                    onChange={e => setNewClient(s => ({ ...s, [key]: e.target.value }))}
                    placeholder={placeholder}
                    style={{
                      width: "100%", boxSizing: "border-box",
                      background: "#080d1a", border: "1px solid #1b2035",
                      borderRadius: 4, color: "#bfcce8", fontSize: 10,
                      padding: "8px 12px", fontFamily: "inherit", outline: "none",
                    }} />
                </div>
              ))}

              <div style={{ marginBottom: 20 }}>
                <div style={{ color: "#4a5f82", fontSize: 8, letterSpacing: "0.1em",
                  marginBottom: 5 }}>ROLE</div>
                <div style={{ display: "flex", gap: 8 }}>
                  {["OPERATOR", "INTEGRATOR", "READONLY", "ADMIN"].map(r => (
                    <button key={r} onClick={() => setNewClient(s => ({ ...s, role: r }))}
                      style={{
                        padding: "6px 14px", borderRadius: 3, cursor: "pointer",
                        fontFamily: "inherit", fontSize: 8, letterSpacing: "0.1em",
                        background: newClient.role === r ? "#141828" : "none",
                        border: `1px solid ${newClient.role === r ? "#e8a020" : "#1b2035"}`,
                        color: newClient.role === r ? "#e8a020" : "#4a5f82",
                      }}>{r}</button>
                  ))}
                </div>
              </div>

              <button onClick={handleProvision}
                disabled={!newClient.client_name.trim() || provisioning}
                style={{
                  width: "100%", padding: "11px",
                  background: !newClient.client_name.trim() ? "#141828" : "#e8a020",
                  border: "none", borderRadius: 4,
                  color: !newClient.client_name.trim() ? "#4a5f82" : "#06070d",
                  fontFamily: "inherit", fontWeight: 700, fontSize: 11,
                  letterSpacing: "0.12em", cursor: "pointer", marginBottom: 16,
                }}>
                {provisioning ? "PROVISIONING..." : "⚡ PROVISION KEY"}
              </button>

              {provResult && (
                <div style={{ background: "#001a05", border: "1px solid #1ae87a40",
                  borderRadius: 4, padding: 16 }}>
                  <div style={{ color: "#1ae87a", fontWeight: 700, fontSize: 10,
                    marginBottom: 10, letterSpacing: "0.1em" }}>✅ KEY PROVISIONED</div>
                  {[
                    ["Client",  provResult.client_name],
                    ["Role",    provResult.role],
                    ["API Key", provResult.api_key],
                  ].map(([l, v]) => (
                    <div key={l} style={{ display: "flex", gap: 12, marginBottom: 6 }}>
                      <span style={{ color: "#4a5f82", fontSize: 8, minWidth: 50 }}>{l}</span>
                      <span style={{
                        color: l === "API Key" ? "#e8a020" : "#bfcce8",
                        fontSize: l === "API Key" ? 9 : 9,
                        fontWeight: l === "API Key" ? 700 : 400,
                        wordBreak: "break-all",
                      }}>{v}</span>
                    </div>
                  ))}
                  <div style={{ color: "#4a5f82", fontSize: 7, marginTop: 8 }}>
                    ⚠️ Copy this key now — it cannot be retrieved again.
                    Send to client: add header X-API-KEY: {provResult.api_key}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ── USAGE TAB ────────────────────────────────────────────────────── */}
          {!loading && tab === "usage" && (
            <div>
              <div style={{ display: "flex", justifyContent: "space-between",
                alignItems: "center", marginBottom: 16 }}>
                <div style={{ color: "#bfcce8", fontSize: 9 }}>
                  {usage.length} key{usage.length !== 1 ? "s" : ""} with activity
                </div>
                <button onClick={exportUsageCSV} style={{
                  background: "none", border: "1px solid #1b2035",
                  color: "#64d2ff", padding: "5px 14px", cursor: "pointer",
                  fontSize: 9, borderRadius: 3, fontFamily: "inherit",
                  letterSpacing: "0.1em",
                }}>⬇ EXPORT CSV</button>
              </div>

              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 9 }}>
                <thead>
                  <tr style={{ borderBottom: "1px solid #1b2035" }}>
                    {["KEY PREFIX","FIRST SEEN","LAST SEEN","STATE VIEWS","CSV UPLOADS"].map(h => (
                      <th key={h} style={{ color: "#4a5f82", padding: "6px 10px",
                        textAlign: "left", letterSpacing: "0.1em", fontSize: 8 }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {usage.map((u, i) => (
                    <tr key={i} style={{ borderBottom: "1px solid #141828" }}>
                      <td style={{ padding: "8px 10px", color: "#bfcce8" }}>{u.api_key_prefix}</td>
                      <td style={{ padding: "8px 10px", color: "#4a5f82" }}>
                        {u.first_seen ? new Date(u.first_seen).toLocaleDateString() : "—"}
                      </td>
                      <td style={{ padding: "8px 10px", color: "#4a5f82" }}>
                        {u.last_seen ? new Date(u.last_seen).toLocaleDateString() : "never"}
                      </td>
                      <td style={{ padding: "8px 10px", color: "#bfcce8", fontWeight: 700 }}>
                        {u.counts?.state_view || 0}
                      </td>
                      <td style={{ padding: "8px 10px", color: "#e8a020", fontWeight: 700 }}>
                        {u.counts?.csv_upload || 0}
                      </td>
                    </tr>
                  ))}
                  {usage.length === 0 && (
                    <tr><td colSpan={5} style={{ padding: 24, color: "#2a3550",
                      textAlign: "center", fontSize: 9 }}>
                      No usage data yet — clients generate data on first API call.
                    </td></tr>
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
