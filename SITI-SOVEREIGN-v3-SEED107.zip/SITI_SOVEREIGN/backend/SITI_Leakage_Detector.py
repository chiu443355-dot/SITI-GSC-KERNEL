"""
╔══════════════════════════════════════════════════════════════════════╗
║  SITI Intelligence — Leakage Detector                               ║
║  Forensic Engine v2.0 · Zero-Crash · NaN-Safe · Fuzzy Column Map   ║
║                                                                      ║
║  What this finds:                                                    ║
║  1. Inverse Reliability Paradox (IRP) — where higher-priority       ║
║     shipments fail at a HIGHER rate than lower-priority ones         ║
║  2. Volume-Profit Inversion — where higher volume leads to          ║
║     lower net profit margin (the real 'Inverse Reliability')         ║
║  3. Cascade Indicators — hubs whose failures correlate in time      ║
║  4. Temporal Blind Spots — windows your BI tools miss               ║
║  5. Revenue Leakage — crore-accurate annual exposure estimate        ║
║                                                                      ║
║  Input:  ANY logistics CSV — column names auto-mapped via fuzzy     ║
║  Output: LeakageReport object + printable summary                   ║
╚══════════════════════════════════════════════════════════════════════╝
"""

import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
from typing import Optional
import warnings
warnings.filterwarnings('ignore')


# ─── FUZZY COLUMN MAPPER ──────────────────────────────────────────────────────
# Maps any company's CSV column names to SITI's internal schema.
# No crash if a column is missing — graceful degradation.

COLUMN_ALIASES = {
    "on_time": [
        "reached.on.time_y.n", "reached_on_time", "on_time", "delivered_on_time",
        "sla_met", "sla_status", "delivery_status", "status", "is_on_time",
        "delivered", "success", "fulfillment_status", "order_status",
        "otd", "on_time_delivery", "tat_met", "within_tat",
        "is_delivered", "delivery_flag", "delivery_success",
    ],
    "importance": [
        # Generic priority/tier columns
        "product_importance", "priority", "shipment_priority", "service_type",
        "product_priority", "order_priority", "category", "tier", "sla_tier",
        "service_level", "shipment_type", "product_type", "customer_tier",
        "urgency", "importance", "order_type", "consignment_type",
        # Shiprocket — the column they actually use
        "shipping_service", "service_name", "carrier_service", "courier_service",
        "delivery_type", "fulfillment_type", "shipment_mode", "service_code",
        "awb_service_type", "shipping_mode", "courier_type", "service_category",
        "courier_name",
        # Porter
        "dispatch_type", "delivery_mode", "order_category", "booking_type",
        # Safexpress
        "cargo_type", "cold_chain", "pharma_flag", "freight_type", "shipment_class",
        # Delhivery
        "product_category", "fc_type", "zone", "order_type_code",
        # BlueDart
        "mode_of_shipment", "service_mode", "dart_service",
    ],
    "hub": [
        "warehouse_block", "hub", "hub_name", "origin_hub", "dispatch_hub",
        "facility", "warehouse", "location", "origin", "source_hub",
        "dispatch_centre", "processing_centre", "fc", "fulfillment_center",
        "warehouse_code", "hub_code", "facility_code",
        # Shiprocket
        "dispatch_facility", "pickup_location", "origin_facility",
        "source_facility", "dispatch_centre_code", "fulfillment_centre",
        # Porter
        "pickup_hub", "origin_city", "source_location",
        # Safexpress
        "origin_branch", "dispatch_branch", "source_branch",
    ],
    "weight": [
        "weight_in_gms", "weight", "gross_weight", "shipment_weight",
        "weight_grams", "weight_kg", "package_weight", "item_weight",
        "shipment_weight_g", "dead_weight", "chargeable_weight",
        "weight_in_kg", "volumetric_weight",
    ],
    "cost_of_product": [
        "cost_of_the_product", "cost_of_product", "product_cost",
        "order_value", "shipment_value", "gmv", "order_amount",
        "declared_value", "invoice_value", "consignment_value",
        "order_value_inr", "item_value", "cod_amount", "invoice_amount",
        "product_value", "declared_value_inr", "package_value",
    ],
    "discount": [
        "discount_offered", "discount", "promo_discount", "offer_discount",
        "seller_discount", "coupon_discount", "cashback_amount",
        "discount_amount", "promotional_discount",
    ],
    "timestamp": [
        "created_at", "order_date", "shipment_date", "dispatch_date",
        "booking_date", "date", "timestamp", "order_time", "pickup_date",
        "order_created_at", "booking_time", "pickup_time", "dispatched_at",
        "order_placed_at", "shipment_created_at",
    ]
}

HIGH_IMPORTANCE_TOKENS = {
    # Generic high-priority words (must be WHOLE TOKEN after splitting by _)
    'high', 'priority', 'express', 'urgent', 'critical', 'premium',
    'immediate', 'overnight', 'instant',
    # Air/speed tokens
    'air', 'dart_plus_air', 'domestic_priority',
    # Compound service names — matched as full string OR after split
    'air_express', 'hyperlocal', 'surface_pro', 'hyperlocal_same_day',
    'same_day', 'sameday', 'same_day_delivery', 'next_day', 'nextday',
    'express_delivery', 'priority_express', 'air_cargo',
    # Porter
    'b2b_priority',
    # Safexpress
    'temperature_controlled', 'pharma', 'cold_chain', 'sensitive',
    # Numeric — ONLY exact '1' after splitting, not substring
    # (handled separately in classify())
}

def fuzzy_map_columns(df: pd.DataFrame) -> dict:
    """
    Maps DataFrame columns to SITI schema using fuzzy matching.
    Returns dict: {siti_name: actual_column_name or None}
    Never crashes — missing columns return None.
    """
    mapping = {k: None for k in COLUMN_ALIASES}
    df_cols_lower = {col.lower().strip().replace(' ', '_'): col for col in df.columns}

    for siti_name, aliases in COLUMN_ALIASES.items():
        for alias in aliases:
            if alias in df_cols_lower:
                mapping[siti_name] = df_cols_lower[alias]
                break
        # If no exact match, try partial match
        if mapping[siti_name] is None:
            for alias in aliases:
                for col_lower, col_orig in df_cols_lower.items():
                    if alias in col_lower or col_lower in alias:
                        mapping[siti_name] = col_orig
                        break
                if mapping[siti_name]:
                    break

    return mapping


def normalize_on_time(series: pd.Series) -> pd.Series:
    """
    Converts any on-time representation to 1=on_time, 0=late.
    Handles: Y/N, Yes/No, 1/0, True/False, 'delivered'/'failed', etc.
    NaN → -1 (unknown, excluded from analysis)
    """
    s = series.copy()
    if s.dtype in [np.int64, np.float64]:
        s = s.fillna(-1).astype(int)
        return s.clip(-1, 1)

    s = s.astype(str).str.strip().str.lower()
    mapping = {
        'y': 1, 'yes': 1, '1': 1, 'true': 1, 'delivered': 1,
        'on_time': 1, 'on-time': 1, 'success': 1, 'fulfilled': 1,
        'met': 1, 'within_tat': 1,
        'n': 0, 'no': 0, '0': 0, 'false': 0, 'delayed': 0,
        'late': 0, 'failed': 0, 'breach': 0, 'missed': 0,
        'not_met': 0, 'nan': -1, 'none': -1, '': -1
    }
    return s.map(lambda x: mapping.get(x, -1))


def classify_importance(series: pd.Series) -> pd.Series:
    """
    Classifies importance as 'High' or 'Low'.
    Handles any categorical or numeric priority field.
    NaN → 'Low' (conservative assumption)
    """
    s = series.fillna('unknown').astype(str).str.lower().str.strip()

    def classify(val):
        # Split compound values into individual tokens: 'air_express' → {'air','express','air_express'}
        # This prevents substring false positives (e.g. 'a' matching 'standard')
        val_clean = val.replace('-', '_').replace(' ', '_')
        parts = set(val_clean.split('_'))
        parts.add(val_clean)   # also check full string (e.g. 'air_express' as whole)
        if parts & HIGH_IMPORTANCE_TOKENS:
            return 'High'
        # Numeric priority: only exact '1' or 'p1' → High
        if val_clean in ('1', 'p1', 'a1', '01'):
            return 'High'
        try:
            n = float(val)
            return 'High' if n <= 1.5 else 'Low'
        except ValueError:
            pass
        return 'Low'

    return s.map(classify)


# ─── LEAKAGE DETECTOR ────────────────────────────────────────────────────────

class SITILeakageDetector:
    """
    Full forensic analysis engine.
    Feed it ANY logistics DataFrame — it maps columns and finds the money.
    """

    def __init__(self, company_name: str = "Company"):
        self.company_name = company_name
        self.report = {}
        self._df = None
        self._mapping = {}

    def load_csv(self, path: str) -> 'SITILeakageDetector':
        """Load from file path. Auto-detects encoding and separator."""
        for enc in ['utf-8', 'latin-1', 'cp1252']:
            for sep in [',', ';', '\t', '|']:
                try:
                    df = pd.read_csv(path, encoding=enc, sep=sep, low_memory=False)
                    if len(df.columns) > 2:
                        self._df = df
                        print(f"[SITI] Loaded: {len(df):,} rows × {len(df.columns)} cols "
                              f"(enc={enc}, sep='{sep}')")
                        return self
                except Exception:
                    continue
        raise ValueError(f"Cannot parse CSV: {path}")

    def load_dataframe(self, df: pd.DataFrame) -> 'SITILeakageDetector':
        self._df = df.copy()
        return self

    def analyse(self) -> dict:
        """Run full forensic analysis. Returns report dict."""
        if self._df is None:
            raise RuntimeError("No data loaded. Call load_csv() or load_dataframe() first.")

        df = self._df.copy()
        self._mapping = fuzzy_map_columns(df)

        print(f"\n[SITI] Column mapping:")
        for k, v in self._mapping.items():
            status = "✅" if v else "⚠️ "
            print(f"  {status} {k:20s} → {v or 'NOT FOUND (graceful skip)'}")

        report = {
            "company": self.company_name,
            "analysis_timestamp": datetime.utcnow().isoformat(),
            "total_records": len(df),
            "columns_mapped": sum(1 for v in self._mapping.values() if v),
            "irp": {},
            "volume_profit_inversion": {},
            "hub_analysis": {},
            "cascade_indicators": {},
            "temporal_blindspots": {},
            "leakage_summary": {}
        }

        # ── 1. CORE IRP ANALYSIS ─────────────────────────────────────────────
        report["irp"] = self._irp_analysis(df)

        # ── 2. VOLUME → PROFIT INVERSION ─────────────────────────────────────
        report["volume_profit_inversion"] = self._volume_profit_inversion(df)

        # ── 3. HUB-LEVEL IRP ─────────────────────────────────────────────────
        report["hub_analysis"] = self._hub_analysis(df)

        # ── 4. CASCADE INDICATORS ────────────────────────────────────────────
        report["cascade_indicators"] = self._cascade_analysis(df)

        # ── 5. TEMPORAL BLIND SPOTS ──────────────────────────────────────────
        report["temporal_blindspots"] = self._temporal_analysis(df)

        # ── 6. LEAKAGE SUMMARY ───────────────────────────────────────────────
        report["leakage_summary"] = self._calculate_leakage(df, report)

        # ── JSON-safe: convert all numpy scalars to Python natives ──────────────
        import json
        def _sanitize(obj):
            if isinstance(obj, dict):  return {k: _sanitize(v) for k,v in obj.items()}
            if isinstance(obj, list):  return [_sanitize(v) for v in obj]
            if isinstance(obj, (bool,)): return bool(obj)  # must be before int check
            try:
                import numpy as np
                if isinstance(obj, np.bool_):    return bool(obj)
                if isinstance(obj, np.integer):  return int(obj)
                if isinstance(obj, np.floating): return float(obj)
            except ImportError: pass
            return obj
        report = _sanitize(report)
        self.report = report
        return report

    def _irp_analysis(self, df: pd.DataFrame) -> dict:
        """Inverse Reliability Paradox — core detection."""
        on_time_col = self._mapping["on_time"]
        imp_col     = self._mapping["importance"]

        if not on_time_col or not imp_col:
            return {"status": "SKIPPED", "reason": f"Missing: on_time={on_time_col}, importance={imp_col}"}

        ot  = normalize_on_time(df[on_time_col])
        imp = classify_importance(df[imp_col])

        # Exclude unknowns
        mask_valid = ot >= 0
        ot_valid   = ot[mask_valid]
        imp_valid  = imp[mask_valid]

        high_mask = imp_valid == 'High'
        low_mask  = imp_valid == 'Low'

        if high_mask.sum() < 10 or low_mask.sum() < 10:
            return {"status": "INSUFFICIENT_DATA",
                    "high_count": int(high_mask.sum()),
                    "low_count": int(low_mask.sum())}

        high_late = (ot_valid[high_mask] == 0).mean()
        low_late  = (ot_valid[low_mask]  == 0).mean()
        irp_gap   = high_late - low_late
        irp_active = irp_gap > 0.005  # 0.5pp threshold for significance

        # Bootstrap confidence interval on IRP gap
        gaps = []
        rng = np.random.default_rng(42)
        for _ in range(500):
            hi_s = rng.choice(ot_valid[high_mask].values, size=min(len(ot_valid[high_mask]), 500))
            lo_s = rng.choice(ot_valid[low_mask].values,  size=min(len(ot_valid[low_mask]),  500))
            gaps.append((hi_s == 0).mean() - (lo_s == 0).mean())
        ci_lo, ci_hi = np.percentile(gaps, [5, 95])

        return {
            "status": "ACTIVE" if irp_active else "NOT_DETECTED",
            "high_importance_late_pct": round(float(high_late) * 100, 2),
            "low_importance_late_pct":  round(float(low_late)  * 100, 2),
            "irp_gap_pp":               round(float(irp_gap)   * 100, 2),
            "confidence_interval_95":   [round(float(ci_lo) * 100, 2), round(float(ci_hi) * 100, 2)],
            "high_count":               int(high_mask.sum()),
            "low_count":                int(low_mask.sum()),
            "interpretation": (
                f"High-priority shipments fail {abs(irp_gap)*100:.1f}pp MORE than low-priority. "
                f"IRP is ACTIVE and costing revenue." if irp_active else
                "No significant IRP detected in this dataset."
            )
        }

    def _volume_profit_inversion(self, df: pd.DataFrame) -> dict:
        """
        Volume-Profit Inversion: as volume increases per hub/period,
        does net margin (value - discount - failure cost) decrease?
        This is 'Inverse Reliability' at the business level.
        """
        hub_col  = self._mapping["hub"]
        cost_col = self._mapping["cost_of_product"]
        disc_col = self._mapping["discount"]
        ot_col   = self._mapping["on_time"]

        if not hub_col or not cost_col or not ot_col:
            return {"status": "SKIPPED",
                    "reason": "Need hub + cost + on_time columns for volume-profit analysis"}

        ot = normalize_on_time(df[ot_col])
        df2 = df.copy()
        df2['_ot'] = ot
        df2['_cost'] = pd.to_numeric(df[cost_col], errors='coerce').fillna(0)
        df2['_disc'] = pd.to_numeric(df[disc_col], errors='coerce').fillna(0) if disc_col else 0
        # Assume 15% leakage cost per failed shipment (conservative)
        LEAKAGE_RATE = 0.15
        df2['_net'] = df2['_cost'] - df2['_disc'] - df2.apply(
            lambda r: r['_cost'] * LEAKAGE_RATE if r['_ot'] == 0 else 0, axis=1
        )

        hub_stats = df2.groupby(hub_col).agg(
            volume    = ('_ot', 'count'),
            avg_net   = ('_net', 'mean'),
            late_rate = ('_ot', lambda x: (x == 0).mean())
        ).reset_index()

        # Correlation: volume vs avg_net_margin
        if len(hub_stats) >= 3:
            corr = np.corrcoef(hub_stats['volume'], hub_stats['avg_net'])[0, 1]
            inversion_active = corr < -0.2  # negative correlation = inversion
        else:
            corr = float('nan')
            inversion_active = False

        worst_hubs = hub_stats.nsmallest(3, 'avg_net')[hub_col].tolist()

        return {
            "status": "ACTIVE" if inversion_active else "MARGINAL",
            "volume_profit_correlation": round(corr, 3) if not np.isnan(corr) else "insufficient_data",
            "inversion_active": bool(inversion_active),
            "worst_hubs_by_margin": worst_hubs,
            "hub_count": len(hub_stats),
            "interpretation": (
                f"Volume-Profit Inversion DETECTED (correlation={corr:.2f}). "
                f"Higher volume hubs are generating lower net margins."
                if inversion_active else
                f"No strong volume-profit inversion detected (correlation={corr:.2f})."
            )
        }

    def _hub_analysis(self, df: pd.DataFrame) -> dict:
        """Per-hub IRP breakdown."""
        hub_col = self._mapping["hub"]
        ot_col  = self._mapping["on_time"]
        imp_col = self._mapping["importance"]

        if not hub_col or not ot_col or not imp_col:
            return {"status": "SKIPPED"}

        ot  = normalize_on_time(df[ot_col])
        imp = classify_importance(df[imp_col])
        valid = ot >= 0

        df2 = df.copy()
        df2['_ot']  = ot
        df2['_imp'] = imp
        df2 = df2[valid]

        results = []
        for hub, grp in df2.groupby(hub_col):
            hi = grp[grp['_imp'] == 'High']
            lo = grp[grp['_imp'] == 'Low']
            if len(hi) < 5 or len(lo) < 5:
                continue
            hl = (hi['_ot'] == 0).mean()
            ll = (lo['_ot'] == 0).mean()
            gap = hl - ll
            results.append({
                "hub":          str(hub),
                "volume":       len(grp),
                "high_late_pct": round(float(hl) * 100, 2),
                "low_late_pct":  round(float(ll) * 100, 2),
                "irp_gap_pp":   round(float(gap) * 100, 2),
                "irp_active":   bool(gap > 0.005)
            })

        results.sort(key=lambda x: x["irp_gap_pp"], reverse=True)

        return {
            "status":          "COMPLETE",
            "hubs_analysed":   len(results),
            "hubs_with_irp":   sum(1 for r in results if r["irp_active"]),
            "worst_hub":       results[0] if results else None,
            "hub_details":     results[:10]  # top 10
        }

    def _cascade_analysis(self, df: pd.DataFrame) -> dict:
        """
        Cascade indicator: if hub A fails more on dates when hub B also fails,
        they are cascade-correlated.
        """
        hub_col  = self._mapping["hub"]
        ot_col   = self._mapping["on_time"]
        ts_col   = self._mapping["timestamp"]

        if not hub_col or not ot_col or not ts_col:
            return {"status": "SKIPPED", "reason": "Need hub + on_time + timestamp"}

        df2 = df.copy()
        df2['_ot'] = normalize_on_time(df[ot_col])
        df2['_ts'] = pd.to_datetime(df[ts_col], errors='coerce')
        df2 = df2[df2['_ot'] >= 0].dropna(subset=['_ts'])

        if len(df2) < 100:
            return {"status": "INSUFFICIENT_DATA"}

        df2['_date'] = df2['_ts'].dt.date
        daily = df2.groupby([hub_col, '_date'])['_ot'].apply(
            lambda x: (x == 0).mean()
        ).unstack(level=0).fillna(0)

        if daily.shape[1] < 2:
            return {"status": "INSUFFICIENT_DATA", "reason": "Need 2+ hubs with timestamps"}

        # Pairwise correlation of daily failure rates
        corr_matrix = daily.corr()
        cascade_pairs = []
        hubs = corr_matrix.columns.tolist()
        for i in range(len(hubs)):
            for j in range(i+1, len(hubs)):
                c = corr_matrix.iloc[i, j]
                if c > 0.35:  # meaningful correlation threshold
                    cascade_pairs.append({
                        "hub_a": str(hubs[i]),
                        "hub_b": str(hubs[j]),
                        "correlation": round(c, 3),
                        "risk_level": "HIGH" if c > 0.6 else "MEDIUM"
                    })
        cascade_pairs.sort(key=lambda x: x["correlation"], reverse=True)

        return {
            "status":           "COMPLETE",
            "cascade_pairs":    cascade_pairs[:5],
            "total_correlated": len(cascade_pairs),
            "interpretation": (
                f"{len(cascade_pairs)} hub pair(s) show cascade correlation. "
                f"A failure in one hub is predictive of failure in the correlated hub."
                if cascade_pairs else
                "No significant cascade correlation detected."
            )
        }

    def _temporal_analysis(self, df: pd.DataFrame) -> dict:
        """Find time windows with disproportionate failure rates — the 2AM-4AM problem."""
        ot_col = self._mapping["on_time"]
        ts_col = self._mapping["timestamp"]

        if not ot_col or not ts_col:
            return {"status": "SKIPPED"}

        df2 = df.copy()
        df2['_ot'] = normalize_on_time(df[ot_col])
        df2['_ts'] = pd.to_datetime(df[ts_col], errors='coerce')
        df2 = df2[df2['_ot'] >= 0].dropna(subset=['_ts'])

        if len(df2) < 200:
            return {"status": "INSUFFICIENT_DATA"}

        df2['_hour'] = df2['_ts'].dt.hour
        hourly = df2.groupby('_hour')['_ot'].agg(
            count='count',
            late_rate=lambda x: (x == 0).mean()
        ).reset_index()

        overall_late = (df2['_ot'] == 0).mean()
        hourly['excess_late'] = hourly['late_rate'] - overall_late
        blind_spots = hourly[hourly['excess_late'] > 0.02].sort_values('excess_late', ascending=False)

        worst_windows = []
        for _, row in blind_spots.iterrows():
            if row['count'] >= 20:
                worst_windows.append({
                    "hour":         int(row['_hour']),
                    "late_rate_pct": round(row['late_rate'] * 100, 2),
                    "excess_pp":    round(row['excess_late'] * 100, 2),
                    "volume":       int(row['count'])
                })

        return {
            "status":          "COMPLETE",
            "overall_late_pct": round(overall_late * 100, 2),
            "blind_spot_windows": worst_windows[:5],
            "interpretation": (
                f"Found {len(worst_windows)} time window(s) with disproportionate failure rates."
                if worst_windows else
                "No significant temporal blind spots detected."
            )
        }

    def _calculate_leakage(self, df: pd.DataFrame, report: dict) -> dict:
        """
        Annual revenue leakage estimate in crore (INR).
        Uses IRP gap × high-priority volume × avg shipment value.
        """
        irp = report.get("irp", {})
        if irp.get("status") != "ACTIVE":
            return {"status": "IRP_NOT_ACTIVE", "annual_leakage_crore": 0}

        cost_col = self._mapping["cost_of_product"]
        imp_col  = self._mapping["importance"]
        ot_col   = self._mapping["on_time"]

        irp_gap_frac = irp["irp_gap_pp"] / 100

        # Estimate avg cost per failure
        if cost_col:
            avg_cost = pd.to_numeric(df[cost_col], errors='coerce').dropna()
            avg_cost = avg_cost[avg_cost > 0].mean() if len(avg_cost) > 0 else 400.0
        else:
            avg_cost = 400.0  # conservative default for Indian logistics

        if imp_col:
            high_count = (classify_importance(df[imp_col]) == 'High').sum()
        else:
            high_count = len(df) * 0.18  # 18% high-priority default

        # Auto-detect actual date range from timestamp column
        # Falls back to 90 days if no timestamp or range < 7 days
        ts_col_ann = self._mapping.get("timestamp")
        data_days = 90  # safe default
        if ts_col_ann:
            try:
                ts_series = pd.to_datetime(df[ts_col_ann], errors='coerce').dropna()
                if len(ts_series) > 0:
                    span = (ts_series.max() - ts_series.min()).days
                    if span >= 7:
                        data_days = max(span, 1)
            except Exception:
                pass
        annual_high = high_count / data_days * 365
        annual_leakage = annual_high * irp_gap_frac * avg_cost

        # 15% leakage threshold check
        leakage_pct = irp_gap_frac * 100
        threshold_breach = leakage_pct >= 15.0

        return {
            "status":               "CALCULATED",
            "irp_gap_pp":           irp["irp_gap_pp"],
            "avg_cost_per_failure": round(float(avg_cost), 2),
            "high_priority_volume": int(high_count),
            "annual_high_priority": int(annual_high),
            "annual_leakage_inr":   round(annual_leakage, 0),
            "annual_leakage_lakh":  round(annual_leakage / 1e5, 1),
            "annual_leakage_crore": round(annual_leakage / 1e7, 2),
            "threshold_15pct_breach": bool(threshold_breach),
            "at_risk_revenue_flag": "CRITICAL" if annual_leakage > 1e7 else
                                    "HIGH"     if annual_leakage > 5e5 else "MODERATE"
        }

    def print_report(self):
        """Human-readable forensic report."""
        r = self.report
        if not r:
            print("No analysis run yet. Call .analyse() first.")
            return

        print("\n" + "═" * 65)
        print(f"  SITI INTELLIGENCE — FORENSIC LEAKAGE REPORT")
        print(f"  Company: {r['company']}")
        print(f"  Records: {r['total_records']:,} | Columns Mapped: {r['columns_mapped']}/7")
        print("═" * 65)

        # IRP
        irp = r.get("irp", {})
        print(f"\n  [1] INVERSE RELIABILITY PARADOX (IRP)")
        if irp.get("status") == "ACTIVE":
            print(f"      Status:       🔴 ACTIVE")
            print(f"      High-Imp Late: {irp['high_importance_late_pct']}%")
            print(f"      Low-Imp Late:  {irp['low_importance_late_pct']}%")
            print(f"      IRP Gap:       +{irp['irp_gap_pp']}pp")
            print(f"      95% CI:        [{irp['confidence_interval_95'][0]}, {irp['confidence_interval_95'][1]}]pp")
        else:
            print(f"      Status: {irp.get('status','UNKNOWN')}")

        # Leakage
        ls = r.get("leakage_summary", {})
        print(f"\n  [2] REVENUE LEAKAGE ESTIMATE")
        if ls.get("status") == "CALCULATED":
            print(f"      Annual Exposure:  ₹{ls['annual_leakage_crore']} Crore / year")
            print(f"      Risk Flag:        {ls['at_risk_revenue_flag']}")
            print(f"      15% Threshold:    {'🔴 BREACH' if ls['threshold_15pct_breach'] else '✅ WITHIN'}")
            print(f"      Cost per Failure: ₹{ls['avg_cost_per_failure']:.0f}")
        else:
            print(f"      Status: {ls.get('status','UNKNOWN')}")

        # Hub Analysis
        ha = r.get("hub_analysis", {})
        print(f"\n  [3] HUB-LEVEL IRP")
        if ha.get("status") == "COMPLETE":
            print(f"      Hubs Analysed:   {ha['hubs_analysed']}")
            print(f"      Hubs with IRP:   {ha['hubs_with_irp']}")
            if ha.get("worst_hub"):
                wh = ha["worst_hub"]
                print(f"      Worst Hub:       {wh['hub']} (+{wh['irp_gap_pp']}pp IRP gap, vol={wh['volume']:,})")

        # Volume-Profit Inversion
        vp = r.get("volume_profit_inversion", {})
        print(f"\n  [4] VOLUME-PROFIT INVERSION")
        if vp.get("status") in ["ACTIVE", "MARGINAL"]:
            print(f"      Status:          {'🔴 ACTIVE' if vp['inversion_active'] else '🟡 MARGINAL'}")
            print(f"      Corr (vol/net):  {vp['volume_profit_correlation']}")
            print(f"      Worst Hubs:      {', '.join(vp['worst_hubs_by_margin'][:3])}")

        # Cascade
        cs = r.get("cascade_indicators", {})
        print(f"\n  [5] CASCADE INDICATORS")
        if cs.get("status") == "COMPLETE":
            if cs["cascade_pairs"]:
                print(f"      🔴 {cs['total_correlated']} cascade pair(s) detected:")
                for p in cs["cascade_pairs"][:3]:
                    print(f"         {p['hub_a']} ↔ {p['hub_b']}  corr={p['correlation']} [{p['risk_level']}]")
            else:
                print("      ✅ No cascade correlation detected")

        # Temporal
        tb = r.get("temporal_blindspots", {})
        print(f"\n  [6] TEMPORAL BLIND SPOTS")
        if tb.get("status") == "COMPLETE" and tb.get("blind_spot_windows"):
            print(f"      Overall late rate: {tb['overall_late_pct']}%")
            for w in tb["blind_spot_windows"][:3]:
                print(f"      ⚠️  {w['hour']:02d}:00–{w['hour']+1:02d}:00  "
                      f"late={w['late_rate_pct']}%  (+{w['excess_pp']}pp excess)  vol={w['volume']}")
        else:
            print(f"      Status: {tb.get('status','SKIPPED')}")

        print("\n" + "═" * 65)


# ─── DEMO / CLI RUNNER ───────────────────────────────────────────────────────

def run_demo():
    """
    Demo mode: generates synthetic data mimicking a real Porter/Safexpress CSV
    and runs the full analysis. Use this to test before you have their actual data.
    """
    print("[SITI] Running demo with synthetic Porter-style data...")
    rng = np.random.default_rng(42)
    N = 5000

    hubs       = rng.choice(['BOM_Andheri','DEL_Rohini','BLR_Hebbal','MUM_Thane','DEL_Noida'], N)
    imp        = rng.choice(['Priority_Express','Smart_Ground','Economy_Ship'], N, p=[0.22,0.35,0.43])
    late_prob  = np.where(
        np.isin(imp, ['Priority_Express']), 0.155,
        np.where(np.isin(imp, ['Smart_Ground']), 0.108, 0.089)
    )
    on_time    = (rng.uniform(0, 1, N) > late_prob).astype(int)
    value      = rng.integers(200, 2000, N)
    discount   = (value * rng.uniform(0.02, 0.12, N)).astype(int)
    dates      = pd.date_range('2024-01-01', periods=N, freq='2h')[:N]

    df = pd.DataFrame({
        'Warehouse_block':    hubs,
        'Product_importance': imp,
        'Reached.on.Time_Y.N': on_time,
        'Cost_of_the_Product': value,
        'Discount_offered':   discount,
        'Order_Date':         dates
    })

    detector = SITILeakageDetector("Porter [Demo]")
    detector.load_dataframe(df)
    report = detector.analyse()
    detector.print_report()
    return report


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        csv_path = sys.argv[1]
        company  = sys.argv[2] if len(sys.argv) > 2 else Path(csv_path).stem
        print(f"[SITI] Analysing: {csv_path}")
        detector = SITILeakageDetector(company)
        detector.load_csv(csv_path)
        report = detector.analyse()
        detector.print_report()
    else:
        run_demo()
