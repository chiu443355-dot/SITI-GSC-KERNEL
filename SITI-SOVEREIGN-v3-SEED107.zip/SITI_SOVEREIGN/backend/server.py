# ═══════════════════════════════════════════════════════════════════════════════
# SITI INTELLIGENCE — MIMI Kernel
# Production Build — Zero Errors · Industrial Dominance
# Protocol: Zero Errors · Industrial Dominance
# Case #02028317 · Wankhede (2026) IEEE
# ═══════════════════════════════════════════════════════════════════════════════

from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException, Header, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel
import os
import re
import logging
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from pathlib import Path
from typing import Optional, List
import io
from datetime import datetime, timezone
from baseline_data import build_forensic_baseline
import joblib

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client    = AsyncIOMotorClient(mongo_url)
db        = client[os.environ['DB_NAME']]

# MongoDB collections — actually used
telemetry_col    = db["telemetry_logs"]
alerts_col       = db["alerts"]
diversion_col    = db["diversion_events"]
api_log_col      = db["api_access_logs"]
decisions_col    = db["human_decisions"]    # Human-in-the-loop audit trail
settings_col     = db["user_settings"]      # Per-deployment cost configuration
network_col      = db["network_config"]       # dynamic hub topology
metrics_col      = db["global_metrics"]        # atomic worker-safe counters
hub_settings_col = db["hub_settings"]           # μ and per-hub capacity — survives restart
system_logs_col  = db["system_logs"]            # remote error visibility — no SSH needed
api_keys_col     = db["api_keys"]               # dynamic key provisioning — admin CRUD
usage_col        = db["usage_analytics"]        # per-key usage stats for renewal convos

# debug=False enforced at uvicorn/gunicorn launch
# Run: uvicorn server:app --host 0.0.0.0 --port 8000 --workers 1
# Production: gunicorn server:app -k uvicorn.workers.UvicornWorker --workers 2
app        = FastAPI(title="SITI Intelligence API", version="1.0.0")
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# ─── CONSTANTS ────────────────────────────────────────────────────────────────
# T_OPERATIONAL and topology now defined in the Dynamic Topology section below
# STRICT API KEY — NO HARDCODED FALLBACK
_raw_keys = os.getenv("API_KEYS", "")
if not _raw_keys.strip():
    raise RuntimeError(
        "FATAL: API_KEYS environment variable is not set. "
        "Generate a key: python3 -c \"import secrets; print(secrets.token_hex(32))\" "
        "then set API_KEYS=<key> in your .env file."
    )
VALID_API_KEYS: set = {k.strip() for k in _raw_keys.split(",") if k.strip()}

# ─── ROLE-BASED ACCESS CONTROL ────────────────────────────────────────────────
# .env key format:  API_KEYS=key1:ADMIN,key2:OPERATOR,key3:INTEGRATOR,key4:READONLY
#
# ROLES:
#   ADMIN       — full access: topology CRUD, decisions, settings, all reads
#   OPERATOR    — approve/dismiss diversions, read all; cannot delete hubs
#   INTEGRATOR  — POST to v1/intercept and GET state only; cannot mutate topology
#   READONLY    — GET endpoints only; no writes of any kind
#
# Keys without a :ROLE suffix default to READONLY (safest default).
# Example .env entry:
#   API_KEYS=siti-admin-abc123:ADMIN,erp-xyz789:INTEGRATOR,ops-def456:OPERATOR

_VALID_ROLES  = {"ADMIN", "OPERATOR", "INTEGRATOR", "READONLY"}
_DEFAULT_ROLE = "READONLY"

# Parse {key: role} from comma-separated KEY:ROLE entries
_KEY_ROLE_MAP: dict = {}
for _entry in _raw_keys.split(","):
    _entry = _entry.strip()
    if not _entry:
        continue
    if ":" in _entry:
        _k, _r = _entry.rsplit(":", 1)
        _KEY_ROLE_MAP[_k.strip()] = _r.strip().upper() if _r.strip().upper() in _VALID_ROLES else _DEFAULT_ROLE
    else:
        _KEY_ROLE_MAP[_entry] = _DEFAULT_ROLE   # legacy key, no role → READONLY

# Rebuild VALID_API_KEYS from parsed map (supports both old and new format)
VALID_API_KEYS = set(_KEY_ROLE_MAP.keys())

# ─── SITI: HIGH-THROUGHPUT ASYNC BUFFER (1,000 WPS) ────────────────────────────
# Upgraded for Blue Dart stress load:
#   • _BUFFER_MAX = 100 records (10x previous) — 1k WPS sustained
#   • _BUFFER_FLUSH = 3.0s — faster drain cycle
#   • Flush is fire-and-forget create_task — never blocks inbound
#   • insert_many(ordered=False) — max MongoDB throughput
import asyncio as _asyncio
_telemetry_buffer: list = []
_BUFFER_MAX   = 100      # flush every 100 records — handles 1k WPS
_BUFFER_FLUSH = 3.0      # drain every 3s
_buffer_lock  = None     # initialised inside event loop at startup

# ─── SITI: REMOTE ERROR VISIBILITY ─────────────────────────────────────────────
# Logs errors to MongoDB system_logs — debug without SSH.
# Usage: asyncio.create_task(log_system_error("context", e)) — fire-and-forget.

async def log_system_error(context: str, error: Exception, severity: str = "ERROR") -> None:
    """
    Persist exception to system_logs_col for remote diagnosis.
    Fire-and-forget via create_task — never blocks the response path.
    Visible at GET /system/logs (ADMIN only).
    """
    try:
        await system_logs_col.insert_one({
            "timestamp":  datetime.now(timezone.utc),
            "severity":   severity,
            "context":    context,
            "error_type": type(error).__name__,
            "error_msg":  str(error),
            "version":    "SITI Intelligence",
        })
    except Exception as _log_err:
        import sys
        print(f"[SITI] log_system_error itself failed: {_log_err}", file=sys.stderr)


async def _flush_telemetry_buffer():
    """Drain in-memory buffer to MongoDB — single insert_many round-trip."""
    global _telemetry_buffer
    if not _telemetry_buffer or _buffer_lock is None:
        return
    async with _buffer_lock:
        batch = _telemetry_buffer[:]
        _telemetry_buffer = []
    if batch:
        try:
            await telemetry_col.insert_many(batch, ordered=False)
            logger.debug(f"[BUFFER] Flushed {len(batch)} docs")
        except Exception as e:
            logger.warning(f"[BUFFER] Flush failed — {len(batch)} docs dropped: {e}")
            _asyncio.create_task(log_system_error("buffer_flush", e, "WARNING"))

async def _telemetry_flush_loop():
    """Background drain loop — 3s cycle for 1k WPS sustained throughput."""
    while True:
        await _asyncio.sleep(_BUFFER_FLUSH)
        await _flush_telemetry_buffer()

# ─── SITI: DYNAMIC TOPOLOGY ─────────────────────────────────────────────────────
# HUB_BLOCK_MAP is no longer a hardcoded constant.
# _hub_block_map is loaded from MongoDB network_config at startup.
# Any hub added to the DB is hot-reloaded immediately via POST /api/network/hubs.
T_OPERATIONAL = 36.0   # hours

_hub_block_map: dict = {}   # populated at startup from MongoDB
_all_blocks:    list = []   # flattened sorted list of all active blocks

def _get_hub_block_map() -> dict:
    return _hub_block_map

def _get_hub_blocks(hub_name: str) -> list:
    return _hub_block_map.get(hub_name, [])

DEFAULT_TOPOLOGY = [
    {"_id": "Alpha", "blocks": ["A", "B"], "mu": 150.0, "order": 1},
    {"_id": "Beta",  "blocks": ["C", "D"], "mu": 150.0, "order": 2},
    {"_id": "Gamma", "blocks": ["F"],      "mu": 150.0, "order": 3},
]

# ─── SETTINGS CACHE ────────────────────────────────────────────────────────────
_settings_cache: dict = {
    "cost_per_failure":  107.0,  # ₹ per high-importance delivery failure (LEAKAGE_SEED)
    "truck_transit_cost": 1.20,  # ₹ per unit truck transit cost (recovery_value multiplier)
    "webhook_url":        "",    # Optional: POST alerts to client's internal system (Slack/ERP/ops)
}


# ─── SECURITY: RBAC — API KEY + ROLE AUTH ─────────────────────────────────────
# Role hierarchy (highest → lowest):
#   ADMIN      — full access: topology CRUD, decisions, settings, all reads
#   OPERATOR   — diversion approvals + all reads; cannot delete hubs
#   INTEGRATOR — v1/intercept + GET state; cannot mutate topology or decisions
#   READONLY   — GET endpoints only; no writes of any kind
#
# .env format:  API_KEYS=abc123:ADMIN,xyz789:INTEGRATOR,def456:OPERATOR
# Legacy keys without :ROLE suffix are treated as READONLY (safest default).

def get_key_role(api_key: str) -> str:
    """Return the RBAC role assigned to this key."""
    return _KEY_ROLE_MAP.get(api_key, _DEFAULT_ROLE)


def require_api_key(x_api_key: str = Header(default=None)) -> str:
    """
    X-API-KEY header authentication.
    Returns the validated key string. Role is checked via require_role().
    """
    if x_api_key is None:
        raise HTTPException(
            status_code=401,
            detail={"error": "UNAUTHORIZED", "message": "X-API-KEY header required"}
        )
    if x_api_key not in VALID_API_KEYS:
        logger.warning(f"[AUTH] Invalid key attempt: {x_api_key[:8]}...")
        raise HTTPException(
            status_code=403,
            detail={"error": "FORBIDDEN", "message": "Invalid API key"}
        )
    return x_api_key


def require_role(api_key: str, allowed_roles: set, endpoint: str = "") -> str:
    """
    Role gate — always call AFTER require_api_key().
    Raises HTTP 403 if the key role is not in allowed_roles.
    Returns the resolved role string on success.

    Usage example:
        key = require_api_key(api_key)
        require_role(key, {"ADMIN", "OPERATOR"}, "DELETE /network/hubs")
    """
    role = get_key_role(api_key)
    if role not in allowed_roles:
        logger.warning(
            f"[RBAC] DENIED role='{role}' on '{endpoint}' "
            f"(requires one of {sorted(allowed_roles)})"
        )
        raise HTTPException(
            status_code=403,
            detail={
                "error":     "FORBIDDEN",
                "message":   f"Role '{role}' is not authorised for this endpoint",
                "your_role": role,
                "required":  sorted(allowed_roles),
                "endpoint":  endpoint,
                "hint":      "Contact your SITI admin to provision a key with the required role",
            }
        )
    logger.debug(f"[RBAC] GRANTED role='{role}' on '{endpoint}'")
    return role


# ─── 2D KALMAN HUB NODE ──────────────────────────────────────────────────────
class HubNode:
    """
    Network distribution hub — Queueing Theory ρ = λ/μ
    2D Kalman state vector x = [ρ, ρ̇]^T
    Transition: F = [[1, Δt], [0, 1]]  (constant-velocity model)
    dt = 0.25 → one 15-minute tick
    """
    def __init__(self, name: str, lambda_rate: float, mu: float = 150.0):
        self.name            = name
        self.lambda_rate     = lambda_rate
        self.mu              = mu
        self._kx: Optional[np.ndarray] = None
        self._kP: np.ndarray = np.eye(2) * 0.1
        self.rho_history: list = []
        self.saturation_protocol: bool = False
        self._prev_lambda: float = lambda_rate

    @property
    def rho(self) -> float:
        """ρ = λ/μ — standard M/M/1 utilization."""
        return float(self.lambda_rate / self.mu) if self.mu > 0 else 99.0

    def check_thundering_herd(self, new_lambda: float) -> bool:
        """Trigger saturation protocol if λ spikes >40% in one tick."""
        if self._prev_lambda > 1.0:
            spike = (new_lambda - self._prev_lambda) / self._prev_lambda
            if spike > 0.40:
                self.saturation_protocol = True
                self._prev_lambda = new_lambda
                return True
        self.saturation_protocol = False
        self._prev_lambda = new_lambda
        return False

    def kalman_step_2d(self, z_rho: float, dt: float = 0.25) -> dict:
        """
        2D Kalman Filter — x = [ρ, ρ̇]^T
        dt = 0.25 hr (15-min tick)
        T+1 = 15 min ahead · T+3 = 45 min ahead
        Q, R calibrated to enterprise IoT 15-min sampling interval.
        """
        Q = np.diag([0.002, 0.001])
        R = np.array([[0.005]])
        H = np.array([[1.0, 0.0]])
        F = np.array([[1.0, dt], [0.0, 1.0]])

        if self._kx is None:
            self._kx = np.array([z_rho, 0.0])
            self._kP = np.eye(2) * 0.1

        x_pred = F @ self._kx
        P_pred = F @ self._kP @ F.T + Q
        y      = np.array([z_rho]) - H @ x_pred
        S      = H @ P_pred @ H.T + R
        K      = P_pred @ H.T @ np.linalg.inv(S)

        self._kx = x_pred + (K @ y).flatten()
        self._kP = (np.eye(2) - K @ H) @ P_pred

        rho_hat = float(self._kx[0])
        rho_dot = float(self._kx[1])
        rho_t1  = float(np.clip(rho_hat + dt * rho_dot, 0.0, 1.5))

        if self.saturation_protocol:
            rho_t3_raw = rho_hat
            v = rho_dot
            for _ in range(3):
                rho_t3_raw += dt * v
                v *= 1.10
            rho_t3_raw = float(rho_t3_raw)
        else:
            rho_t3_raw = float(rho_hat + 3.0 * dt * rho_dot)

        rho_t3 = float(np.clip(rho_t3_raw, 0.0, 1.5))
        pvi    = round(abs(z_rho - rho_t3) * 100, 2)

        return {
            "x_hat":              round(rho_hat, 4),
            "rho_dot":            round(rho_dot, 6),
            "P":                  round(float(np.trace(self._kP)), 6),
            "K":                  [round(float(K[0, 0]), 4), round(float(K[1, 0]), 4)],
            "rho_t1":             round(rho_t1, 4),
            "rho_t3":             round(rho_t3, 4),
            "pvi":                pvi,
            "saturation_protocol": self.saturation_protocol,
        }


# ─── MIMI KERNEL ──────────────────────────────────────────────────────────────
class MIMIKernel:
    LEAKAGE_SEED       = 107.0
    AUDIT_WINDOW_HOURS = 36.0
    K_DECAY            = 20
    BASELINE_HI_FAIL   = 0.817   # Wankhede (2026) §IV-C

    def __init__(self, df: pd.DataFrame, mu: float = 150.0):
        self.df           = df.copy()
        self.n_total      = len(df)
        self.mu           = mu
        self.critical_rho = 0.85
        self.lr_model     = None
        self.hubs: dict   = self._init_hubs()
        # Dynamic lambda tracking for intercept API
        self._intercept_lambda_override: Optional[float] = None

    def _init_hubs(self) -> dict:
        hubs = {}
        for name, blocks in _get_hub_block_map().items():
            hub_df = self.df[self.df['Warehouse_block'].isin(blocks)]
            lambda_rate = len(hub_df) / T_OPERATIONAL
            hubs[name] = HubNode(name, lambda_rate, self.mu)
        return hubs

    def recalculate_lambdas(self):
        for name, blocks in _get_hub_block_map().items():
            if name in self.hubs:
                hub_df = self.df[self.df['Warehouse_block'].isin(blocks)]
                new_lambda = len(hub_df) / T_OPERATIONAL
                self.hubs[name].check_thundering_herd(new_lambda)
                self.hubs[name].lambda_rate = new_lambda

    def global_rho(self) -> float:
        total_lambda = sum(h.lambda_rate for h in self.hubs.values())
        total_mu     = sum(h.mu for h in self.hubs.values())
        return float(np.clip(total_lambda / total_mu, 0.0, 1.5)) if total_mu > 0 else 1.0

    def failure_rate(self) -> float:
        late = int((self.df['Reached.on.Time_Y.N'] == 0).sum())
        return round(float(late / self.n_total), 4) if self.n_total > 0 else 0.0

    def update_mu(self, new_mu: float):
        self.mu = new_mu
        for hub in self.hubs.values():
            hub.mu = new_mu

    def phi(self, rho_val: float) -> float:
        return round(float(1 / (1 + np.exp(-self.K_DECAY * (rho_val - self.critical_rho)))), 4)

    def wq(self, rho_val: float) -> float:
        if rho_val >= 1.0:
            return 99.9999
        return round(float(rho_val / (1 - rho_val)), 4)

    @property
    def annualized_exposure(self) -> float:
        """
        Live formula: (daily_shipments × 365) × hi_imp_failure_rate × cost_per_failure
        Uses user-configured cost_per_failure from _settings_cache (default: 3.94).
        Traceable: Wankhede (2026) §IV-C, Eq. (7)
        """
        daily_shipments = self.n_total / self.AUDIT_WINDOW_HOURS * 24.0
        irp = self.inverse_reliability()
        rate = irp['failure_rate'] if irp['failure_rate'] > 0 else self.BASELINE_HI_FAIL
        cost = _settings_cache.get("cost_per_failure", self.LEAKAGE_SEED)
        return round(daily_shipments * 365 * rate * cost, 0)

    def diversion_units_calculated(self, effective_lambdas: dict, cascade_events: list) -> int:
        """Calculated diversion — NO random numbers. excess_λ × (15min/60)."""
        if not cascade_events:
            total = 0
            for name, eff_lam in effective_lambdas.items():
                hub = self.hubs.get(name)
                if hub:
                    eff_rho = eff_lam / hub.mu if hub.mu > 0 else 0
                    if eff_rho > 0.80:
                        excess = max(0, (eff_rho - 0.80) * hub.mu)
                        total += int(excess * (15.0 / 60.0))
            return total
        total_excess = sum(ev['excess_lambda'] for ev in cascade_events)
        return int(total_excess * (15.0 / 60.0))

    def routing_logic_rho(self) -> dict:
        """
        FIXED: Routing based purely on ρ = λ/μ per hub.
        No more late/n contamination. One definition everywhere.
        """
        epsilon   = 0.05
        threshold = self.critical_rho
        hub_rhos  = []
        for name, hub in self.hubs.items():
            hub_rhos.append({"hub": name, "rho": round(hub.rho, 4), "lambda": round(hub.lambda_rate, 2), "mu": round(hub.mu, 2)})

        overloaded = [h for h in hub_rhos if h["rho"] > threshold]
        available  = [h for h in hub_rhos if h["rho"] < threshold - epsilon]
        return {
            "hub_utilizations":  hub_rhos,
            "overloaded_hubs":   overloaded,
            "available_hubs":    available,
            "diversion_active":  len(overloaded) > 0 and len(available) > 0,
            "epsilon":           epsilon,
            "threshold":         round(threshold, 4),
            "method":            "rho_lambda_mu",   # auditable: confirms correct formula
        }

    def inverse_reliability(self) -> dict:
        df     = self.df
        mask   = (df['Product_importance'].str.lower() == 'high') & (df['Reached.on.Time_Y.N'] == 0)
        fail_df = df[mask]
        n_fail = int(len(fail_df))
        n_high = int((df['Product_importance'].str.lower() == 'high').sum())
        failure_rate = round(float(n_fail / n_high), 4) if n_high > 0 else 0.0
        top = fail_df.head(25)[['ID', 'Warehouse_block', 'Mode_of_Shipment',
                                 'Cost_of_the_Product', 'Weight_in_gms', 'Discount_offered']].copy()
        top.columns = ['id', 'hub', 'mode', 'cost', 'weight', 'discount']
        records = [{k: int(v) if isinstance(v, (np.integer, np.int64)) else v
                    for k, v in row.items()} for row in top.to_dict('records')]
        return {
            "failure_count": n_fail, "total_high": n_high, "failure_rate": failure_rate,
            "leakage_total": round(n_fail * self.LEAKAGE_SEED, 2),
            "clv_loss":      round(n_fail * 2.74, 2),
            "recovery_value": round(n_fail * 1.20, 2),
            "records":       records,
        }

    def warehouse_metrics(self) -> list:
        results = []
        # Dynamic block detection: always derive from actual DataFrame
        # Never hardcode block list — if client has Block E, G, Z — we find it
        detected_blocks = sorted(self.df['Warehouse_block'].dropna().unique().tolist())             if 'Warehouse_block' in self.df.columns else []
        active_blocks = _all_blocks if _all_blocks else detected_blocks if detected_blocks else ['A','B','C','D','E','F']
        for b in active_blocks:
            sub = self.df[self.df['Warehouse_block'] == b]
            n   = len(sub)
            if n == 0: continue
            late = int((sub['Reached.on.Time_Y.N'] == 0).sum())
            results.append({"block": b, "total": int(n), "late": late,
                            "failure_rate": round(float(late / n), 4), "on_time": int(n - late)})
        return results

    def mode_metrics(self) -> list:
        results = []
        for m in ['Ship', 'Flight', 'Road']:
            sub = self.df[self.df['Mode_of_Shipment'] == m]
            n   = len(sub)
            if n == 0: continue
            late = int((sub['Reached.on.Time_Y.N'] == 0).sum())
            results.append({"mode": m, "total": int(n), "late": late, "rate": round(float(late / n), 4)})
        return results

    def red_zone_importance(self) -> list:
        # Same dynamic detection as warehouse_metrics — never hardcode block list
        detected_blocks = sorted(self.df['Warehouse_block'].dropna().unique().tolist())             if 'Warehouse_block' in self.df.columns else []
        _blocks = _all_blocks if _all_blocks else detected_blocks if detected_blocks else ['A','B','C','D','E','F']
        red_blocks = [
            b for b in _blocks
            if (sub := self.df[self.df['Warehouse_block'] == b]) is not None
            and len(sub) > 0
            and (sub['Reached.on.Time_Y.N'] == 0).sum() / len(sub) > 0.80
        ]
        if not red_blocks:
            red_blocks = _blocks
        red_df = self.df[
            (self.df['Warehouse_block'].isin(red_blocks)) &
            (self.df['Reached.on.Time_Y.N'] == 0)
        ]
        counts = red_df['Product_importance'].str.title().value_counts()
        return [{"name": lvl, "value": int(counts.get(lvl, 0))} for lvl in ['High', 'Medium', 'Low']]

    # Warm Start checkpoint
    CHECKPOINT_PATH = Path(__file__).parent / "mimi_kernel_v1.joblib"

    def fit_lr(self, checkpoint: bool = True) -> float:
        """
        V7 WARM START: checks mimi_kernel_v1.joblib before fitting.
          EXISTS  → joblib.load in <100ms regardless of dataset size
          MISSING → cold fit, then save for every future restart
        Reduces startup from minutes → under 5 seconds on massive datasets.
        random_state=2028317 (case number) — deterministic, auditable.
        """
        import time as _t
        if checkpoint and MIMIKernel.CHECKPOINT_PATH.exists():
            try:
                t0   = _t.monotonic()
                ckpt = joblib.load(MIMIKernel.CHECKPOINT_PATH)
                self.lr_model     = ckpt["lr_model"]
                self.critical_rho = float(ckpt["critical_rho"])
                logger.info(f"[WARM START] Loaded checkpoint in {_t.monotonic()-t0:.3f}s "
                            f"— ρ_c={self.critical_rho:.4f} (saved {ckpt.get('saved_at','?')})")
                return self.critical_rho
            except Exception as e:
                logger.warning(f"[WARM START] Load failed ({e}) — falling back to cold fit")

        # Cold fit path — runs once, saves checkpoint for all future restarts
        t0 = _t.monotonic()
        df = self.df.copy()
        for col in ['Mode_of_Shipment', 'Product_importance', 'Warehouse_block', 'Gender']:
            if col in df.columns:
                df[f'{col}_enc'] = LabelEncoder().fit_transform(df[col].astype(str))
        features = [c for c in [
            'Customer_care_calls', 'Customer_rating', 'Cost_of_the_Product',
            'Prior_purchases', 'Discount_offered', 'Weight_in_gms',
            'Mode_of_Shipment_enc', 'Product_importance_enc',
            'Warehouse_block_enc', 'Gender_enc'
        ] if c in df.columns]
        X = df[features].values
        y = df['Reached.on.Time_Y.N'].values
        self.lr_model = LogisticRegression(max_iter=2000, random_state=2028317)
        self.lr_model.fit(X, y)
        proba_late    = 1 - self.lr_model.predict_proba(X)[:, 1]
        new_thresh    = float(np.mean(proba_late) + 1.0 * np.std(proba_late))
        self.critical_rho = round(float(np.clip(new_thresh, 0.70, 0.95)), 4)
        elapsed = _t.monotonic() - t0
        logger.info(f"[COLD FIT] LR fitted in {elapsed:.2f}s — ρ_c={self.critical_rho:.4f} — saving checkpoint")

        if checkpoint:
            try:
                joblib.dump({
                    "lr_model":     self.lr_model,
                    "critical_rho": self.critical_rho,
                    "n_samples":    len(df),
                    "saved_at":     datetime.now(timezone.utc).isoformat(),
                }, MIMIKernel.CHECKPOINT_PATH)
                logger.info(f"[WARM START] Checkpoint saved → {MIMIKernel.CHECKPOINT_PATH.name}")
            except Exception as e:
                logger.warning(f"[WARM START] Save failed: {e}")
        return self.critical_rho


# ─── SESSION STATE ────────────────────────────────────────────────────────────
# diverted_units and revenue_saved are atomic MongoDB counters.
# All counter state lives in MongoDB global_metrics collection.
# Workers use atomic $inc — 50 workers, one consistent number. Never jumps backward.
# ─── MULTI-TENANT SESSION REGISTRY ─────────────────────────────────────────
# Each API key gets a fully isolated session — no data cross-contamination.
# Porter uploads their CSV → their session. Delhivery uploads theirs → separate session.
# Shared read-only baseline (built from baseline_data.py) is NEVER mutated here.

_sessions: dict = {}   # {api_key: session_dict}

def _get_session(api_key: str) -> dict:
    """
    Get or create an isolated session for this API key.
    New tenants inherit the baseline MIMI kernel (read-only copy).
    They diverge the moment they upload their own CSV.
    Porter's data NEVER touches Delhivery's session.
    """
    if api_key not in _sessions:
        # Clone baseline kernel reference for new tenant
        # First request inherits the shared baseline; upload replaces it
        baseline = _sessions.get("__startup__", {})
        _sessions[api_key] = {
            "mimi":           baseline.get("mimi"),       # shared baseline (read-only until upload)
            "refresh_count":  0,
            "rho_history":    [],
            "dataset_name":   baseline.get("dataset_name", "BASELINE"),
            "mu":             baseline.get("mu", 150.0),
            "api_requests":   0,
        }
    return _sessions[api_key]

# Keep _session as a property of the ADMIN key for startup/warmup compatibility
# (baseline init populates admin session; other tenants start fresh on first request)
_session: dict = _get_session("__startup__")   # startup/baseline init only



# ─── SITI: ATOMIC MONGODB COUNTERS ──────────────────────────────────────────
# All revenue/diversion state lives here — worker-safe via $inc.
# _session["diverted_units"] and _session["revenue_saved"] are DELETED.
# Any number of Gunicorn workers reads the same MongoDB document.

async def atomic_inc_metrics(diverted: int, revenue: float) -> None:
    """
    Atomic $inc on global_metrics._id='counters'.
    Concurrent workers increment safely — no read-modify-write race.
    Fire-and-forget via create_task — never blocks the response path.
    """
    if diverted == 0 and revenue == 0.0:
        return
    try:
        await metrics_col.update_one(
            {"_id": "counters"},
            {"$inc": {"diverted_units": diverted, "revenue_saved": round(revenue, 2)},
             "$set": {"last_updated": datetime.now(timezone.utc)}},
            upsert=True
        )
    except Exception as e:
        logger.warning(f"[ATOMIC] Counter increment failed: {e}")
        _asyncio.create_task(log_system_error("atomic_inc_metrics", e, "ERROR"))

async def get_global_metrics() -> dict:
    """Read current atomic counters — single document, worker-safe."""
    try:
        doc = await metrics_col.find_one({"_id": "counters"})
        if doc:
            return {
                "diverted_units": int(doc.get("diverted_units", 0)),
                "revenue_saved":  float(doc.get("revenue_saved", 0.0)),
            }
    except Exception as e:
        logger.warning(f"[ATOMIC] Counter read failed: {e}")
    return {"diverted_units": 0, "revenue_saved": 0.0}


# ─── HELPERS ──────────────────────────────────────────────────────────────────
def _sanitize_numeric(val):
    if isinstance(val, str):
        cleaned = re.sub(r'[^\d.]', '', val.strip())
        try:    return float(cleaned) if cleaned else 0.0
        except (ValueError, TypeError): return 0.0
    return val

def _sanitize_numeric_columns(df: pd.DataFrame) -> pd.DataFrame:
    for col in ['Customer_care_calls', 'Customer_rating', 'Cost_of_the_Product',
                'Prior_purchases', 'Discount_offered', 'Weight_in_gms']:
        if col in df.columns:
            df[col] = df[col].apply(_sanitize_numeric)
    return df

def _strip_non_ascii(t):
    return re.sub(r'[^\x20-\x7E\t\n\r]', '', t)

def _parse_csv_resilient(content: bytes) -> pd.DataFrame:
    for encoding in ('utf-8', 'iso-8859-1', 'windows-1252'):
        try:
            text = content.decode(encoding, errors='replace')
            if encoding == 'utf-8' and '\uFFFD' in text:
                continue
            text = _strip_non_ascii(text)
            df   = pd.read_csv(io.StringIO(text), on_bad_lines='skip')
            logger.info(f"CSV parsed OK: encoding={encoding}, rows={len(df)}")
            return df
        except UnicodeDecodeError:
            logger.warning(f"Decode failed with {encoding}")
        except Exception as exc:
            logger.warning(f"CSV parse error ({encoding}): {exc}")
    raise ValueError("CSV unreadable with UTF-8, ISO-8859-1, or Windows-1252")

def _fuzzy_map_columns(df: pd.DataFrame) -> pd.DataFrame:
    TARGET_MAP = [
        ('Reached.on.Time_Y.N', lambda c: ('reached' in c) or ('on_time' in c) or ('delivered' in c)),
        ('Warehouse_block',     lambda c: ('warehouse' in c) or ('block' in c and 'hub' not in c)),
        ('Mode_of_Shipment',    lambda c: ('mode' in c) or ('shipment' in c) or ('carrier' in c)),
        ('Customer_care_calls', lambda c: ('care' in c and 'call' in c) or ('cc_call' in c)),
        ('Customer_rating',     lambda c: ('rating' in c) or ('csat' in c)),
        ('Cost_of_the_Product', lambda c: ('cost' in c) or ('price' in c)),
        ('Prior_purchases',     lambda c: ('prior' in c) or ('purchase' in c)),
        ('Product_importance',  lambda c: ('importance' in c) or ('priority' in c)),
        ('Gender',              lambda c: c in ('gender', 'sex', 'g')),
        ('Discount_offered',    lambda c: ('discount' in c) or ('promo' in c)),
        ('Weight_in_gms',       lambda c: ('weight' in c) or ('gms' in c) or ('gram' in c)),
    ]
    col_map = {}
    already_mapped = set()
    for col in df.columns:
        lower = col.lower().replace(' ', '_').replace('.', '_').replace('-', '_')
        for target, matcher in TARGET_MAP:
            if target not in already_mapped and matcher(lower):
                col_map[col] = target
                already_mapped.add(target)
                break
    return df.rename(columns=col_map)

def _fill_missing_with_means(df: pd.DataFrame) -> pd.DataFrame:
    for col in ['Customer_care_calls', 'Customer_rating', 'Cost_of_the_Product',
                'Prior_purchases', 'Discount_offered', 'Weight_in_gms']:
        if col in df.columns:
            m = df[col].mean()
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0 if pd.isna(m) else m).astype(int)
    for col, default in [('Warehouse_block','A'),('Mode_of_Shipment','Ship'),
                          ('Product_importance','Medium'),('Gender','M')]:
        if col in df.columns:
            df[col] = df[col].fillna(default)
    return df

def _compute_cascade(hubs: dict) -> tuple:
    effective = {name: h.lambda_rate for name, h in hubs.items()}
    events    = []
    for name in sorted(effective.keys(), key=lambda n: effective[n] / hubs[n].mu, reverse=True):
        hub = hubs[name]
        rho = effective[name] / hub.mu if hub.mu > 0 else 99.0
        if rho > 0.85:
            excess = (rho - 0.85) * hub.mu
            others = [(n, effective[n] / hubs[n].mu) for n in effective if n != name]
            if not others: continue
            receiver = min(others, key=lambda x: x[1])[0]
            effective[name]    -= excess
            effective[receiver] += excess
            events.append({
                "from_hub":         name,
                "to_hub":           receiver,
                "excess_lambda":    round(excess, 2),
                "new_rho_source":   round(effective[name] / hub.mu, 4),
                "new_rho_receiver": round(effective[receiver] / hubs[receiver].mu, 4),
            })
    return effective, events


# ─── MONGODB PERSISTENCE ──────────────────────────────────────────────────────
async def persist_telemetry(hub_states: list, global_rho: float,
                             cascade_events: list, alert: dict) -> None:
    """
    STRESS CHECK FIX: Buffer telemetry writes — never blocks dashboard.
    Telemetry docs go into _telemetry_buffer; background loop flushes to MongoDB.
    Alert writes (rare) go direct — they are low-frequency and high-value.
    """
    ts = datetime.now(timezone.utc)
    doc = {
        "timestamp":      ts,
        "global_rho":     round(global_rho, 4),
        "hub_states":     [
            {
                "name":    h["name"],
                "rho":     h["rho"],
                "rho_dot": h["kalman"].get("rho_dot", 0),
                "rho_t1":  h["kalman"].get("rho_t1", 0),
                "rho_t3":  h["kalman"].get("rho_t3", 0),
                "lambda":  h["lambda_rate"],
                "status":  "DIVERTING" if h.get("cascade_source") else
                           "CASCADE_RECV" if h.get("cascade_risk") else "NOMINAL",
            }
            for h in hub_states
        ],
        "cascade_active": len(cascade_events) > 0,
        "cascade_events": cascade_events,
        "dataset":        _session.get("dataset_name", "SAFEXPRESS_CASE_02028317"),
    }

    # ── ASYNC BUFFER: append, flush only when full ──────────────────────────
    async with _buffer_lock:
        _telemetry_buffer.append(doc)
        should_flush = len(_telemetry_buffer) >= _BUFFER_MAX

    if should_flush:
        # Fire-and-forget — response is NOT blocked
        _asyncio.create_task(_flush_telemetry_buffer())

    # ── ALERTS: direct write (rare, high-value) ─────────────────────────────
    if alert.get("sent"):
        alert_doc = {
            "timestamp":    ts,
            "hub":          alert.get("hub"),
            "rho":          alert.get("rho"),
            "alert_count":  alert.get("alert_count"),
            "message":      alert.get("message", ""),
            "decision":     "PENDING",   # awaiting human-in-the-loop approval
        }
        try:
            await alerts_col.insert_one(alert_doc)
        except Exception as e:
            logger.warning(f"Alert persist failed: {e}")


# ─── SITI: WHATSAPP ALERT — LIVE (stdlib only, no SDK) ─────────────────────────
_alert_state: dict = {"last_alert_rho": 0.0, "alert_count": 0, "last_alert_time": None}
# Note: _alert_state is in-memory but alert_count is persisted via MongoDB alerts_col

def _send_whatsapp(msg: str) -> bool:
    """
    SITI Intelligence: Pure stdlib Twilio REST sender — zero SDK dependency.
    Activate by setting these env vars:
      TWILIO_SID   = AC... (Account SID from twilio.com/console)
      TWILIO_TOKEN = your auth token
      TWILIO_FROM  = whatsapp:+14155238886
      TWILIO_TO    = whatsapp:+91XXXXXXXXXX  (VP operations number)
    If any credential missing — logs alert only, never crashes.
    """
    import urllib.request, urllib.parse, base64
    sid   = os.getenv("TWILIO_SID",   "")
    token = os.getenv("TWILIO_TOKEN", "")
    frm   = os.getenv("TWILIO_FROM",  "whatsapp:+14155238886")
    to_raw = os.getenv("TWILIO_TO", "")
    if not all([sid, token, to_raw]):
        logger.info("[WHATSAPP] Creds not set — alert logged only (set TWILIO_SID/TOKEN/TO)")
        return False
    # MULTI-NUMBER: TWILIO_TO can be comma-separated list
    # e.g. "whatsapp:+919876543210,whatsapp:+919876543211"
    recipients = [t.strip() for t in to_raw.split(",") if t.strip()]
    url  = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
    cred = base64.b64encode(f"{sid}:{token}".encode()).decode()
    sent = 0
    for to in recipients:
        data = urllib.parse.urlencode({"From": frm, "To": to, "Body": msg}).encode()
        req  = urllib.request.Request(
            url, data=data,
            headers={"Authorization": f"Basic {cred}",
                     "Content-Type":  "application/x-www-form-urlencoded"}
        )
        try:
            with urllib.request.urlopen(req, timeout=8) as r:
                logger.info(f"[WHATSAPP] Fired to {to[:25]}... — HTTP {r.status}")
                sent += 1
        except Exception as e:
            logger.warning(f"[WHATSAPP] Send failed to {to[:20]}: {e}")
    return sent > 0


def trigger_critical_alert(global_rho: float, hubs: dict) -> dict:
    """
    SITI Intelligence: Live WhatsApp alert via Twilio REST — suppression timer active.
    Cool-down: ALERT_COOLDOWN_MIN env var (default 30 min).
    ρ threshold: > 0.80 on any hub.
    """
    payload      = {"sent": False, "message": "", "hub": "", "rho": 0.0}
    now          = datetime.now(timezone.utc)
    cooldown_sec = int(os.getenv("ALERT_COOLDOWN_MIN", "30") or "30") * 60
    cooldown_sec = max(60, min(cooldown_sec, 3600))  # clamp 1–60 min

    last = _alert_state.get("last_alert_time")
    if last and (now - last).total_seconds() < cooldown_sec:
        return payload

    worst = max(hubs.values(), key=lambda h: h.rho, default=None)
    if worst is None or worst.rho <= 0.80:
        return payload

    # ── SITI: ACTIONABLE DIRECTIVE FORMAT ──────────────────────────────────────
    # Dual register: machine-precise data + human-readable action.
    # The VP reading this at 2am must know: WHAT is wrong, HOW BAD, WHAT TO DO.
    _alert_state["alert_count"] += 1          # increment FIRST — message shows correct number
    severity       = "CRITICAL" if worst.rho >= 0.85 else "WARNING"
    utilization    = round(worst.rho * 100, 1)          # % of capacity — human-readable
    backlog_units  = max(0, round((worst.lambda_rate - worst.mu) * 0.75))  # projected units in 45min window
    backlog_str    = f"{backlog_units:,}" if backlog_units > 0 else "<50"

    msg = (
        f"{'🔴' if severity == 'CRITICAL' else '🟡'} [{severity}] "
        f"Hub {worst.name.upper()} is at {utilization}%.\n"
        f"Predicted backlog: {backlog_str} units.\n"
        f"Action: Divert inbound shipments immediately.\n"
        f"Window closes in 45m.\n"
        f"\n"
        f"Network load: {round(worst.lambda_rate,1)} arrivals/hr "
        f"vs {round(worst.mu,0):.0f}/hr capacity.\n"
        f"At current rate, Hub {worst.name.upper()} hits collapse threshold "
        f"in ~{min(45, max(1, round((0.90-worst.rho)/max(0.001,worst.rho-0.75)*15)))}m.\n"
        f"\n"
        f"— SITI Intelligence | {now.strftime('%d %b, %H:%M')} | "
        f"Alert #{_alert_state['alert_count']:04d} | "
        f"Next alert suppressed 30m"
    )
    logger.warning(f"[ALERT] {severity} Hub={worst.name} util={utilization}% backlog={backlog_str}")
    # run_in_executor prevents 8-second Twilio timeout from blocking asyncio event loop.
    # trigger_critical_alert is sync, so we schedule the HTTP call as a fire-and-forget background thread.
    # The alert state is updated immediately; whatsapp delivery is best-effort async.
    try:
        import asyncio as _fix_asyncio
        loop = _fix_asyncio.get_running_loop()
        if loop.is_running():
            # Inside event loop — schedule as non-blocking background thread
            loop.run_in_executor(None, _send_whatsapp, msg)
            whatsapp_sent = True  # fired (delivery confirmed via log)
        else:
            whatsapp_sent = _send_whatsapp(msg)  # fallback: direct call outside event loop
    except Exception as _wa_err:
        logger.warning(f"[WHATSAPP] Executor dispatch failed: {_wa_err}")
        whatsapp_sent = _send_whatsapp(msg)  # last resort: direct call

    _alert_state["last_alert_rho"]  = worst.rho
    _alert_state["last_alert_time"] = now

    # ── MISSING 5 FIX: WEBHOOK DISPATCH ────────────────────────────────────────
    # If client has configured a webhook URL in settings, POST the alert payload
    # to their internal system (Slack, ERP, ops dashboard) as a fire-and-forget.
    webhook_url = _settings_cache.get("webhook_url", "").strip()
    if webhook_url:
        webhook_payload = {
            "event":      "hub_alert",
            "severity":   severity,
            "hub":        worst.name,
            "rho":        round(worst.rho, 4),
            "lambda_rate": round(worst.lambda_rate, 1),
            "mu":          round(worst.mu, 1),
            "utilization_pct": utilization,
            "alert_count": _alert_state["alert_count"],
            "timestamp":   now.isoformat(),
            "message":     msg,
        }
        async def _fire_webhook(url: str, data: dict):
            try:
                import httpx as _hx
                async with _hx.AsyncClient(timeout=5) as hx:
                    r = await hx.post(url, json=data)
                logger.info(f"[WEBHOOK] Fired → {url} HTTP {r.status_code}")
            except Exception as _wh_err:
                logger.warning(f"[WEBHOOK] Delivery failed: {_wh_err}")
        try:
            import asyncio as _wh_asyncio
            _loop = _wh_asyncio.get_running_loop()
            if _loop.is_running():
                _loop.create_task(_fire_webhook(webhook_url, webhook_payload))
        except Exception as _wh_ex:
            logger.warning(f"[WEBHOOK] Dispatch error: {_wh_ex}")
    return {
        "sent":           True,
        "whatsapp_fired": whatsapp_sent,
        "message":        msg,
        "hub":            worst.name,
        "rho":            round(worst.rho, 4),
        "alert_count":    _alert_state["alert_count"],
        "cooldown_min":   cooldown_sec // 60,
    }


# ─── REQUEST MODELS ───────────────────────────────────────────────────────────
class MuUpdate(BaseModel):
    mu: float

# ─── ROUTES ───────────────────────────────────────────────────────────────────

@api_router.get("/")
async def root():
    return {
        "service":  "SITI Intelligence — MIMI Kernel",
        "status":   "operational",
        "security": "X-API-KEY required on protected endpoints",
        "docs":     "/docs",
    }


@api_router.get("/kernel/state")
async def get_kernel_state(api_key: str = Header(alias="X-API-KEY", default=None)):
    """Protected: requires X-API-KEY header."""
    key = require_api_key(api_key)
    _session = _get_session(key)
    _session["api_requests"] += 1
    # MISSING 9: track usage per key — fire-and-forget
    _asyncio.create_task(_track_usage(key, "state_view"))

    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")

    effective_lambdas, cascade_events = _compute_cascade(mimi.hubs)

    hub_states = []
    for name in list(_hub_block_map.keys()):   # dynamic iteration
        if name not in mimi.hubs:
            continue
        hub      = mimi.hubs[name]
        eff_lam  = effective_lambdas.get(name, mimi.hubs[name].lambda_rate)
        # eff_rho passed directly — ZERO noise injection.
        # Kalman Q=diag(0.002,0.001) and R=[[0.005]] encode real process/measurement uncertainty.
        eff_rho  = float(np.clip(eff_lam / hub.mu, 0.0, 1.5)) if hub.mu > 0 else 1.0
        kalman   = hub.kalman_step_2d(eff_rho)

        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        hub.rho_history.append({"time": ts, "rho": round(eff_rho, 4),
                                 "t1": kalman["rho_t1"], "t3": kalman["rho_t3"]})
        if len(hub.rho_history) > 30:
            hub.rho_history.pop(0)

        hub_states.append({
            "name":             name,
            "blocks":            _get_hub_blocks(name),
            "lambda_rate":      round(hub.lambda_rate, 2),
            "effective_lambda": round(eff_lam, 2),
            "mu":               round(hub.mu, 2),
            "rho":              round(eff_rho, 4),
            "rho_exact":        round(eff_rho, 4),
            "kalman":           kalman,
            "rho_history":      hub.rho_history[-30:],
            "cascade_risk":     any(e["to_hub"] == name for e in cascade_events),
            "cascade_source":   any(e["from_hub"] == name for e in cascade_events),
            "saturation_protocol": hub.saturation_protocol,
        })

    total_eff  = sum(effective_lambdas.values())
    total_mu   = sum(h.mu for h in mimi.hubs.values())
    g_rho_val  = float(np.clip(total_eff / total_mu, 0.0, 1.5)) if total_mu > 0 else 1.0
    # g_rho_val is the true aggregate signal — zero artificial jitter
    g_rho_meas = g_rho_val   # direct pass — Kalman R encodes measurement uncertainty

    phi_val  = mimi.phi(g_rho_meas)
    irp      = mimi.inverse_reliability()
    alpha_k  = hub_states[0]["kalman"] if hub_states else {}

    ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
    _session["rho_history"].append({
        "time": ts, "rho": round(g_rho_meas, 4),
        "t1": alpha_k.get("rho_t1", 0), "t3": alpha_k.get("rho_t3", 0),
    })
    if len(_session["rho_history"]) > 30:
        _session["rho_history"].pop(0)

    critical_hub = max(hub_states, key=lambda h: h["rho"])
    rho_t3_max   = critical_hub["kalman"]["rho_t3"]
    rho_dot_max  = critical_hub["kalman"]["rho_dot"]

    # Commander message — dynamic, no hardcoded statistics
    if cascade_events:
        ev = cascade_events[0]
        commander_msg   = (f"CASCADE DIVERSION ACTIVE: {ev['from_hub']} → {ev['to_hub']} "
                          f"({ev['excess_lambda']:.1f} units/hr).\n"
                          f"MONITOR {ev['to_hub']} FOR SECONDARY STRAIN.")
        commander_level = "critical"
    elif rho_t3_max >= 0.85:
        commander_msg   = (f"CRITICAL: HUB {critical_hub['name'].upper()} SATURATION IMMINENT.\n"
                          f"INITIATE PREEMPTIVE DIVERSION PROTOCOL.")
        commander_level = "critical"
    elif rho_t3_max < 0.40:
        commander_msg   = "EFFICIENCY GAP: NETWORK UNDER-UTILIZED.\nACCELERATE INBOUND INGESTION."
        commander_level = "efficiency"
    else:
        # FIXED: no hardcoded "CERTAINTY 99.2%" — dynamic state description
        state_label = "CRITICAL" if g_rho_meas > 0.80 else "NOMINAL"
        commander_msg   = (f"SYSTEM STATE: {state_label} — "
                          f"ρ {g_rho_meas:.4f} — "
                          f"VELOCITY {rho_dot_max:+.6f}")
        commander_level = "stable"

    any_saturation = any(h["saturation_protocol"] for h in hub_states)
    if any_saturation:
        sat_hub       = next(h for h in hub_states if h["saturation_protocol"])
        commander_msg = (f"THUNDERING HERD: HUB {sat_hub['name'].upper()}.\n"
                        f"IMMEDIATE SATURATION PROTOCOL ENGAGED.")
        commander_level = "critical"

    catastrophe = g_rho_meas > 0.80
    collapse    = g_rho_meas >= 0.85
    alert       = trigger_critical_alert(g_rho_meas, mimi.hubs)

    # Write to MongoDB via async buffer — never blocks state response
    _asyncio.create_task(persist_telemetry(hub_states, g_rho_meas, cascade_events, alert))

    # V7 P1: atomic fetch — consistent across all 50 workers
    _live_metrics = await get_global_metrics()

    return {
        "rho":            round(g_rho_meas, 4),
        "global_rho":     round(g_rho_meas, 4),
        "mu":             round(mimi.mu, 2),
        "total_lambda":   round(total_eff, 2),
        "phi":            phi_val,
        "critical_rho":   mimi.critical_rho,
        "k_decay":        mimi.K_DECAY,
        "n_total":        mimi.n_total,
        "failure_rate":   mimi.failure_rate(),
        "wq":             mimi.wq(g_rho_meas),
        "hubs":           hub_states,
        "cascade_events": cascade_events,
        "kalman":         alpha_k,
        "rho_t3":         rho_t3_max,
        "pvi":            alpha_k.get("pvi", 0),
        "pvi_alert":      alpha_k.get("pvi", 0) > 15.0,
        "commander_message": commander_msg,
        "commander_level":   commander_level,
        "inverse_reliability": irp,
        "warehouse_metrics": mimi.warehouse_metrics(),
        "mode_metrics":      mimi.mode_metrics(),
        "red_zone_importance": mimi.red_zone_importance(),
        "routing":           mimi.routing_logic_rho(),
        "catastrophe":       catastrophe,
        "collapse":          collapse,
        "catastrophe_predicted": rho_t3_max > 0.80,
        "collapse_predicted":    rho_t3_max >= 0.85,
        "alert":             alert,
        "rho_history":       _session["rho_history"][-30:],
        "annualized_exposure": mimi.annualized_exposure,
        "leakage_seed":      mimi.LEAKAGE_SEED,
        "diverted_units":    _live_metrics["diverted_units"],
        "revenue_saved":     round(_live_metrics["revenue_saved"], 2),
        "refresh_count":     _session["refresh_count"],
        "dataset_name":      _session["dataset_name"],
        "api_requests":      _session["api_requests"],
        "secure":            True,
    }


@api_router.get("/kernel/history")
async def get_kernel_history(
    limit: int = 100,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Fetch last N telemetry states from MongoDB.
    Returns historical hub trajectories for trend analysis.
    Protected: requires X-API-KEY header.
    """
    require_api_key(api_key)
    try:
        cursor = telemetry_col.find(
            {},
            {"_id": 0, "timestamp": 1, "global_rho": 1,
             "hub_states": 1, "cascade_active": 1}
        ).sort("timestamp", -1).limit(limit)
        docs = await cursor.to_list(length=limit)
        # Convert timestamps to ISO strings for JSON
        for d in docs:
            if isinstance(d.get("timestamp"), datetime):
                d["timestamp"] = d["timestamp"].isoformat()
        return {
            "count":   len(docs),
            "records": list(reversed(docs)),  # chronological order
            "source":  "mongodb:telemetry_logs",
        }
    except Exception as e:
        logger.error(f"History fetch failed: {e}")
        _asyncio.create_task(log_system_error("get_kernel_history", e, "WARNING"))
        raise HTTPException(status_code=500, detail=f"History unavailable: {str(e)}")


@api_router.post("/kernel/tick")
async def kernel_tick(
    payload: Optional[TickPayload] = None,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """Protected: requires X-API-KEY header.
    Optional body: {"hub": "BOM", "lambda_rate": 310}
    If provided, overrides that hub's lambda for this tick — enables surge simulation.
    """
    key = require_api_key(api_key)
    _session = _get_session(key)

    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")

    # If caller specified a hub + lambda_rate, inject it before cascade computation
    if payload and payload.hub and payload.lambda_rate is not None:
        hub_key = payload.hub.upper()
        for name, hub in mimi.hubs.items():
            if hub_key in name.upper():
                hub.lambda_rate = float(payload.lambda_rate)
                logger.info(f"[TICK] Hub {name} λ overridden to {payload.lambda_rate}/hr")
                break

    effective_lambdas, cascade_events = _compute_cascade(mimi.hubs)
    diverted = mimi.diversion_units_calculated(effective_lambdas, cascade_events)

    cost_per      = _settings_cache.get("cost_per_failure", mimi.LEAKAGE_SEED)
    revenue_delta = round(diverted * cost_per, 2)
    _session["refresh_count"] += 1

    g_rho      = mimi.global_rho()
    alert_sent = trigger_critical_alert(g_rho, mimi.hubs)

    if diverted > 0:
        # V7 P1: atomic $inc — 50 workers, one consistent number, never jumps backward
        _asyncio.create_task(atomic_inc_metrics(diverted, revenue_delta))
        try:
            await diversion_col.insert_one({
                "timestamp":      datetime.now(timezone.utc),
                "diverted_units": diverted,
                "cascade_events": cascade_events,
                "revenue_saved":  revenue_delta,
                "global_rho":     round(g_rho, 4),
            })
        except Exception as e:
            logger.warning(f"Diversion persist failed: {e}")

    metrics = await get_global_metrics()
    return {
        "diverted":         diverted,
        "total_diverted":   metrics["diverted_units"],
        "revenue_saved":    metrics["revenue_saved"],
        "refresh_count":    _session["refresh_count"],
        "alert_sent":       alert_sent,
        "diversion_method": "calculated_atomic_v7",
    }


@api_router.post("/kernel/upload")
async def upload_dataset(
    file: UploadFile = File(...),
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """Upload real CSV data. Protected: requires X-API-KEY header."""
    key = require_api_key(api_key)
    _session = _get_session(key)
    try:
        content = await file.read()
        df      = _parse_csv_resilient(content)
        df      = _fuzzy_map_columns(df)

        if 'Reached.on.Time_Y.N' not in df.columns:
            raise HTTPException(status_code=400, detail={
                "type": "SCHEMA_MISMATCH",
                "found_columns": list(df.columns),
                "required": ["Reached.on.Time_Y.N"],
                "message": "SCHEMA MISMATCH: Cannot map delivery status column",
            })

        col = df['Reached.on.Time_Y.N']
        if col.dtype == object:
            df['Reached.on.Time_Y.N'] = col.map(
                lambda x: 1 if str(x).strip().upper() in ['Y', 'YES', '1', 'TRUE'] else 0
            ).astype(int)
        else:
            df['Reached.on.Time_Y.N'] = pd.to_numeric(col, errors='coerce').fillna(0).astype(int)

        if 'ID' not in df.columns:
            df['ID'] = range(1, len(df) + 1)
        for cat, default in [('Warehouse_block','A'),('Mode_of_Shipment','Ship'),
                              ('Product_importance','Medium'),('Gender','M')]:
            if cat not in df.columns:
                df[cat] = default

        df = _sanitize_numeric_columns(df)
        df = _fill_missing_with_means(df)

        new_kernel     = MIMIKernel(df, _session.get("mu", 150.0))
        # GAP 3 FIX: checkpoint=False forces cold fit on new customer data.
        # Without this, uploading Blue Dart data would silently load the
        # Safexpress model from mimi_kernel_v1.joblib — a silent data fraud.
        new_crit_rho   = new_kernel.fit_lr(checkpoint=False)

        _session["mimi"]         = new_kernel
        _session["refresh_count"] = 0
        _session["rho_history"]   = []
        _session["dataset_name"]  = file.filename or "UPLOADED_DATASET"
        # MISSING 9: track csv upload for usage analytics
        _asyncio.create_task(_track_usage(key, "csv_upload", {"filename": file.filename, "rows": len(df)}))
        # Reset atomic counters on new dataset upload
        try:
            await metrics_col.replace_one(
                {"_id": "counters"},
                {"_id": "counters", "diverted_units": 0, "revenue_saved": 0.0,
                 "reset_at": datetime.now(timezone.utc)},
                upsert=True
            )
        except Exception as e:
            logger.warning(f"Metrics reset failed: {e}")

        g_rho = new_kernel.global_rho()
        return {
            "success":          True,
            "n_total":          len(df),
            "new_rho":          round(g_rho, 4),
            "new_critical_rho": new_crit_rho,
            "message":          f"MIMI Kernel reinitialized. ρ={g_rho:.4f}, ρ_c={new_crit_rho:.4f}",
            "dataset_name":     _session["dataset_name"],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upload error: {e}")
        _asyncio.create_task(log_system_error("upload_dataset", e, "ERROR"))
        raise HTTPException(status_code=400, detail=f"CSV parse error: {str(e)}")


@api_router.post("/kernel/stream-batch")
async def stream_batch(
    n: int = 100,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Demo shipment batch injection — DIAMOND AUDIT NOTE:
    RNG below is isolated to this demo endpoint only.
    The Kalman kernel (get_kernel_state, v1/intercept) receives only
    deterministic eff_rho — zero random input.
    """
    key = require_api_key(api_key)
    _session = _get_session(key)
    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")

    # Demo RNG — generates synthetic arrivals for dashboard stress testing only
    rng        = np.random.default_rng()
    rho_base   = mimi.failure_rate()
    late_prob  = float(np.clip(rho_base + rng.normal(0, 0.018), 0.55, 0.98))

    new_rows = pd.DataFrame({
        'ID':                  range(mimi.n_total + 1, mimi.n_total + n + 1),
        # BUG 3 FIX: Block E was silently excluded. Now uses live topology or A-F inclusive.
        # If client has Block G, H, Z — they appear in stream-batch too, not just uploaded data.
        'Warehouse_block':     rng.choice(
            _all_blocks if _all_blocks else ['A','B','C','D','E','F'],
            n
        ),
        'Mode_of_Shipment':    rng.choice(['Ship','Flight','Road'], n, p=[0.55,0.33,0.12]),
        'Customer_care_calls': rng.integers(1, 8, n).astype(int),
        'Customer_rating':     rng.integers(1, 6, n).astype(int),
        'Cost_of_the_Product': rng.integers(96, 310, n).astype(int),
        'Prior_purchases':     rng.integers(2, 8, n).astype(int),
        'Product_importance':  rng.choice(['Low','Medium','High'], n, p=[0.60,0.25,0.15]),
        'Gender':              rng.choice(['F','M'], n),
        'Discount_offered':    rng.integers(0, 66, n).astype(int),
        'Weight_in_gms':       rng.integers(1000, 7100, n).astype(int),
        'Reached.on.Time_Y.N': rng.choice([0, 1], n, p=[late_prob, 1.0 - late_prob]).astype(int),
    })

    mimi.df      = pd.concat([mimi.df, new_rows], ignore_index=True)
    mimi.n_total = len(mimi.df)
    mimi.recalculate_lambdas()

    new_rho = mimi.global_rho()
    eff_s, casc_s = _compute_cascade(mimi.hubs)
    diverted      = mimi.diversion_units_calculated(eff_s, casc_s)
    cost_per = _settings_cache.get("cost_per_failure", mimi.LEAKAGE_SEED)
    if diverted > 0:
        # V7 P1: atomic $inc — worker-safe
        _asyncio.create_task(atomic_inc_metrics(diverted, round(diverted * cost_per, 2)))
    _session["refresh_count"] += 1

    metrics = await get_global_metrics()
    return {
        "success":        True,
        "injected":       n,
        "new_n_total":    mimi.n_total,
        "new_rho":        round(new_rho, 4),
        "diverted":       diverted,
        "total_diverted": metrics["diverted_units"],
        "revenue_saved":  metrics["revenue_saved"],
    }


@api_router.post("/kernel/set-mu")
async def set_mu(
    data: MuUpdate,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    key = require_api_key(api_key)
    _session = _get_session(key)
    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")
    if not (10 <= data.mu <= 1000):
        raise HTTPException(status_code=400, detail="μ must be between 10 and 1000")
    mimi.update_mu(data.mu)
    _session["mu"] = data.mu
    # write μ to dedicated hub_settings_col — institutional memory
    # Survives: server restarts, deployments, container rebuilds
    try:
        await hub_settings_col.update_one(
            {"_id": "global_mu"},
            {"$set": {
                "mu":         data.mu,
                "updated_at": datetime.now(timezone.utc),
                "set_by":     "operator",
                "version":    "SITI Intelligence",
            }},
            upsert=True
        )
        logger.info(f"[MU] μ={data.mu} persisted to hub_settings_col")
    except Exception as e:
        logger.warning(f"[MU] Persist failed (non-fatal — μ active in RAM): {e}")
    return {
        "success":       True,
        "mu":            data.mu,
        "new_global_rho": round(mimi.global_rho(), 4),
        "persisted":     True,
        "note":          f"μ={data.mu} will survive server restart",
    }


# ─── ENTERPRISE INTEGRATION API ──────────────────────────────────────────────

class ShipmentRecord(BaseModel):
    id:                  str
    warehouse_block:     str = "A"
    mode_of_shipment:    str = "Ship"
    weight_gms:          float = 3000
    cost:                float = 200
    product_importance:  str = "Medium"
    customer_care_calls: int = 3

class InterceptPayload(BaseModel):
    shipments: List[ShipmentRecord] = []
    config: dict = {}

@api_router.post("/v1/intercept")
async def intercept_endpoint(
    payload: InterceptPayload,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Enterprise interception endpoint — SAP/Oracle ERP integration.
    ACTUALLY PROCESSES incoming shipment data:
      1. Parses shipment list → derives arrival rate λ
      2. Feeds λ into 2D Kalman per hub
      3. Returns per-hub ρ prediction + DIVERSION_REQUIRED boolean
    Protected: requires X-API-KEY header.
    """
    key = require_api_key(api_key)
    _session = _get_session(key)
    _session["api_requests"] += 1

    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")

    # ── Parse payload & derive λ ──────────────────────────────────────
    shipments    = payload.shipments
    if not shipments:
        raise HTTPException(status_code=422, detail="shipments list is empty")
    config       = payload.config
    mu_override  = float(config.get("mu", mimi.mu))
    threshold    = float(config.get("threshold", mimi.critical_rho))

    if shipments:
        # Count shipments per block — uses live _all_blocks (dynamic topology)
        # Dynamic: use actual blocks from dataset, not hardcoded list
        _live_blocks = _all_blocks if _all_blocks else ['A','B','C','D','E','F']
        block_counts = {b: 0 for b in _live_blocks}
        for s in shipments:
            blk = s.warehouse_block.upper()
            if blk in block_counts:
                block_counts[blk] += 1

        window_hours = max(float(config.get("window_hours", 0.25)), 0.01)

        # Derive λ per hub from live _hub_block_map — works for any number of hubs
        derived_lambdas = {
            hub_name: sum(block_counts.get(b, 0) for b in blocks) / window_hours
            for hub_name, blocks in _hub_block_map.items()
        }

        hub_predictions = []
        for name in list(_hub_block_map.keys()):
            hub       = mimi.hubs[name]
            new_lam   = derived_lambdas[name]
            eff_rho   = new_lam / mu_override if mu_override > 0 else 0
            # Feed real derived ρ into Kalman — this is live payload-driven prediction
            kalman    = hub.kalman_step_2d(float(np.clip(eff_rho, 0.0, 1.5)))
            hub_predictions.append({
                "hub":              name,
                "blocks":            _get_hub_blocks(name),
                "shipments_in_batch": sum(block_counts.get(b, 0) for b in _get_hub_blocks(name)),
                "derived_lambda":   round(new_lam, 2),
                "mu":               round(mu_override, 2),
                "rho_current":      round(eff_rho, 4),
                "rho_t1_15min":     kalman["rho_t1"],
                "rho_t3_45min":     kalman["rho_t3"],
                "rho_dot":          kalman["rho_dot"],
                "diversion_required": eff_rho > threshold,
                "saturation_risk":  kalman["rho_t3"] >= threshold,
            })

        diversion_required = any(h["diversion_required"] for h in hub_predictions)
        highest_rho_hub    = max(hub_predictions, key=lambda h: h["rho_current"])
        n_shipments        = len(shipments)

    else:
        # No shipments in payload — return current network state
        effective, cascade = _compute_cascade(mimi.hubs)
        hub_predictions = [{
            "hub": name, "rho_current": round(effective[name] / mimi.hubs[name].mu, 4),
            "derived_lambda": round(effective[name], 2), "diversion_required": False,
        } for name in list(_hub_block_map.keys()) if name in mimi.hubs]
        diversion_required = mimi.global_rho() > threshold
        highest_rho_hub    = max(hub_predictions, key=lambda h: h["rho_current"])
        n_shipments        = 0

    # Log to MongoDB
    try:
        await api_log_col.insert_one({
            "timestamp":    datetime.now(timezone.utc),
            "endpoint":     "/v1/intercept",
            "n_shipments":  n_shipments,
            "diversion_req": diversion_required,
            "api_key_prefix": api_key[:8] + "..." if api_key else "unknown",
        })
    except Exception as e:
        logger.warning(f"API log persist failed: {e}")

    return {
        "status":              "collapse" if highest_rho_hub["rho_current"] >= 0.85
                               else "critical" if highest_rho_hub["rho_current"] > 0.80
                               else "nominal",
        "shipments_processed": n_shipments,
        "window_hours":        float(config.get("window_hours", 0.25)),
        "hub_predictions":     hub_predictions,
        "network": {
            "diversion_required": diversion_required,
            "recommended_action": "DIVERT" if diversion_required else
                                  "MONITOR" if any(h["saturation_risk"] for h in hub_predictions if "saturation_risk" in h)
                                  else "NOMINAL",
            "worst_hub":          highest_rho_hub["hub"],
            "worst_rho":          highest_rho_hub["rho_current"],
        },
        "kalman_method":       "2D_state_vector_rho_rhodot",
        "traceable_to":        "Wankhede_2026_IEEE_CaseNo02028317",
        "timestamp":           datetime.now(timezone.utc).isoformat(),
    }


@api_router.get("/v1/intercept/schema")
async def intercept_schema(api_key: str = Header(..., alias="X-API-KEY")):
    key = api_key.strip()
    require_role(key, {"ADMIN","OPERATOR","INTEGRATOR","READONLY"}, "GET /v1/intercept/schema")
    return {
        "endpoint":    "/api/v1/intercept",
        "method":      "POST",
        "description": "Real-time shipment interception. Parses incoming data, derives λ, runs 2D Kalman, returns per-hub ρ prediction.",
        "auth":        "X-API-KEY header required",
        "request_schema": {
            "shipments": [{"id": "string", "warehouse_block": "A|B|C|D|F",
                           "mode_of_shipment": "Ship|Flight|Road",
                           "weight_gms": "number", "cost": "number",
                           "product_importance": "Low|Medium|High",
                           "customer_care_calls": "number (1-7)"}],
            "config": {"mu": "number (default: 150)", "threshold": "number (default: 0.85)",
                       "window_hours": "number (default: 0.25 = 15min)"},
        },
        "response_schema": {
            "status": "nominal|critical|collapse",
            "shipments_processed": "number",
            "hub_predictions": [{
                "hub": "string", "rho_current": "number", "rho_t1_15min": "number",
                "rho_t3_45min": "number", "diversion_required": "boolean",
            }],
            "network": {"diversion_required": "boolean", "recommended_action": "NOMINAL|MONITOR|DIVERT"},
        },
        "rate_limit":  "Enterprise Tier SLA - Tiered by API Key",
        "sla":         "P99 < 200ms",
    }


# ─── HUMAN-IN-THE-LOOP DECISION ENDPOINT ─────────────────────────────────────


class TickPayload(BaseModel):
    hub:         Optional[str]   = None
    lambda_rate: Optional[float] = None

class DecisionPayload(BaseModel):
    alert_id:    str = ""
    hub:         str
    rho:         float
    action:      str           # "APPROVED" | "DISMISSED"
    directive:   str = ""      # text of the directive that was acted on
    operator_id: str = "ops"   # future: real user identity

@api_router.post("/decisions/log")
async def log_decision(
    payload: DecisionPayload,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Human-in-the-loop audit trail.
    Every APPROVE or DISMISS action is timestamped and written to MongoDB.
    Builds institutional trust — auditors can replay every decision made.
    Protected: requires X-API-KEY header.
    """
    key = require_api_key(api_key)
    _session = _get_session(key)
    require_role(key, {"ADMIN", "OPERATOR"}, "POST /decisions/log")
    ts = datetime.now(timezone.utc)
    doc = {
        "timestamp":   ts,
        "hub":         payload.hub,
        "rho_at_decision": round(payload.rho, 4),
        "action":      payload.action,       # APPROVED or DISMISSED
        "directive":   payload.directive,
        "operator_id": payload.operator_id,
        "alert_id":    payload.alert_id,
        "dataset":     _session.get("dataset_name", "SAFEXPRESS_CASE_02028317"),
    }
    try:
        result = await decisions_col.insert_one(doc)
        inserted_id = str(result.inserted_id)
    except Exception as e:
        logger.error(f"Decision log failed: {e}")
        _asyncio.create_task(log_system_error("log_decision", e, "CRITICAL"))
        raise HTTPException(status_code=500, detail="Decision could not be persisted")

    logger.info(f"[DECISION] {payload.action} by {payload.operator_id} on Hub {payload.hub} (ρ={payload.rho:.4f})")
    return {
        "logged":     True,
        "action":     payload.action,
        "hub":        payload.hub,
        "timestamp":  ts.isoformat(),
        "record_id":  inserted_id,
        "message":    f"Decision '{payload.action}' recorded for Hub {payload.hub} at ρ={payload.rho:.4f}",
    }


@api_router.get("/decisions/history")
async def get_decision_history(
    limit: int = 50,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """Return last N human decisions for audit display."""
    require_api_key(api_key)
    try:
        cursor = decisions_col.find(
            {}, {"_id": 0}
        ).sort("timestamp", -1).limit(limit)
        docs = await cursor.to_list(length=limit)
        for d in docs:
            if isinstance(d.get("timestamp"), datetime):
                d["timestamp"] = d["timestamp"].isoformat()
        return {"count": len(docs), "decisions": list(reversed(docs))}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── USER SETTINGS / COST CONFIGURATOR ───────────────────────────────────────

class CostSettings(BaseModel):
    cost_per_failure:   float        # ₹ per high-importance delivery failure
    truck_transit_cost: float        # ₹ per unit truck transit/diversion cost
    webhook_url:        str = ""     # Optional: URL to POST alerts to client's systems

@api_router.get("/settings")
async def get_settings(api_key: str = Header(alias="X-API-KEY", default=None)):
    """Return current cost configuration."""
    require_api_key(api_key)
    return {
        "cost_per_failure":   _settings_cache["cost_per_failure"],
        "truck_transit_cost": _settings_cache["truck_transit_cost"],
        "leakage_seed":       _settings_cache["cost_per_failure"],  # alias for frontend
        "webhook_url":        _settings_cache.get("webhook_url", ""),
    }

@api_router.post("/settings")
async def update_settings(
    data: CostSettings,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Update cost parameters — changes take effect immediately.
    The $X.XXM hero metric and revenue_saved calculations use these values
    on the very next /kernel/state call.
    Protected: requires X-API-KEY header.
    """
    require_api_key(api_key)
    if not (0.01 <= data.cost_per_failure <= 10000):
        raise HTTPException(status_code=400, detail="cost_per_failure must be between 0.01 and 10000")
    if not (0.01 <= data.truck_transit_cost <= 10000):
        raise HTTPException(status_code=400, detail="truck_transit_cost must be between 0.01 and 10000")

    _settings_cache["cost_per_failure"]   = data.cost_per_failure
    _settings_cache["truck_transit_cost"] = data.truck_transit_cost
    _settings_cache["webhook_url"]        = (data.webhook_url or "").strip()

    # Persist to MongoDB so settings survive restarts
    try:
        await settings_col.replace_one(
            {"_id": "global"},
            {"_id": "global", **_settings_cache, "updated_at": datetime.now(timezone.utc)},
            upsert=True
        )
    except Exception as e:
        logger.warning(f"Settings persist failed (non-fatal): {e}")

    # Recompute current annualized exposure with new cost
    mimi = _session.get("mimi")
    new_exposure = mimi.annualized_exposure if mimi else 0

    logger.info(f"[SETTINGS] cost_per_failure={data.cost_per_failure}, truck_transit_cost={data.truck_transit_cost}")
    return {
        "updated":            True,
        "cost_per_failure":   data.cost_per_failure,
        "truck_transit_cost": data.truck_transit_cost,
        "new_annualized_exposure": new_exposure,
        "message":            f"Cost config updated. New annualized exposure: ₹{new_exposure:,.0f}",
    }




@api_router.get("/metrics")
async def get_metrics(api_key: str = Header(alias="X-API-KEY", default=None)):
    """
    SITI Intelligence: Atomic global metrics — consistent across all workers.
    Revenue Saved and Diverted Units read from MongoDB, not RAM.
    """
    require_api_key(api_key)
    m = await get_global_metrics()
    return {
        "diverted_units": m["diverted_units"],
        "revenue_saved":  m["revenue_saved"],
        "source":         "mongodb:global_metrics (atomic)",
        "workers":        "consistent — $inc operations",
    }


@api_router.get("/system/logs")
async def get_system_logs(
    limit: int = 100,
    severity: str = "",
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    SITI Intelligence: Remote error visibility — debug without SSH.
    Returns recent system errors from MongoDB system_logs.
    ADMIN only — contains internal error details.
    """
    key = require_api_key(api_key)
    require_role(key, {"ADMIN"}, "GET /system/logs")
    try:
        query = {"severity": severity.upper()} if severity else {}
        cursor = system_logs_col.find(query, {"_id": 0}).sort("timestamp", -1).limit(limit)
        docs   = await cursor.to_list(length=limit)
        for d in docs:
            if isinstance(d.get("timestamp"), datetime):
                d["timestamp"] = d["timestamp"].isoformat()
        return {
            "count":   len(docs),
            "logs":    docs,
            "source":  "mongodb:system_logs",
            "version": "SITI Intelligence",
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ─── SITI: DYNAMIC TOPOLOGY MANAGEMENT API ──────────────────────────────────────

class HubConfig(BaseModel):
    name:   str
    blocks: List[str]
    mu:     float = 150.0
    order:  int   = 99

@api_router.get("/network/hubs")
async def list_hubs(api_key: str = Header(alias="X-API-KEY", default=None)):
    """Return current hub topology from MongoDB network_config."""
    require_api_key(api_key)
    try:
        cursor = network_col.find({}, {"_id": 1, "blocks": 1, "mu": 1, "order": 1})
        docs   = await cursor.to_list(length=50)
        hubs   = [{"name": d["_id"], "blocks": d.get("blocks", []),
                   "mu": d.get("mu", 150.0), "order": d.get("order", 99)} for d in docs]
        hubs.sort(key=lambda h: h["order"])
        return {"hub_count": len(hubs), "hubs": hubs, "source": "mongodb:network_config",
                "live_map": _hub_block_map}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/network/hubs")
async def add_hub(
    data: HubConfig,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Add or update a hub. Hot-reloads into live kernel immediately.
    If a 4th hub is added here, the dashboard renders it on the next poll.
    """
    key = require_api_key(api_key)
    _session = _get_session(key)
    require_role(key, {"ADMIN", "OPERATOR"}, "POST /network/hubs")
    if not data.name or not data.blocks:
        raise HTTPException(status_code=400, detail="name and blocks are required")
    cleaned_blocks = [b.upper().strip() for b in data.blocks if b.strip()]
    if not cleaned_blocks:
        raise HTTPException(status_code=400, detail="at least one block required")

    doc = {"_id": data.name, "blocks": cleaned_blocks, "mu": data.mu,
           "order": data.order, "created_at": datetime.now(timezone.utc)}
    try:
        await network_col.replace_one({"_id": data.name}, doc, upsert=True)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    global _hub_block_map, _all_blocks
    _hub_block_map[data.name] = cleaned_blocks
    _all_blocks = sorted(set(b for blocks in _hub_block_map.values() for b in blocks))

    mimi: MIMIKernel = _session.get("mimi")
    if mimi and data.name not in mimi.hubs:
        hub_df = mimi.df[mimi.df['Warehouse_block'].isin(cleaned_blocks)]
        lambda_rate = len(hub_df) / T_OPERATIONAL
        mimi.hubs[data.name] = HubNode(data.name, lambda_rate, data.mu)

    logger.info(f"[TOPOLOGY] Hub '{data.name}' added/updated: blocks={cleaned_blocks}")
    return {"saved": True, "name": data.name, "blocks": cleaned_blocks,
            "mu": data.mu, "effect": "immediate", "hub_count": len(_hub_block_map)}

@api_router.delete("/network/hubs/{hub_name}")
async def delete_hub(
    hub_name: str,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """Remove a hub from topology. Minimum 1 hub enforced."""
    key = require_api_key(api_key)
    _session = _get_session(key)
    require_role(key, {"ADMIN"}, "DELETE /network/hubs/{hub_name}")
    global _hub_block_map, _all_blocks
    if len(_hub_block_map) <= 1:
        raise HTTPException(status_code=400, detail="Cannot delete last hub")
    try:
        await network_col.delete_one({"_id": hub_name})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    _hub_block_map.pop(hub_name, None)
    _all_blocks = sorted(set(b for blocks in _hub_block_map.values() for b in blocks))
    mimi = _session.get("mimi")
    if mimi: mimi.hubs.pop(hub_name, None)
    return {"deleted": True, "name": hub_name, "remaining_hubs": list(_hub_block_map.keys())}


# ─── FEATURE: JWT AUTH ────────────────────────────────────────────────────────
# JWT tokens for browser sessions — layered on top of existing API key auth.
# Flow: POST /api/auth/login with {api_key} → returns {token, role, expires_in}
# Token is then used as Bearer auth OR X-API-KEY still works (backward compat).
import jwt as _jwt
import time as _time
import hashlib as _hashlib

_JWT_SECRET = os.getenv("JWT_SECRET", _hashlib.sha256(
    os.getenv("API_KEYS", "siti-dev").encode()
).hexdigest())
_JWT_ALG    = "HS256"
_JWT_EXPIRY = 3600 * 8  # 8 hours

class LoginRequest(BaseModel):
    api_key: str

@api_router.post("/auth/login")
async def auth_login(body: LoginRequest):
    """
    Exchange an API key for a JWT session token.
    Returns: {token, role, tenant_id, expires_in, issued_at}
    """
    if body.api_key not in VALID_API_KEYS:
        raise HTTPException(status_code=403, detail={
            "error": "INVALID_KEY",
            "message": "API key not recognised"
        })
    role      = get_key_role(body.api_key)
    tenant_id = _hashlib.sha256(body.api_key.encode()).hexdigest()[:12]
    now       = int(_time.time())
    payload   = {
        "sub":       tenant_id,
        "api_key":   body.api_key,
        "role":      role,
        "iat":       now,
        "exp":       now + _JWT_EXPIRY,
    }
    token = _jwt.encode(payload, _JWT_SECRET, algorithm=_JWT_ALG)
    return {
        "token":      token,
        "role":       role,
        "tenant_id":  tenant_id,
        "expires_in": _JWT_EXPIRY,
        "issued_at":  datetime.now(timezone.utc).isoformat(),
    }

@api_router.post("/auth/verify")
async def auth_verify(request: Request):
    """Verify a JWT token — returns decoded claims or 401."""
    auth_header = request.headers.get("Authorization", "")
    if not auth_header.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Bearer token required")
    token = auth_header.removeprefix("Bearer ").strip()
    try:
        claims = _jwt.decode(token, _JWT_SECRET, algorithms=[_JWT_ALG])
        return {"valid": True, "claims": claims}
    except _jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail={"error": "TOKEN_EXPIRED"})
    except _jwt.InvalidTokenError as e:
        raise HTTPException(status_code=401, detail={"error": "INVALID_TOKEN", "detail": str(e)})


# ─── FEATURE: EMAIL FORENSIC REPORT (SendGrid or SMTP) ───────────────────────
# Generates a forensic PDF and emails it via SendGrid API or fallback SMTP.
# Required env: SENDGRID_KEY=SG.xxx  OR  SMTP_HOST + SMTP_USER + SMTP_PASS
# Endpoint: POST /api/report/email  {recipient_email, tenant_label}

import smtplib as _smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders as _encoders
import io as _io
import base64 as _b64

def _build_forensic_pdf_bytes(kstate_data: dict, tenant_label: str) -> bytes:
    """Build a compact forensic PDF from live kernel state. Returns bytes."""
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas as _canvas
    from reportlab.lib import colors as _colors

    buf = _io.BytesIO()
    c = _canvas.Canvas(buf, pagesize=A4)
    W, H = A4

    BG   = _colors.HexColor('#06070d')
    AMB  = _colors.HexColor('#e8a020')
    RED  = _colors.HexColor('#f0284a')
    GRN  = _colors.HexColor('#1ae87a')
    TXT  = _colors.HexColor('#bfcce8')
    DIM  = _colors.HexColor('#4a5f82')

    c.setFillColor(BG); c.rect(0, 0, W, H, fill=1, stroke=0)

    # Header
    c.setFillColor(AMB); c.setFont('Helvetica-Bold', 20)
    c.drawString(20, H-40, "SITI INTELLIGENCE — FORENSIC REPORT")
    c.setFillColor(TXT); c.setFont('Helvetica', 9)
    c.drawString(20, H-56, f"Tenant: {tenant_label}  ·  Generated: {datetime.now(timezone.utc).strftime('%d %b %Y %H:%M UTC')}")
    c.setFillColor(RED); c.rect(20, H-62, W-40, 1, fill=1, stroke=0)

    irp      = kstate_data.get("inverse_reliability", {})
    exposure = kstate_data.get("annualized_exposure", 0)
    rho      = kstate_data.get("rho", 0)
    n_total  = kstate_data.get("n_total", 0)
    dataset  = kstate_data.get("dataset_name", "UNKNOWN")
    hubs     = kstate_data.get("hubs", [])

    rows = [
        ("Dataset",             dataset),
        ("Records analysed",    f"{n_total:,}"),
        ("Network ρ",           f"{rho:.4f}"),
        ("IRP Gap",             f"+{irp.get('irp_gap_pp', 0):.2f}pp"),
        ("High-imp fail rate",  f"{irp.get('failure_rate', 0)*100:.2f}%"),
        ("Annualised exposure",  f"${exposure:,.0f}"),
        ("Confidence interval", f"{irp.get('ci_95', 'N/A')}"),
        ("Risk flag",           irp.get('at_risk_flag', 'N/A')),
    ]
    y = H - 80
    for label, value in rows:
        c.setFillColor(DIM);  c.setFont('Helvetica', 8.5); c.drawString(20, y, label)
        vc = RED if any(k in label.lower() for k in ['exposure','risk','irp','fail']) else GRN
        c.setFillColor(vc);   c.setFont('Helvetica-Bold', 8.5); c.drawString(180, y, str(value))
        y -= 14

    y -= 10
    c.setFillColor(AMB); c.setFont('Helvetica-Bold', 10)
    c.drawString(20, y, "HUB BREAKDOWN")
    y -= 14
    for hub in hubs[:8]:
        hub_name = hub.get('name', '?')
        hub_rho  = hub.get('rho', 0)
        col = RED if hub_rho > 0.85 else _colors.HexColor('#e8a020') if hub_rho > 0.75 else GRN
        c.setFillColor(TXT);  c.setFont('Helvetica', 8); c.drawString(20, y, hub_name)
        c.setFillColor(col);  c.setFont('Helvetica-Bold', 8)
        c.drawString(120, y, f"ρ={hub_rho:.4f}  λ={hub.get('lambda_rate',0):.0f}/hr")
        y -= 12

    c.setFillColor(DIM); c.setFont('Helvetica', 7)
    c.drawString(20, 20, "SITI Intelligence · Confidential Forensic Report · Not for external distribution")
    c.save()
    return buf.getvalue()

class EmailReportRequest(BaseModel):
    recipient_email: str
    tenant_label:    str = "SITI Client"

@api_router.post("/report/email")
async def email_forensic_report(
    body: EmailReportRequest,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Generate forensic PDF from live kernel state and email it.
    Uses SendGrid if SENDGRID_KEY is set, else SMTP.
    Required env vars:
      SENDGRID_KEY=SG.xxxx  (preferred)
      OR: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, REPORT_FROM_EMAIL
    """
    key     = require_api_key(api_key)
    session = _get_session(key)
    mimi    = session.get("mimi")
    if not mimi:
        raise HTTPException(status_code=400, detail="No dataset loaded — upload CSV first")

    irp      = mimi.inverse_reliability()
    exposure = mimi.annualized_exposure
    hubs_data = [
        {"name": h.name, "rho": round(h.rho, 4), "lambda_rate": round(h.lambda_rate, 1)}
        for h in mimi.hubs.values()
    ]
    kstate_snapshot = {
        "rho":                  round(mimi.global_rho(), 4),
        "n_total":              mimi.n_total,
        "dataset_name":         session.get("dataset_name", "UNKNOWN"),
        "inverse_reliability":  irp,
        "annualized_exposure":  round(float(exposure), 2),
        "hubs":                 hubs_data,
    }
    try:
        pdf_bytes = _build_forensic_pdf_bytes(kstate_snapshot, body.tenant_label)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"PDF generation failed: {e}")

    sendgrid_key = os.getenv("SENDGRID_KEY", "")
    smtp_host    = os.getenv("SMTP_HOST", "")

    if sendgrid_key and sendgrid_key.startswith("SG."):
        # SendGrid REST API (no extra package — pure httpx)
        import httpx as _httpx
        pdf_b64 = _b64.b64encode(pdf_bytes).decode()
        payload = {
            "personalizations": [{"to": [{"email": body.recipient_email}]}],
            "from":             {"email": os.getenv("REPORT_FROM_EMAIL", "noreply@siti-intelligence.com")},
            "subject":          f"SITI Forensic Report — {body.tenant_label}",
            "content":          [{"type": "text/plain", "value":
                                  f"Forensic report for {body.tenant_label} attached.\n\n"
                                  f"Network ρ={kstate_snapshot['rho']} · "
                                  f"Exposure=${kstate_snapshot['annualized_exposure']:,.0f}"}],
            "attachments": [{
                "content":  pdf_b64,
                "filename": f"SITI_Forensic_{body.tenant_label.replace(' ','_')}.pdf",
                "type":     "application/pdf",
                "disposition": "attachment",
            }]
        }
        try:
            async with _httpx.AsyncClient(timeout=10) as hx:
                resp = await hx.post(
                    "https://api.sendgrid.com/v3/mail/send",
                    json=payload,
                    headers={"Authorization": f"Bearer {sendgrid_key}"}
                )
            if resp.status_code in (200, 202):
                return {"sent": True, "channel": "sendgrid", "to": body.recipient_email,
                        "pdf_size_kb": round(len(pdf_bytes)/1024, 1)}
            else:
                raise HTTPException(status_code=502, detail=f"SendGrid error {resp.status_code}: {resp.text[:200]}")
        except _httpx.RequestError as e:
            raise HTTPException(status_code=502, detail=f"SendGrid network error: {e}")

    elif smtp_host:
        msg = MIMEMultipart()
        msg['From']    = os.getenv("REPORT_FROM_EMAIL", os.getenv("SMTP_USER", "noreply@siti.ai"))
        msg['To']      = body.recipient_email
        msg['Subject'] = f"SITI Forensic Report — {body.tenant_label}"
        msg.attach(MIMEText(
            f"Forensic report for {body.tenant_label} is attached.\n\n"
            f"Network ρ={kstate_snapshot['rho']}  ·  "
            f"Annualised exposure: ${kstate_snapshot['annualized_exposure']:,.0f}\n\n"
            f"— SITI Intelligence", 'plain'
        ))
        part = MIMEBase('application', 'octet-stream')
        part.set_payload(pdf_bytes)
        _encoders.encode_base64(part)
        part.add_header('Content-Disposition',
                        f'attachment; filename="SITI_Forensic_{body.tenant_label}.pdf"')
        msg.attach(part)
        try:
            smtp_port = int(os.getenv("SMTP_PORT", "587"))
            with _smtplib.SMTP(smtp_host, smtp_port, timeout=10) as s:
                s.starttls()
                s.login(os.getenv("SMTP_USER",""), os.getenv("SMTP_PASS",""))
                s.send_message(msg)
            return {"sent": True, "channel": "smtp", "to": body.recipient_email,
                    "pdf_size_kb": round(len(pdf_bytes)/1024, 1)}
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"SMTP send failed: {e}")
    else:
        # No email configured — return the PDF as base64 so frontend can trigger browser download
        pdf_b64 = _b64.b64encode(pdf_bytes).decode()
        return {
            "sent":          False,
            "channel":       "download",
            "pdf_base64":    pdf_b64,
            "pdf_size_kb":   round(len(pdf_bytes)/1024, 1),
            "message":       "No SENDGRID_KEY or SMTP_HOST set. PDF returned as base64 for browser download.",
            "to":            body.recipient_email,
        }


# ─── FEATURE: CSV ONBOARDING — column schema detection ───────────────────────
# Helps first-time users map their messy CSV headers BEFORE committing an upload.
# POST /api/onboarding/detect-schema  {file} → returns column mapping + confidence

@api_router.post("/onboarding/detect-schema")
async def detect_csv_schema(
    file: UploadFile = File(...),
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Dry-run schema detection: upload CSV, get back column mapping + gaps.
    Does NOT reinitialise the kernel — safe to call before a real upload.
    """
    require_api_key(api_key)
    try:
        content = await file.read()
        df_raw  = _parse_csv_resilient(content)
        df_map  = _fuzzy_map_columns(df_raw.copy())
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"CSV parse failed: {e}")

    REQUIRED   = {'Reached.on.Time_Y.N'}
    OPTIONAL   = {'Warehouse_block','Mode_of_Shipment','Product_importance',
                   'Cost_of_the_Product','Customer_rating','Customer_care_calls'}
    SITI_COLS  = REQUIRED | OPTIONAL

    mapped    = {c for c in SITI_COLS if c in df_map.columns}
    missing   = SITI_COLS - mapped
    extra     = [c for c in df_raw.columns if c not in df_map.columns]

    col_report = []
    for orig_col in df_raw.columns:
        mapped_to = None
        for siti_col in SITI_COLS:
            if siti_col in df_map.columns:
                # Check if this original col became this siti col
                if df_raw[orig_col].equals(df_map[siti_col]):
                    mapped_to = siti_col
                    break
        col_report.append({
            "original":  orig_col,
            "mapped_to": mapped_to,
            "status":    "MAPPED" if mapped_to else "UNMAPPED"
        })

    can_upload = REQUIRED.issubset(mapped)
    return {
        "filename":        file.filename,
        "rows":            len(df_raw),
        "original_cols":   list(df_raw.columns),
        "column_mapping":  col_report,
        "mapped_count":    len(mapped),
        "missing_required": list(REQUIRED - mapped),
        "missing_optional": list(OPTIONAL - mapped),
        "can_upload":      can_upload,
        "confidence":      round(len(mapped) / len(SITI_COLS), 2),
        "message": (
            "✅ Schema valid — ready to upload" if can_upload
            else f"❌ Cannot upload: missing required column(s): {list(REQUIRED - mapped)}"
        )
    }

# ─── MISSING 9: USAGE ANALYTICS HELPER ────────────────────────────────────────
async def _track_usage(api_key: str, event: str, meta: dict = None):
    """
    Upsert usage counters per API key. Fire-and-forget — never blocks requests.
    Tracked: state_view_count, csv_upload_count, alert_count, last_seen
    """
    try:
        now = datetime.now(timezone.utc)
        inc_field = f"counts.{event}"
        update = {
            "$inc":  {inc_field: 1},
            "$set":  {"last_seen": now, "api_key_prefix": api_key[:8] + "..."},
            "$setOnInsert": {"first_seen": now, "api_key": api_key},
        }
        if meta:
            update["$push"] = {"recent_events": {"$each": [{"event": event, "ts": now, **meta}], "$slice": -20}}
        await usage_col.update_one({"_id": api_key}, update, upsert=True)
    except Exception as _ue:
        logger.debug(f"[USAGE] Track failed (non-fatal): {_ue}")


# ─── MISSING 1: ADMIN KEY GENERATOR ──────────────────────────────────────────
# POST /api/admin/create-key  {client_name, role}  → instant API key
# The key is persisted in MongoDB AND hot-loaded into VALID_API_KEYS in memory.
# No server restart needed. Works at 2am when a buyer says yes.
import secrets as _secrets

class CreateKeyRequest(BaseModel):
    client_name: str
    role:        str = "OPERATOR"
    notes:       str = ""  # optional memo — visible in /admin/clients

@api_router.post("/admin/create-key")
async def create_client_key(
    body: CreateKeyRequest,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    ADMIN-only: Provision a new API key for a client instantly.
    Key is live in memory immediately + persisted to MongoDB.
    No .env edit. No restart. Works at 2am.
    """
    key = require_api_key(api_key)
    require_role(key, {"ADMIN"}, "POST /admin/create-key")

    role = body.role.upper()
    if role not in _VALID_ROLES:
        raise HTTPException(status_code=400, detail=f"Invalid role. Must be one of: {sorted(_VALID_ROLES)}")

    safe_name  = "".join(c if c.isalnum() or c == "-" else "_" for c in body.client_name.lower())[:24]
    new_key    = f"siti-{safe_name}-{_secrets.token_hex(10)}"
    created_at = datetime.now(timezone.utc)

    # Persist to MongoDB — survives restart
    await api_keys_col.insert_one({
        "_id":          new_key,
        "client_name":  body.client_name,
        "role":         role,
        "notes":        body.notes,
        "created_at":   created_at,
        "created_by":   api_key[:8] + "...",
        "active":       True,
    })

    # Hot-load into memory — live immediately, no restart
    _KEY_ROLE_MAP[new_key] = role
    VALID_API_KEYS.add(new_key)

    logger.info(f"[ADMIN] Key created: {new_key[:20]}... role={role} client='{body.client_name}'")
    return {
        "api_key":     new_key,
        "client_name": body.client_name,
        "role":        role,
        "created_at":  created_at.isoformat(),
        "active":      True,
        "usage": f"Add header: X-API-KEY: {new_key}",
    }


@api_router.delete("/admin/revoke-key/{target_key}")
async def revoke_client_key(
    target_key: str,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """ADMIN-only: Revoke a client API key instantly. Removes from memory + marks inactive in DB."""
    key = require_api_key(api_key)
    require_role(key, {"ADMIN"}, "DELETE /admin/revoke-key")
    if target_key == key:
        raise HTTPException(status_code=400, detail="Cannot revoke your own key")

    VALID_API_KEYS.discard(target_key)
    _KEY_ROLE_MAP.pop(target_key, None)
    await api_keys_col.update_one({"_id": target_key}, {"$set": {"active": False, "revoked_at": datetime.now(timezone.utc)}})
    logger.info(f"[ADMIN] Key revoked: {target_key[:20]}...")
    return {"revoked": True, "key_prefix": target_key[:16] + "..."}


# ─── MISSING 3: MULTI-CASE CLIENT DASHBOARD ──────────────────────────────────
# GET /api/admin/clients  → table of all provisioned clients + live IRP status

@api_router.get("/admin/clients")
async def list_clients(
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    ADMIN-only: List all provisioned clients with their last activity,
    current rho, case status, and usage stats.
    """
    key = require_api_key(api_key)
    require_role(key, {"ADMIN"}, "GET /admin/clients")

    # Pull all keys from MongoDB (provisioned keys + .env keys)
    try:
        cursor  = api_keys_col.find({})
        db_keys = await cursor.to_list(length=200)
    except Exception:
        db_keys = []

    clients = []
    for doc in db_keys:
        client_key = doc["_id"]
        session    = _sessions.get(client_key)
        mimi       = session.get("mimi") if session else None

        # Usage stats
        usage_doc = None
        try:
            usage_doc = await usage_col.find_one({"_id": client_key})
        except Exception:
            pass

        clients.append({
            "client_name":   doc.get("client_name", "Unknown"),
            "key_prefix":    client_key[:16] + "...",
            "role":          doc.get("role", "OPERATOR"),
            "active":        doc.get("active", True),
            "created_at":    doc["created_at"].isoformat() if isinstance(doc.get("created_at"), datetime) else str(doc.get("created_at", "")),
            "notes":         doc.get("notes", ""),
            "current_rho":   round(mimi.global_rho(), 4) if mimi else None,
            "dataset_name":  session.get("dataset_name") if session else None,
            "irp_gap_pp":    round(float(mimi.inverse_reliability().get("irp_gap_pp", 0)), 2) if mimi else None,
            "last_seen":     usage_doc["last_seen"].isoformat() if usage_doc and isinstance(usage_doc.get("last_seen"), datetime) else None,
            "state_views":   usage_doc.get("counts", {}).get("state_view", 0) if usage_doc else 0,
            "csv_uploads":   usage_doc.get("counts", {}).get("csv_upload", 0) if usage_doc else 0,
            "alert_count":   _alert_state.get("alert_count", 0),
        })

    # Also list .env-provisioned keys that aren't in MongoDB
    env_only = [k for k in VALID_API_KEYS if k not in {d["_id"] for d in db_keys}]
    for ek in env_only:
        session = _sessions.get(ek)
        mimi    = session.get("mimi") if session else None
        clients.append({
            "client_name":  f"[env] {ek[:12]}...",
            "key_prefix":   ek[:16] + "...",
            "role":         _KEY_ROLE_MAP.get(ek, "UNKNOWN"),
            "active":       True,
            "created_at":   None,
            "notes":        "Provisioned via .env API_KEYS",
            "current_rho":  round(mimi.global_rho(), 4) if mimi else None,
            "dataset_name": session.get("dataset_name") if session else None,
            "irp_gap_pp":   None,
            "last_seen":    None,
            "state_views":  0,
            "csv_uploads":  0,
            "alert_count":  0,
        })

    return {
        "total_clients": len(clients),
        "active":        sum(1 for c in clients if c["active"]),
        "clients":       clients,
        "generated_at":  datetime.now(timezone.utc).isoformat(),
    }


# ─── MISSING 4: SCHEDULED DAILY EMAIL REPORT ─────────────────────────────────
# Background asyncio task that fires daily at 08:00 UTC.
# Emails forensic PDF to each active client that has REPORT_EMAIL_* set.
# No APScheduler needed — pure asyncio sleep loop.

_daily_report_task = None  # tracked so we can cancel on shutdown

async def _daily_email_loop():
    """
    Infinite loop: sleep until 08:00 UTC daily, then email forensic PDF to
    all active clients that have an email configured.
    Configured per client via: REPORT_EMAIL_<KEY_PREFIX>=address@company.com
    Or set REPORT_EMAIL_DEFAULT for a catch-all.
    """
    import math
    logger.info("[DAILY REPORT] Scheduler started — fires daily at 08:00 UTC")
    while True:
        try:
            now = datetime.now(timezone.utc)
            # Seconds until next 08:00 UTC
            target_hour = 8
            next_run = now.replace(hour=target_hour, minute=0, second=0, microsecond=0)
            if next_run <= now:
                next_run = next_run.replace(day=next_run.day + 1)
            sleep_sec = (next_run - now).total_seconds()
            logger.info(f"[DAILY REPORT] Next run in {sleep_sec/3600:.1f}h at {next_run.isoformat()}")
            await _asyncio.sleep(sleep_sec)

            # Send to each active session that has data
            sent_count = 0
            for client_key, session in list(_sessions.items()):
                if client_key == "__startup__":
                    continue
                mimi = session.get("mimi")
                if not mimi:
                    continue
                # Look up email: REPORT_EMAIL_<first8chars> or REPORT_EMAIL_DEFAULT
                email_addr = (
                    os.getenv(f"REPORT_EMAIL_{client_key[:8].upper()}", "") or
                    os.getenv("REPORT_EMAIL_DEFAULT", "")
                ).strip()
                if not email_addr:
                    continue

                irp      = mimi.inverse_reliability()
                exposure = mimi.annualized_exposure
                kstate_snapshot = {
                    "rho":                 round(mimi.global_rho(), 4),
                    "n_total":             mimi.n_total,
                    "dataset_name":        session.get("dataset_name", "UNKNOWN"),
                    "inverse_reliability": irp,
                    "annualized_exposure": round(float(exposure), 2),
                    "hubs": [{"name": h.name, "rho": round(h.rho, 4), "lambda_rate": round(h.lambda_rate, 1)}
                             for h in mimi.hubs.values()],
                }
                try:
                    pdf_bytes = _build_forensic_pdf_bytes(kstate_snapshot, session.get("dataset_name", "Client"))
                    # Reuse existing email dispatch — SendGrid or SMTP
                    from email.mime.multipart import MIMEMultipart as _MM
                    from email.mime.text import MIMEText as _MT
                    from email.mime.base import MIMEBase as _MB
                    from email import encoders as _enc
                    import smtplib as _sm, base64 as _b

                    sg_key    = os.getenv("SENDGRID_KEY", "")
                    smtp_host = os.getenv("SMTP_HOST", "")
                    label     = session.get("dataset_name", "Client")

                    if sg_key and sg_key.startswith("SG."):
                        import httpx as _hx
                        pdf_b64 = _b.b64encode(pdf_bytes).decode()
                        payload = {
                            "personalizations": [{"to": [{"email": email_addr}]}],
                            "from":    {"email": os.getenv("REPORT_FROM_EMAIL", "noreply@siti-intelligence.com")},
                            "subject": f"[Daily] SITI Forensic Report — {label} — {now.strftime('%d %b %Y')}",
                            "content": [{"type": "text/plain", "value":
                                f"Daily SITI forensic report for {label}.\n\n"
                                f"ρ={kstate_snapshot['rho']} · Exposure ₹{kstate_snapshot['annualized_exposure']:,.0f}\n"
                                f"IRP Gap: +{irp.get('irp_gap_pp',0):.2f}pp\n\n— SITI Intelligence"}],
                            "attachments": [{
                                "content": pdf_b64,
                                "filename": f"SITI_Daily_{label}_{now.strftime('%Y%m%d')}.pdf",
                                "type": "application/pdf", "disposition": "attachment"
                            }]
                        }
                        async with _hx.AsyncClient(timeout=10) as hx:
                            resp = await hx.post("https://api.sendgrid.com/v3/mail/send",
                                json=payload, headers={"Authorization": f"Bearer {sg_key}"})
                        if resp.status_code in (200, 202):
                            sent_count += 1
                            logger.info(f"[DAILY REPORT] Sent to {email_addr} for {label}")
                    elif smtp_host:
                        msg = _MM(); msg['From'] = os.getenv("SMTP_USER",""); msg['To'] = email_addr
                        msg['Subject'] = f"[Daily] SITI Forensic Report — {label}"
                        msg.attach(_MT(f"Daily report for {label} attached.", 'plain'))
                        part = _MB('application','octet-stream'); part.set_payload(pdf_bytes)
                        _enc.encode_base64(part)
                        part.add_header('Content-Disposition', f'attachment; filename="SITI_Daily_{label}.pdf"')
                        msg.attach(part)
                        with _sm.SMTP(smtp_host, int(os.getenv("SMTP_PORT","587")), timeout=10) as s:
                            s.starttls(); s.login(os.getenv("SMTP_USER",""), os.getenv("SMTP_PASS",""))
                            s.send_message(msg)
                        sent_count += 1
                except Exception as _re:
                    logger.warning(f"[DAILY REPORT] Failed for {email_addr}: {_re}")

            logger.info(f"[DAILY REPORT] Cycle complete — {sent_count} report(s) sent")
        except _asyncio.CancelledError:
            logger.info("[DAILY REPORT] Scheduler cancelled")
            break
        except Exception as _loop_err:
            logger.warning(f"[DAILY REPORT] Loop error: {_loop_err}")
            await _asyncio.sleep(3600)  # back off 1h on error


@api_router.post("/admin/trigger-daily-report")
async def trigger_daily_report_now(
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """ADMIN: Send daily PDF report to all configured recipients right now (test endpoint)."""
    key = require_api_key(api_key)
    require_role(key, {"ADMIN"}, "POST /admin/trigger-daily-report")
    # Force immediate run by temporarily cancelling sleep — just re-trigger the send logic
    sent = []
    for client_key, session in list(_sessions.items()):
        if client_key == "__startup__": continue
        mimi = session.get("mimi")
        if not mimi: continue
        email_addr = (
            os.getenv(f"REPORT_EMAIL_{client_key[:8].upper()}", "") or
            os.getenv("REPORT_EMAIL_DEFAULT", "")
        ).strip()
        sent.append({"key_prefix": client_key[:8] + "...", "email": email_addr or "NOT_CONFIGURED",
                     "has_data": True})
    return {"triggered": True, "sessions_checked": len(sent), "detail": sent,
            "note": "Set REPORT_EMAIL_<KEY_PREFIX8> or REPORT_EMAIL_DEFAULT in .env to receive reports"}


# ─── MISSING 6: CSV EXPORT OF ANALYSIS RESULTS ───────────────────────────────
# GET /api/export/csv  → download hub analysis + IRP scores as spreadsheet

from fastapi.responses import StreamingResponse
import csv as _csv

@api_router.get("/export/csv")
async def export_analysis_csv(
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Download the current kernel analysis as a CSV spreadsheet.
    Includes: hub analysis, IRP scores, failure rates, leakage estimates.
    Enterprise clients can load this directly into Excel/Tableau.
    """
    key     = require_api_key(api_key)
    session = _get_session(key)
    mimi    = session.get("mimi")
    if not mimi:
        raise HTTPException(status_code=400, detail="No dataset loaded — upload CSV first")

    irp       = mimi.inverse_reliability()
    wh_data   = mimi.warehouse_metrics()
    mode_data = mimi.mode_metrics()
    now_str   = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M")

    output = _io.StringIO()
    writer = _csv.writer(output)

    # ── Section 1: Summary ─────────────────────────────────────────────────────
    writer.writerow(["SITI Intelligence — Analysis Export", f"Generated: {now_str} UTC"])
    writer.writerow(["Dataset", session.get("dataset_name", "UNKNOWN")])
    writer.writerow(["Records", mimi.n_total])
    writer.writerow([])

    writer.writerow(["=== IRP ANALYSIS ==="])
    writer.writerow(["Metric", "Value"])
    writer.writerow(["IRP Status",           irp.get("status", "N/A")])
    writer.writerow(["IRP Gap (pp)",          irp.get("irp_gap_pp", 0)])
    writer.writerow(["High-Imp Fail Rate",    f"{irp.get('failure_rate',0)*100:.2f}%"])
    writer.writerow(["High-Imp Late Count",   irp.get("failure_count", 0)])
    writer.writerow(["Total High-Imp",        irp.get("total_high", 0)])
    writer.writerow(["95% CI",                str(irp.get("ci_95", "N/A"))])
    writer.writerow(["Annualised Exposure ₹", round(float(mimi.annualized_exposure), 2)])
    writer.writerow(["Network Rho",           round(mimi.global_rho(), 4)])
    writer.writerow([])

    # ── Section 2: Hub breakdown ───────────────────────────────────────────────
    writer.writerow(["=== HUB ANALYSIS ==="])
    writer.writerow(["Hub Name", "Rho (ρ)", "Lambda (arrivals/hr)", "Mu (capacity/hr)", "Status"])
    for hub in mimi.hubs.values():
        status = "OVERFLOW" if hub.rho >= 0.95 else "CRITICAL" if hub.rho >= 0.85 else "WARNING" if hub.rho >= 0.75 else "NOMINAL"
        writer.writerow([hub.name, round(hub.rho, 4), round(hub.lambda_rate, 1), round(hub.mu, 0), status])
    writer.writerow([])

    # ── Section 3: Warehouse block analysis ───────────────────────────────────
    if wh_data:
        writer.writerow(["=== WAREHOUSE BLOCK ANALYSIS ==="])
        writer.writerow(["Block", "Total Shipments", "Late", "On-Time", "Failure Rate"])
        for row in wh_data:
            writer.writerow([row["block"], row["total"], row["late"], row["on_time"],
                             f"{row['failure_rate']*100:.2f}%"])
        writer.writerow([])

    # ── Section 4: Mode of shipment ───────────────────────────────────────────
    if mode_data:
        writer.writerow(["=== SHIPMENT MODE ANALYSIS ==="])
        writer.writerow(["Mode", "Total", "Late", "Failure Rate"])
        for row in mode_data:
            writer.writerow([row["mode"], row["total"], row["late"], f"{row['rate']*100:.2f}%"])

    output.seek(0)
    filename = f"SITI_Analysis_{now_str}.csv"
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )


# ─── MISSING 9: USAGE ANALYTICS DASHBOARD ────────────────────────────────────
# GET /api/admin/usage  → per-client usage table for renewal conversations

@api_router.get("/admin/usage")
async def get_usage_analytics(
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    ADMIN-only: Per-key usage stats for renewal conversations.
    Shows: uploads, API calls, alert count, last seen, first seen.
    """
    key = require_api_key(api_key)
    require_role(key, {"ADMIN"}, "GET /admin/usage")
    try:
        cursor = usage_col.find({})
        docs   = await cursor.to_list(length=500)
        for d in docs:
            for ts_field in ("last_seen", "first_seen"):
                if isinstance(d.get(ts_field), datetime):
                    d[ts_field] = d[ts_field].isoformat()
            d.pop("_id", None)
            d.pop("recent_events", None)  # strip verbose event log from summary
        return {
            "total_keys_with_activity": len(docs),
            "usage":                    docs,
            "generated_at":             datetime.now(timezone.utc).isoformat(),
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── MISSING 8: RAZORPAY PAYMENT STUB ────────────────────────────────────────
# Webhook receiver for Razorpay payment confirmation.
# When payment.captured fires, auto-provision a client API key.
# Set RAZORPAY_WEBHOOK_SECRET in .env for signature verification.

import hmac as _hmac, hashlib as _hashlib2

class RazorpayWebhookBody(BaseModel):
    event:   str
    payload: dict

@api_router.post("/payments/razorpay-webhook")
async def razorpay_webhook(
    request: Request,
    x_razorpay_signature: str = Header(default=""),
):
    """
    Razorpay webhook receiver. On payment.captured event:
    1. Verify HMAC-SHA256 signature
    2. Extract client name + plan from payment notes
    3. Auto-provision API key via create_client_key logic
    4. Return key in webhook response (Razorpay logs it)

    Setup: In Razorpay Dashboard → Settings → Webhooks → Add URL:
    https://your-domain/api/payments/razorpay-webhook
    """
    body_bytes = await request.body()
    secret     = os.getenv("RAZORPAY_WEBHOOK_SECRET", "")

    if secret:
        expected_sig = _hmac.new(secret.encode(), body_bytes, _hashlib2.sha256).hexdigest()
        if not _hmac.compare_digest(expected_sig, x_razorpay_signature):
            raise HTTPException(status_code=400, detail="Invalid Razorpay signature")

    try:
        data = __import__("json").loads(body_bytes)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON body")

    event = data.get("event", "")
    if event not in ("payment.captured", "subscription.activated"):
        return {"received": True, "action": "ignored", "event": event}

    # Extract client details from payment notes
    payment    = data.get("payload", {}).get("payment", {}).get("entity", {})
    notes      = payment.get("notes", {})
    client_name = notes.get("client_name") or payment.get("email", "razorpay-client")
    plan        = notes.get("plan", "OPERATOR").upper()
    role        = plan if plan in _VALID_ROLES else "OPERATOR"
    amount_inr  = payment.get("amount", 0) / 100  # paise → ₹

    safe_name = "".join(c if c.isalnum() or c == "-" else "_" for c in client_name.lower())[:24]
    new_key   = f"siti-{safe_name}-{_secrets.token_hex(10)}"

    await api_keys_col.insert_one({
        "_id":          new_key,
        "client_name":  client_name,
        "role":         role,
        "notes":        f"Auto-provisioned via Razorpay. Amount: ₹{amount_inr:.0f}. Plan: {plan}",
        "created_at":   datetime.now(timezone.utc),
        "created_by":   "razorpay-webhook",
        "active":       True,
        "payment_id":   payment.get("id", ""),
        "amount_inr":   amount_inr,
    })
    _KEY_ROLE_MAP[new_key] = role
    VALID_API_KEYS.add(new_key)

    logger.info(f"[RAZORPAY] Key auto-provisioned: {new_key[:20]}... client='{client_name}' ₹{amount_inr:.0f}")
    return {
        "received":    True,
        "action":      "key_provisioned",
        "client_name": client_name,
        "role":        role,
        "key_prefix":  new_key[:16] + "...",
        "note":        "Full key logged server-side. Email delivery requires SendGrid setup.",
    }


# ─── APP SETUP ────────────────────────────────────────────────────────────────

app.include_router(api_router)

# SECURITY: CORS restricted to FRONTEND_URL env var — no wildcard
_allowed_origins = [
    o.strip()
    for o in os.environ.get(
        "FRONTEND_URL",
        "http://localhost:3000,http://localhost:3001"
    ).split(",")
    if o.strip()
]
# Allow 'null' origin so dashboard works when opened directly from filesystem (file://)
# and allow localhost variants for development
if "null" not in _allowed_origins:
    _allowed_origins.append("null")
if "http://localhost:8000" not in _allowed_origins:
    _allowed_origins.append("http://localhost:8000")
logger.info(f"CORS allowed origins: {_allowed_origins}")

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=_allowed_origins,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def init_kernel():
    import asyncio
    global _buffer_lock

    # Initialise the async lock (must happen inside event loop)
    _buffer_lock = asyncio.Lock()

    # Start background telemetry flush loop
    asyncio.create_task(_telemetry_flush_loop())
    logger.info("Async telemetry buffer started (flush every 8s or 10 docs)")

    # MISSING 4: Start daily email report scheduler
    asyncio.create_task(_daily_email_loop())
    logger.info("[DAILY REPORT] Scheduler started — fires at 08:00 UTC")

    # Ensure MongoDB indexes for performance
    try:
        await telemetry_col.create_index([("timestamp", -1)])
        await alerts_col.create_index([("timestamp", -1)])
        await diversion_col.create_index([("timestamp", -1)])
        await api_log_col.create_index([("timestamp", -1)])
        await decisions_col.create_index([("timestamp", -1)])
        await settings_col.create_index([("_id", 1)])
        await hub_settings_col.create_index([("_id", 1)])
        await system_logs_col.create_index([("timestamp", -1)])
        logger.info("MongoDB indexes created")
    except Exception as e:
        logger.warning(f"Index creation failed (non-fatal): {e}")

    # Load persisted cost settings if they exist
    try:
        saved = await settings_col.find_one({"_id": "global"})
        if saved:
            _settings_cache["cost_per_failure"]   = saved.get("cost_per_failure", 3.94)
            _settings_cache["truck_transit_cost"]  = saved.get("truck_transit_cost", 1.20)
            # FIX: restore μ from MongoDB so restart preserves operator-set throughput
            if saved.get("mu"):
                _session["mu"] = float(saved["mu"])
            logger.info(f"Cost settings loaded from MongoDB: cost_per_failure={_settings_cache['cost_per_failure']} (μ will be loaded from hub_settings_col)")
    except Exception as e:
        logger.warning(f"Settings load failed (using defaults): {e}")


    # ── SITI: Load dynamic topology from MongoDB ────────────────────────────────
    try:
        cursor    = network_col.find({})
        topo_docs = await cursor.to_list(length=100)
        if topo_docs:
            topo_docs.sort(key=lambda d: d.get("order", 99))
            _hub_block_map.update({d["_id"]: d.get("blocks", []) for d in topo_docs})
            logger.info(f"[TOPOLOGY] Loaded {len(_hub_block_map)} hubs from MongoDB: {list(_hub_block_map.keys())}")
        else:
            for doc in DEFAULT_TOPOLOGY:
                await network_col.replace_one({"_id": doc["_id"]}, doc, upsert=True)
            _hub_block_map.update({d["_id"]: d["blocks"] for d in DEFAULT_TOPOLOGY})
            logger.info(f"[TOPOLOGY] Seeded default topology: {list(_hub_block_map.keys())}")
    except Exception as e:
        logger.warning(f"[TOPOLOGY] Load failed, using defaults: {e}")
        _asyncio.create_task(log_system_error("topology_load", e, "WARNING"))
        _hub_block_map.update({d["_id"]: d["blocks"] for d in DEFAULT_TOPOLOGY})

    _all_blocks[:] = sorted(set(b for blocks in _hub_block_map.values() for b in blocks))
    logger.info(f"[TOPOLOGY] Active blocks: {_all_blocks}")

    df = build_forensic_baseline()
    # Startup init populates admin baseline — each tenant gets their own session on first request
    _session["mimi"] = MIMIKernel(df)
    # Load persisted μ AFTER kernel init — correct order, no race condition
    # Priority: hub_settings_col > user_settings > default 150
    _startup_mu = 150.0
    try:
        hub_doc = await hub_settings_col.find_one({"_id": "global_mu"})
        if hub_doc and hub_doc.get("mu"):
            _startup_mu = float(hub_doc["mu"])
            logger.info(f"[MU] Restored μ={_startup_mu} from hub_settings_col (operator-set)")
        elif _session.get("mu") and _session["mu"] != 150.0:
            _startup_mu = float(_session["mu"])
            logger.info(f"[MU] Restored μ={_startup_mu} from user_settings (legacy)")
    except Exception as e:
        logger.warning(f"[MU] Load failed — using default μ=150: {e}")
    _session["mu"] = _startup_mu
    _session["mimi"].update_mu(_startup_mu)
    logger.info(f"[SITI] MIMI Kernel initialized: n={len(df)}, μ={_startup_mu}, ρ={_session['mimi'].global_rho():.4f}")
    for name, hub in _session["mimi"].hubs.items():
        logger.info(f"  Hub {name}: λ={hub.lambda_rate:.1f}/hr  μ={hub.mu:.0f}/hr  ρ={hub.rho:.4f}")

    # Warm Start — load checkpoint if available
    import time as _startup_time
    t_fit = _startup_time.monotonic()
    loop  = asyncio.get_running_loop()
    await loop.run_in_executor(None, lambda: _session["mimi"].fit_lr(checkpoint=True))
    elapsed_fit = _startup_time.monotonic() - t_fit
    logger.info(f"[WARM START] ρ_c={_session['mimi'].critical_rho:.4f} — ready in {elapsed_fit:.2f}s")

    # ── SITI: Initialise atomic counters — read from global_metrics ──────────────
    try:
        await metrics_col.create_index([("_id", 1)])
        existing = await metrics_col.find_one({"_id": "counters"})
        if existing:
            logger.info(
                f"[ATOMIC] Counters live: "
                f"{int(existing.get('diverted_units',0)):,} units diverted · "
                f"₹{float(existing.get('revenue_saved',0.0)):,.2f} saved"
            )
        else:
            # Migrate: seed from diversion_events aggregate on first V7 run
            pipeline = [{"$group": {"_id": None,
                                    "total_diverted": {"$sum": "$diverted_units"},
                                    "total_revenue":  {"$sum": "$revenue_saved"}}}]
            cursor  = diversion_col.aggregate(pipeline)
            results = await cursor.to_list(length=1)
            seed_units   = int(results[0].get("total_diverted", 0)) if results else 0
            seed_revenue = float(results[0].get("total_revenue", 0.0)) if results else 0.0
            await metrics_col.insert_one({
                "_id": "counters",
                "diverted_units": seed_units,
                "revenue_saved":  seed_revenue,
                "migrated_from":  "diversion_events",
                "last_updated":   datetime.now(timezone.utc),
            })
            logger.info(f"[ATOMIC] Counters seeded from history: {seed_units:,} units · ₹{seed_revenue:,.2f}")
    except Exception as e:
        logger.warning(f"[ATOMIC] Counter init failed: {e}")

    # MISSING 1: Load persisted API keys from MongoDB — survive restarts
    try:
        cursor    = api_keys_col.find({"active": True})
        db_keys   = await cursor.to_list(length=500)
        loaded    = 0
        for doc in db_keys:
            k = doc["_id"]; r = doc.get("role", "OPERATOR")
            if k not in VALID_API_KEYS:
                _KEY_ROLE_MAP[k] = r
                VALID_API_KEYS.add(k)
                loaded += 1
        if loaded:
            logger.info(f"[ADMIN] Loaded {loaded} persisted key(s) from MongoDB api_keys collection")
    except Exception as _ke:
        logger.warning(f"[ADMIN] Key restore failed (non-fatal): {_ke}")

    logger.info("SITI Intelligence ACTIVE — Atomic state · Live WhatsApp · Warm start · RBAC · 1k-WPS buffer")
    role_summary = {r: sum(1 for v in _KEY_ROLE_MAP.values() if v == r) for r in _VALID_ROLES if r in _KEY_ROLE_MAP.values()}
    logger.info(f"[RBAC] {len(VALID_API_KEYS)} key(s) active: {role_summary}")
    logger.info(f"CORS: {_allowed_origins}")


@app.on_event("shutdown")
async def shutdown_db_client():
    await _flush_telemetry_buffer()   # drain buffer before disconnect
    client.close()