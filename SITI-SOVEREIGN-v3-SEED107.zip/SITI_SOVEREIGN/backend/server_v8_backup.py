# ═══════════════════════════════════════════════════════════════════════════════
# SITI INTELLIGENCE — MIMI KERNEL v4.0 "DIAMOND-FINAL"
# DIAMOND-FINAL PRODUCTION BUILD — V7
# Protocol: Atomic State · Live WhatsApp · Warm Start · 1k-WPS Buffer
# Case #02028317 · Wankhede (2026) IEEE
# ═══════════════════════════════════════════════════════════════════════════════

from fastapi import FastAPI, APIRouter, UploadFile, File, HTTPException, Header, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from pydantic import BaseModel
import os
import re
import logging
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import LabelEncoder
from pathlib import Path
from typing import Optional, List
import io
from datetime import datetime, timezone
from baseline_data import build_forensic_baseline
import joblib

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client    = AsyncIOMotorClient(mongo_url)
db        = client[os.environ['DB_NAME']]

# MongoDB collections — actually used
telemetry_col    = db["telemetry_logs"]
alerts_col       = db["alerts"]
diversion_col    = db["diversion_events"]
api_log_col      = db["api_access_logs"]
decisions_col    = db["human_decisions"]    # Human-in-the-loop audit trail
settings_col     = db["user_settings"]      # Per-deployment cost configuration
network_col      = db["network_config"]       # DIAMOND: dynamic hub topology
metrics_col      = db["global_metrics"]        # V7: atomic worker-safe counters

# DIAMOND PROTOCOL 5: debug=False enforced at uvicorn/gunicorn launch (not in FastAPI constructor)
# Run: uvicorn server:app --host 0.0.0.0 --port 8000 --workers 1
# Production: gunicorn server:app -k uvicorn.workers.UvicornWorker --workers 2
app        = FastAPI(title="SITI Intelligence API — Diamond-Final v4.0", version="4.0.0")
api_router = APIRouter(prefix="/api")

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


# ─── CONSTANTS ────────────────────────────────────────────────────────────────
# T_OPERATIONAL and topology now defined in the Dynamic Topology section below
# DIAMOND PROTOCOL 5: STRICT API KEY — NO HARDCODED FALLBACK
_raw_keys = os.getenv("API_KEYS", "")
if not _raw_keys.strip():
    raise RuntimeError(
        "FATAL: API_KEYS environment variable is not set. "
        "Generate a key: python3 -c \"import secrets; print(secrets.token_hex(32))\" "
        "then set API_KEYS=<key> in your .env file."
    )
VALID_API_KEYS: set = {k.strip() for k in _raw_keys.split(",") if k.strip()}

# ─── ROLE-BASED ACCESS CONTROL ────────────────────────────────────────────────
# .env key format:  API_KEYS=key1:ADMIN,key2:OPERATOR,key3:INTEGRATOR,key4:READONLY
#
# ROLES:
#   ADMIN       — full access: topology CRUD, decisions, settings, all reads
#   OPERATOR    — approve/dismiss diversions, read all; cannot delete hubs
#   INTEGRATOR  — POST to v1/intercept and GET state only; cannot mutate topology
#   READONLY    — GET endpoints only; no writes of any kind
#
# Keys without a :ROLE suffix default to READONLY (safest default).
# Example .env entry:
#   API_KEYS=siti-admin-abc123:ADMIN,erp-xyz789:INTEGRATOR,ops-def456:OPERATOR

_VALID_ROLES  = {"ADMIN", "OPERATOR", "INTEGRATOR", "READONLY"}
_DEFAULT_ROLE = "READONLY"

# Parse {key: role} from comma-separated KEY:ROLE entries
_KEY_ROLE_MAP: dict = {}
for _entry in _raw_keys.split(","):
    _entry = _entry.strip()
    if not _entry:
        continue
    if ":" in _entry:
        _k, _r = _entry.rsplit(":", 1)
        _KEY_ROLE_MAP[_k.strip()] = _r.strip().upper() if _r.strip().upper() in _VALID_ROLES else _DEFAULT_ROLE
    else:
        _KEY_ROLE_MAP[_entry] = _DEFAULT_ROLE   # legacy key, no role → READONLY

# Rebuild VALID_API_KEYS from parsed map (supports both old and new format)
VALID_API_KEYS = set(_KEY_ROLE_MAP.keys())

# ─── V7 PROTOCOL 4: HIGH-THROUGHPUT ASYNC BUFFER (1,000 WPS) ─────────────────
# Upgraded for Blue Dart stress load:
#   • _BUFFER_MAX = 100 records (10x previous) — 1k WPS sustained
#   • _BUFFER_FLUSH = 3.0s — faster drain cycle
#   • Flush is fire-and-forget create_task — never blocks inbound
#   • insert_many(ordered=False) — max MongoDB throughput
import asyncio as _asyncio
_telemetry_buffer: list = []
_BUFFER_MAX   = 100      # V7: flush every 100 records — handles 1k WPS
_BUFFER_FLUSH = 3.0      # V7: drain every 3s (was 8s)
_buffer_lock  = None     # initialised inside event loop at startup

async def _flush_telemetry_buffer():
    """Drain in-memory buffer to MongoDB — single insert_many round-trip."""
    global _telemetry_buffer
    if not _telemetry_buffer or _buffer_lock is None:
        return
    async with _buffer_lock:
        batch = _telemetry_buffer[:]
        _telemetry_buffer = []
    if batch:
        try:
            await telemetry_col.insert_many(batch, ordered=False)
            logger.debug(f"[BUFFER] Flushed {len(batch)} docs")
        except Exception as e:
            logger.warning(f"[BUFFER] Flush failed — {len(batch)} docs dropped: {e}")

async def _telemetry_flush_loop():
    """Background drain loop — 3s cycle for 1k WPS sustained throughput."""
    while True:
        await _asyncio.sleep(_BUFFER_FLUSH)
        await _flush_telemetry_buffer()

# ─── DIAMOND PROTOCOL 3: DYNAMIC TOPOLOGY ─────────────────────────────────────
# HUB_BLOCK_MAP is no longer a hardcoded constant.
# _hub_block_map is loaded from MongoDB network_config at startup.
# Any hub added to the DB is hot-reloaded immediately via POST /api/network/hubs.
T_OPERATIONAL = 36.0   # hours

_hub_block_map: dict = {}   # populated at startup from MongoDB
_all_blocks:    list = []   # flattened sorted list of all active blocks

def _get_hub_block_map() -> dict:
    return _hub_block_map

def _get_hub_blocks(hub_name: str) -> list:
    return _hub_block_map.get(hub_name, [])

DEFAULT_TOPOLOGY = [
    {"_id": "Alpha", "blocks": ["A", "B"], "mu": 150.0, "order": 1},
    {"_id": "Beta",  "blocks": ["C", "D"], "mu": 150.0, "order": 2},
    {"_id": "Gamma", "blocks": ["F"],      "mu": 150.0, "order": 3},
]

# ─── SETTINGS CACHE ────────────────────────────────────────────────────────────
_settings_cache: dict = {
    "cost_per_failure":  3.94,   # ₹ per high-importance delivery failure (LEAKAGE_SEED)
    "truck_transit_cost": 1.20,  # ₹ per unit truck transit cost (recovery_value multiplier)
}


# ─── SECURITY: RBAC — API KEY + ROLE AUTH ─────────────────────────────────────
# Role hierarchy (highest → lowest):
#   ADMIN      — full access: topology CRUD, decisions, settings, all reads
#   OPERATOR   — diversion approvals + all reads; cannot delete hubs
#   INTEGRATOR — v1/intercept + GET state; cannot mutate topology or decisions
#   READONLY   — GET endpoints only; no writes of any kind
#
# .env format:  API_KEYS=abc123:ADMIN,xyz789:INTEGRATOR,def456:OPERATOR
# Legacy keys without :ROLE suffix are treated as READONLY (safest default).

def get_key_role(api_key: str) -> str:
    """Return the RBAC role assigned to this key."""
    return _KEY_ROLE_MAP.get(api_key, _DEFAULT_ROLE)


def require_api_key(x_api_key: str = Header(default=None)) -> str:
    """
    X-API-KEY header authentication.
    Returns the validated key string. Role is checked via require_role().
    """
    if x_api_key is None:
        raise HTTPException(
            status_code=401,
            detail={"error": "UNAUTHORIZED", "message": "X-API-KEY header required"}
        )
    if x_api_key not in VALID_API_KEYS:
        logger.warning(f"[AUTH] Invalid key attempt: {x_api_key[:8]}...")
        raise HTTPException(
            status_code=403,
            detail={"error": "FORBIDDEN", "message": "Invalid API key"}
        )
    return x_api_key


def require_role(api_key: str, allowed_roles: set, endpoint: str = "") -> str:
    """
    Role gate — always call AFTER require_api_key().
    Raises HTTP 403 if the key role is not in allowed_roles.
    Returns the resolved role string on success.

    Usage example:
        key = require_api_key(api_key)
        require_role(key, {"ADMIN", "OPERATOR"}, "DELETE /network/hubs")
    """
    role = get_key_role(api_key)
    if role not in allowed_roles:
        logger.warning(
            f"[RBAC] DENIED role='{role}' on '{endpoint}' "
            f"(requires one of {sorted(allowed_roles)})"
        )
        raise HTTPException(
            status_code=403,
            detail={
                "error":     "FORBIDDEN",
                "message":   f"Role '{role}' is not authorised for this endpoint",
                "your_role": role,
                "required":  sorted(allowed_roles),
                "endpoint":  endpoint,
                "hint":      "Contact your SITI admin to provision a key with the required role",
            }
        )
    logger.debug(f"[RBAC] GRANTED role='{role}' on '{endpoint}'")
    return role


# ─── 2D KALMAN HUB NODE ──────────────────────────────────────────────────────
class HubNode:
    """
    Network distribution hub — Queueing Theory ρ = λ/μ
    2D Kalman state vector x = [ρ, ρ̇]^T
    Transition: F = [[1, Δt], [0, 1]]  (constant-velocity model)
    dt = 0.25 → one 15-minute tick
    """
    def __init__(self, name: str, lambda_rate: float, mu: float = 150.0):
        self.name            = name
        self.lambda_rate     = lambda_rate
        self.mu              = mu
        self._kx: Optional[np.ndarray] = None
        self._kP: np.ndarray = np.eye(2) * 0.1
        self.rho_history: list = []
        self.saturation_protocol: bool = False
        self._prev_lambda: float = lambda_rate

    @property
    def rho(self) -> float:
        """ρ = λ/μ — standard M/M/1 utilization."""
        return float(self.lambda_rate / self.mu) if self.mu > 0 else 99.0

    def check_thundering_herd(self, new_lambda: float) -> bool:
        """Trigger saturation protocol if λ spikes >40% in one tick."""
        if self._prev_lambda > 1.0:
            spike = (new_lambda - self._prev_lambda) / self._prev_lambda
            if spike > 0.40:
                self.saturation_protocol = True
                self._prev_lambda = new_lambda
                return True
        self.saturation_protocol = False
        self._prev_lambda = new_lambda
        return False

    def kalman_step_2d(self, z_rho: float, dt: float = 0.25) -> dict:
        """
        2D Kalman Filter — x = [ρ, ρ̇]^T
        dt = 0.25 hr (15-min tick)
        T+1 = 15 min ahead · T+3 = 45 min ahead
        Q, R calibrated to enterprise IoT 15-min sampling interval.
        """
        Q = np.diag([0.002, 0.001])
        R = np.array([[0.005]])
        H = np.array([[1.0, 0.0]])
        F = np.array([[1.0, dt], [0.0, 1.0]])

        if self._kx is None:
            self._kx = np.array([z_rho, 0.0])
            self._kP = np.eye(2) * 0.1

        x_pred = F @ self._kx
        P_pred = F @ self._kP @ F.T + Q
        y      = np.array([z_rho]) - H @ x_pred
        S      = H @ P_pred @ H.T + R
        K      = P_pred @ H.T @ np.linalg.inv(S)

        self._kx = x_pred + (K @ y).flatten()
        self._kP = (np.eye(2) - K @ H) @ P_pred

        rho_hat = float(self._kx[0])
        rho_dot = float(self._kx[1])
        rho_t1  = float(np.clip(rho_hat + dt * rho_dot, 0.0, 1.5))

        if self.saturation_protocol:
            rho_t3_raw = rho_hat
            v = rho_dot
            for _ in range(3):
                rho_t3_raw += dt * v
                v *= 1.10
            rho_t3_raw = float(rho_t3_raw)
        else:
            rho_t3_raw = float(rho_hat + 3.0 * dt * rho_dot)

        rho_t3 = float(np.clip(rho_t3_raw, 0.0, 1.5))
        pvi    = round(abs(z_rho - rho_t3) * 100, 2)

        return {
            "x_hat":              round(rho_hat, 4),
            "rho_dot":            round(rho_dot, 6),
            "P":                  round(float(np.trace(self._kP)), 6),
            "K":                  [round(float(K[0, 0]), 4), round(float(K[1, 0]), 4)],
            "rho_t1":             round(rho_t1, 4),
            "rho_t3":             round(rho_t3, 4),
            "pvi":                pvi,
            "saturation_protocol": self.saturation_protocol,
        }


# ─── MIMI KERNEL ──────────────────────────────────────────────────────────────
class MIMIKernel:
    LEAKAGE_SEED       = 3.94
    AUDIT_WINDOW_HOURS = 36.0
    K_DECAY            = 20
    BASELINE_HI_FAIL   = 0.817   # Wankhede (2026) §IV-C

    def __init__(self, df: pd.DataFrame, mu: float = 150.0):
        self.df           = df.copy()
        self.n_total      = len(df)
        self.mu           = mu
        self.critical_rho = 0.85
        self.lr_model     = None
        self.hubs: dict   = self._init_hubs()
        # Dynamic lambda tracking for intercept API
        self._intercept_lambda_override: Optional[float] = None

    def _init_hubs(self) -> dict:
        hubs = {}
        for name, blocks in _get_hub_block_map().items():
            hub_df = self.df[self.df['Warehouse_block'].isin(blocks)]
            lambda_rate = len(hub_df) / T_OPERATIONAL
            hubs[name] = HubNode(name, lambda_rate, self.mu)
        return hubs

    def recalculate_lambdas(self):
        for name, blocks in _get_hub_block_map().items():
            if name in self.hubs:
                hub_df = self.df[self.df['Warehouse_block'].isin(blocks)]
                new_lambda = len(hub_df) / T_OPERATIONAL
                self.hubs[name].check_thundering_herd(new_lambda)
                self.hubs[name].lambda_rate = new_lambda

    def global_rho(self) -> float:
        total_lambda = sum(h.lambda_rate for h in self.hubs.values())
        total_mu     = sum(h.mu for h in self.hubs.values())
        return float(np.clip(total_lambda / total_mu, 0.0, 1.5)) if total_mu > 0 else 1.0

    def failure_rate(self) -> float:
        late = int((self.df['Reached.on.Time_Y.N'] == 0).sum())
        return round(float(late / self.n_total), 4) if self.n_total > 0 else 0.0

    def update_mu(self, new_mu: float):
        self.mu = new_mu
        for hub in self.hubs.values():
            hub.mu = new_mu

    def phi(self, rho_val: float) -> float:
        return round(float(1 / (1 + np.exp(-self.K_DECAY * (rho_val - self.critical_rho)))), 4)

    def wq(self, rho_val: float) -> float:
        if rho_val >= 1.0:
            return 99.9999
        return round(float(rho_val / (1 - rho_val)), 4)

    @property
    def annualized_exposure(self) -> float:
        """
        Live formula: (daily_shipments × 365) × hi_imp_failure_rate × cost_per_failure
        Uses user-configured cost_per_failure from _settings_cache (default: 3.94).
        Traceable: Wankhede (2026) §IV-C, Eq. (7)
        """
        daily_shipments = self.n_total / self.AUDIT_WINDOW_HOURS * 24.0
        irp = self.inverse_reliability()
        rate = irp['failure_rate'] if irp['failure_rate'] > 0 else self.BASELINE_HI_FAIL
        cost = _settings_cache.get("cost_per_failure", self.LEAKAGE_SEED)
        return round(daily_shipments * 365 * rate * cost, 0)

    def diversion_units_calculated(self, effective_lambdas: dict, cascade_events: list) -> int:
        """Calculated diversion — NO random numbers. excess_λ × (15min/60)."""
        if not cascade_events:
            total = 0
            for name, eff_lam in effective_lambdas.items():
                hub = self.hubs.get(name)
                if hub:
                    eff_rho = eff_lam / hub.mu if hub.mu > 0 else 0
                    if eff_rho > 0.80:
                        excess = max(0, (eff_rho - 0.80) * hub.mu)
                        total += int(excess * (15.0 / 60.0))
            return total
        total_excess = sum(ev['excess_lambda'] for ev in cascade_events)
        return int(total_excess * (15.0 / 60.0))

    def routing_logic_rho(self) -> dict:
        """
        FIXED: Routing based purely on ρ = λ/μ per hub.
        No more late/n contamination. One definition everywhere.
        """
        epsilon   = 0.05
        threshold = self.critical_rho
        hub_rhos  = []
        for name, hub in self.hubs.items():
            hub_rhos.append({"hub": name, "rho": round(hub.rho, 4), "lambda": round(hub.lambda_rate, 2), "mu": round(hub.mu, 2)})

        overloaded = [h for h in hub_rhos if h["rho"] > threshold]
        available  = [h for h in hub_rhos if h["rho"] < threshold - epsilon]
        return {
            "hub_utilizations":  hub_rhos,
            "overloaded_hubs":   overloaded,
            "available_hubs":    available,
            "diversion_active":  len(overloaded) > 0 and len(available) > 0,
            "epsilon":           epsilon,
            "threshold":         round(threshold, 4),
            "method":            "rho_lambda_mu",   # auditable: confirms correct formula
        }

    def inverse_reliability(self) -> dict:
        df     = self.df
        mask   = (df['Product_importance'].str.lower() == 'high') & (df['Reached.on.Time_Y.N'] == 0)
        fail_df = df[mask]
        n_fail = int(len(fail_df))
        n_high = int((df['Product_importance'].str.lower() == 'high').sum())
        failure_rate = round(float(n_fail / n_high), 4) if n_high > 0 else 0.0
        top = fail_df.head(25)[['ID', 'Warehouse_block', 'Mode_of_Shipment',
                                 'Cost_of_the_Product', 'Weight_in_gms', 'Discount_offered']].copy()
        top.columns = ['id', 'hub', 'mode', 'cost', 'weight', 'discount']
        records = [{k: int(v) if isinstance(v, (np.integer, np.int64)) else v
                    for k, v in row.items()} for row in top.to_dict('records')]
        return {
            "failure_count": n_fail, "total_high": n_high, "failure_rate": failure_rate,
            "leakage_total": round(n_fail * self.LEAKAGE_SEED, 2),
            "clv_loss":      round(n_fail * 2.74, 2),
            "recovery_value": round(n_fail * 1.20, 2),
            "records":       records,
        }

    def warehouse_metrics(self) -> list:
        results = []
        for b in (_all_blocks if _all_blocks else ['A', 'B', 'C', 'D', 'F']):
            sub = self.df[self.df['Warehouse_block'] == b]
            n   = len(sub)
            if n == 0: continue
            late = int((sub['Reached.on.Time_Y.N'] == 0).sum())
            results.append({"block": b, "total": int(n), "late": late,
                            "failure_rate": round(float(late / n), 4), "on_time": int(n - late)})
        return results

    def mode_metrics(self) -> list:
        results = []
        for m in ['Ship', 'Flight', 'Road']:
            sub = self.df[self.df['Mode_of_Shipment'] == m]
            n   = len(sub)
            if n == 0: continue
            late = int((sub['Reached.on.Time_Y.N'] == 0).sum())
            results.append({"mode": m, "total": int(n), "late": late, "rate": round(float(late / n), 4)})
        return results

    def red_zone_importance(self) -> list:
        _blocks = _all_blocks if _all_blocks else ['A', 'B', 'C', 'D', 'F']
        red_blocks = [
            b for b in _blocks
            if (sub := self.df[self.df['Warehouse_block'] == b]) is not None
            and len(sub) > 0
            and (sub['Reached.on.Time_Y.N'] == 0).sum() / len(sub) > 0.80
        ]
        if not red_blocks:
            red_blocks = _blocks
        red_df = self.df[
            (self.df['Warehouse_block'].isin(red_blocks)) &
            (self.df['Reached.on.Time_Y.N'] == 0)
        ]
        counts = red_df['Product_importance'].str.title().value_counts()
        return [{"name": lvl, "value": int(counts.get(lvl, 0))} for lvl in ['High', 'Medium', 'Low']]

    # V7 PROTOCOL 3: Warm Start checkpoint
    CHECKPOINT_PATH = Path(__file__).parent / "mimi_kernel_v1.joblib"

    def fit_lr(self, checkpoint: bool = True) -> float:
        """
        V7 WARM START: checks mimi_kernel_v1.joblib before fitting.
          EXISTS  → joblib.load in <100ms regardless of dataset size
          MISSING → cold fit, then save for every future restart
        Reduces startup from minutes → under 5 seconds on massive datasets.
        random_state=2028317 (case number) — deterministic, auditable.
        """
        import time as _t
        if checkpoint and MIMIKernel.CHECKPOINT_PATH.exists():
            try:
                t0   = _t.monotonic()
                ckpt = joblib.load(MIMIKernel.CHECKPOINT_PATH)
                self.lr_model     = ckpt["lr_model"]
                self.critical_rho = float(ckpt["critical_rho"])
                logger.info(f"[WARM START] Loaded checkpoint in {_t.monotonic()-t0:.3f}s "
                            f"— ρ_c={self.critical_rho:.4f} (saved {ckpt.get('saved_at','?')})")
                return self.critical_rho
            except Exception as e:
                logger.warning(f"[WARM START] Load failed ({e}) — falling back to cold fit")

        # Cold fit path — runs once, saves checkpoint for all future restarts
        t0 = _t.monotonic()
        df = self.df.copy()
        for col in ['Mode_of_Shipment', 'Product_importance', 'Warehouse_block', 'Gender']:
            if col in df.columns:
                df[f'{col}_enc'] = LabelEncoder().fit_transform(df[col].astype(str))
        features = [c for c in [
            'Customer_care_calls', 'Customer_rating', 'Cost_of_the_Product',
            'Prior_purchases', 'Discount_offered', 'Weight_in_gms',
            'Mode_of_Shipment_enc', 'Product_importance_enc',
            'Warehouse_block_enc', 'Gender_enc'
        ] if c in df.columns]
        X = df[features].values
        y = df['Reached.on.Time_Y.N'].values
        self.lr_model = LogisticRegression(max_iter=2000, random_state=2028317)
        self.lr_model.fit(X, y)
        proba_late    = 1 - self.lr_model.predict_proba(X)[:, 1]
        new_thresh    = float(np.mean(proba_late) + 1.0 * np.std(proba_late))
        self.critical_rho = round(float(np.clip(new_thresh, 0.70, 0.95)), 4)
        elapsed = _t.monotonic() - t0
        logger.info(f"[COLD FIT] LR fitted in {elapsed:.2f}s — ρ_c={self.critical_rho:.4f} — saving checkpoint")

        if checkpoint:
            try:
                joblib.dump({
                    "lr_model":     self.lr_model,
                    "critical_rho": self.critical_rho,
                    "n_samples":    len(df),
                    "saved_at":     datetime.now(timezone.utc).isoformat(),
                }, MIMIKernel.CHECKPOINT_PATH)
                logger.info(f"[WARM START] Checkpoint saved → {MIMIKernel.CHECKPOINT_PATH.name}")
            except Exception as e:
                logger.warning(f"[WARM START] Save failed: {e}")
        return self.critical_rho


# ─── SESSION STATE ────────────────────────────────────────────────────────────
# V7 PROTOCOL 1: diverted_units and revenue_saved REMOVED from _session.
# All counter state lives in MongoDB global_metrics collection.
# Workers use atomic $inc — 50 workers, one consistent number. Never jumps backward.
_session: dict = {
    "mimi":           None,
    "refresh_count":  0,       # per-process tick counter (non-critical)
    "rho_history":   [],
    "dataset_name":  "SAFEXPRESS_CASE_02028317",
    "mu":            150.0,    # current μ — also persisted to settings_col
    "api_requests":  0,
}



# ─── V7 PROTOCOL 1: ATOMIC MONGODB COUNTERS ──────────────────────────────────
# All revenue/diversion state lives here — worker-safe via $inc.
# _session["diverted_units"] and _session["revenue_saved"] are DELETED.
# Any number of Gunicorn workers reads the same MongoDB document.

async def atomic_inc_metrics(diverted: int, revenue: float) -> None:
    """
    Atomic $inc on global_metrics._id='counters'.
    Concurrent workers increment safely — no read-modify-write race.
    Fire-and-forget via create_task — never blocks the response path.
    """
    if diverted == 0 and revenue == 0.0:
        return
    try:
        await metrics_col.update_one(
            {"_id": "counters"},
            {"$inc": {"diverted_units": diverted, "revenue_saved": round(revenue, 2)},
             "$set": {"last_updated": datetime.now(timezone.utc)}},
            upsert=True
        )
    except Exception as e:
        logger.warning(f"[ATOMIC] Counter increment failed: {e}")

async def get_global_metrics() -> dict:
    """Read current atomic counters — single document, worker-safe."""
    try:
        doc = await metrics_col.find_one({"_id": "counters"})
        if doc:
            return {
                "diverted_units": int(doc.get("diverted_units", 0)),
                "revenue_saved":  float(doc.get("revenue_saved", 0.0)),
            }
    except Exception as e:
        logger.warning(f"[ATOMIC] Counter read failed: {e}")
    return {"diverted_units": 0, "revenue_saved": 0.0}

# ─── HELPERS ──────────────────────────────────────────────────────────────────
def _sanitize_numeric(val):
    if isinstance(val, str):
        cleaned = re.sub(r'[^\d.]', '', val.strip())
        try:    return float(cleaned) if cleaned else 0.0
        except Exception: return 0.0
    return val

def _sanitize_numeric_columns(df: pd.DataFrame) -> pd.DataFrame:
    for col in ['Customer_care_calls', 'Customer_rating', 'Cost_of_the_Product',
                'Prior_purchases', 'Discount_offered', 'Weight_in_gms']:
        if col in df.columns:
            df[col] = df[col].apply(_sanitize_numeric)
    return df

def _strip_non_ascii(t):
    return re.sub(r'[^\x20-\x7E\t\n\r]', '', t)

def _parse_csv_resilient(content: bytes) -> pd.DataFrame:
    for encoding in ('utf-8', 'iso-8859-1', 'windows-1252'):
        try:
            text = content.decode(encoding, errors='replace')
            if encoding == 'utf-8' and '\uFFFD' in text:
                continue
            text = _strip_non_ascii(text)
            df   = pd.read_csv(io.StringIO(text), on_bad_lines='skip')
            logger.info(f"CSV parsed OK: encoding={encoding}, rows={len(df)}")
            return df
        except UnicodeDecodeError:
            logger.warning(f"Decode failed with {encoding}")
        except Exception as exc:
            logger.warning(f"CSV parse error ({encoding}): {exc}")
    raise ValueError("CSV unreadable with UTF-8, ISO-8859-1, or Windows-1252")

def _fuzzy_map_columns(df: pd.DataFrame) -> pd.DataFrame:
    TARGET_MAP = [
        ('Reached.on.Time_Y.N', lambda c: ('reached' in c) or ('on_time' in c) or ('delivered' in c)),
        ('Warehouse_block',     lambda c: ('warehouse' in c) or ('block' in c and 'hub' not in c)),
        ('Mode_of_Shipment',    lambda c: ('mode' in c) or ('shipment' in c) or ('carrier' in c)),
        ('Customer_care_calls', lambda c: ('care' in c and 'call' in c) or ('cc_call' in c)),
        ('Customer_rating',     lambda c: ('rating' in c) or ('csat' in c)),
        ('Cost_of_the_Product', lambda c: ('cost' in c) or ('price' in c)),
        ('Prior_purchases',     lambda c: ('prior' in c) or ('purchase' in c)),
        ('Product_importance',  lambda c: ('importance' in c) or ('priority' in c)),
        ('Gender',              lambda c: c in ('gender', 'sex', 'g')),
        ('Discount_offered',    lambda c: ('discount' in c) or ('promo' in c)),
        ('Weight_in_gms',       lambda c: ('weight' in c) or ('gms' in c) or ('gram' in c)),
    ]
    col_map = {}
    already_mapped = set()
    for col in df.columns:
        lower = col.lower().replace(' ', '_').replace('.', '_').replace('-', '_')
        for target, matcher in TARGET_MAP:
            if target not in already_mapped and matcher(lower):
                col_map[col] = target
                already_mapped.add(target)
                break
    return df.rename(columns=col_map)

def _fill_missing_with_means(df: pd.DataFrame) -> pd.DataFrame:
    for col in ['Customer_care_calls', 'Customer_rating', 'Cost_of_the_Product',
                'Prior_purchases', 'Discount_offered', 'Weight_in_gms']:
        if col in df.columns:
            m = df[col].mean()
            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0 if pd.isna(m) else m).astype(int)
    for col, default in [('Warehouse_block','A'),('Mode_of_Shipment','Ship'),
                          ('Product_importance','Medium'),('Gender','M')]:
        if col in df.columns:
            df[col] = df[col].fillna(default)
    return df

def _compute_cascade(hubs: dict) -> tuple:
    effective = {name: h.lambda_rate for name, h in hubs.items()}
    events    = []
    for name in sorted(effective.keys(), key=lambda n: effective[n] / hubs[n].mu, reverse=True):
        hub = hubs[name]
        rho = effective[name] / hub.mu if hub.mu > 0 else 99.0
        if rho > 0.85:
            excess = (rho - 0.85) * hub.mu
            others = [(n, effective[n] / hubs[n].mu) for n in effective if n != name]
            if not others: continue
            receiver = min(others, key=lambda x: x[1])[0]
            effective[name]    -= excess
            effective[receiver] += excess
            events.append({
                "from_hub":         name,
                "to_hub":           receiver,
                "excess_lambda":    round(excess, 2),
                "new_rho_source":   round(effective[name] / hub.mu, 4),
                "new_rho_receiver": round(effective[receiver] / hubs[receiver].mu, 4),
            })
    return effective, events


# ─── MONGODB PERSISTENCE ──────────────────────────────────────────────────────
async def persist_telemetry(hub_states: list, global_rho: float,
                             cascade_events: list, alert: dict) -> None:
    """
    STRESS CHECK FIX: Buffer telemetry writes — never blocks dashboard.
    Telemetry docs go into _telemetry_buffer; background loop flushes to MongoDB.
    Alert writes (rare) go direct — they are low-frequency and high-value.
    """
    ts = datetime.now(timezone.utc)
    doc = {
        "timestamp":      ts,
        "global_rho":     round(global_rho, 4),
        "hub_states":     [
            {
                "name":    h["name"],
                "rho":     h["rho"],
                "rho_dot": h["kalman"].get("rho_dot", 0),
                "rho_t1":  h["kalman"].get("rho_t1", 0),
                "rho_t3":  h["kalman"].get("rho_t3", 0),
                "lambda":  h["lambda_rate"],
                "status":  "DIVERTING" if h.get("cascade_source") else
                           "CASCADE_RECV" if h.get("cascade_risk") else "NOMINAL",
            }
            for h in hub_states
        ],
        "cascade_active": len(cascade_events) > 0,
        "cascade_events": cascade_events,
        "dataset":        _session.get("dataset_name", "SAFEXPRESS_CASE_02028317"),
    }

    # ── ASYNC BUFFER: append, flush only when full ──────────────────────────
    async with _buffer_lock:
        _telemetry_buffer.append(doc)
        should_flush = len(_telemetry_buffer) >= _BUFFER_MAX

    if should_flush:
        # Fire-and-forget — response is NOT blocked
        _asyncio.create_task(_flush_telemetry_buffer())

    # ── ALERTS: direct write (rare, high-value) ─────────────────────────────
    if alert.get("sent"):
        alert_doc = {
            "timestamp":    ts,
            "hub":          alert.get("hub"),
            "rho":          alert.get("rho"),
            "alert_count":  alert.get("alert_count"),
            "message":      alert.get("message", ""),
            "decision":     "PENDING",   # awaiting human-in-the-loop approval
        }
        try:
            await alerts_col.insert_one(alert_doc)
        except Exception as e:
            logger.warning(f"Alert persist failed: {e}")


# ─── V7 PROTOCOL 2: WHATSAPP ALERT — LIVE (stdlib only, no SDK) ──────────────
_alert_state: dict = {"last_alert_rho": 0.0, "alert_count": 0, "last_alert_time": None}

def _send_whatsapp(msg: str) -> bool:
    """
    V7 PROTOCOL 2: Pure stdlib Twilio REST sender — zero SDK dependency.
    Activate by setting these env vars:
      TWILIO_SID   = AC... (Account SID from twilio.com/console)
      TWILIO_TOKEN = your auth token
      TWILIO_FROM  = whatsapp:+14155238886
      TWILIO_TO    = whatsapp:+91XXXXXXXXXX  (VP operations number)
    If any credential missing — logs alert only, never crashes.
    """
    import urllib.request, urllib.parse, base64
    sid   = os.getenv("TWILIO_SID",   "")
    token = os.getenv("TWILIO_TOKEN", "")
    frm   = os.getenv("TWILIO_FROM",  "whatsapp:+14155238886")
    to    = os.getenv("TWILIO_TO",    "")
    if not all([sid, token, to]):
        logger.info("[WHATSAPP] Creds not set — alert logged only (set TWILIO_SID/TOKEN/TO)")
        return False
    url  = f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json"
    data = urllib.parse.urlencode({"From": frm, "To": to, "Body": msg}).encode()
    cred = base64.b64encode(f"{sid}:{token}".encode()).decode()
    req  = urllib.request.Request(
        url, data=data,
        headers={"Authorization": f"Basic {cred}",
                 "Content-Type":  "application/x-www-form-urlencoded"}
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            logger.info(f"[WHATSAPP] Fired to {to[:20]}... — HTTP {r.status}")
            return True
    except Exception as e:
        logger.warning(f"[WHATSAPP] Send failed: {e}")
        return False


def trigger_critical_alert(global_rho: float, hubs: dict) -> dict:
    """
    V7 PROTOCOL 2: Live WhatsApp alert — LIVE, not commented.
    Cool-down: ALERT_COOLDOWN_MIN env var (default 30 min).
    ρ threshold: > 0.80 on any hub.
    """
    payload      = {"sent": False, "message": "", "hub": "", "rho": 0.0}
    now          = datetime.now(timezone.utc)
    cooldown_sec = int(os.getenv("ALERT_COOLDOWN_MIN", "30")) * 60

    last = _alert_state.get("last_alert_time")
    if last and (now - last).total_seconds() < cooldown_sec:
        return payload

    worst = max(hubs.values(), key=lambda h: h.rho, default=None)
    if worst is None or worst.rho <= 0.80:
        return payload

    # Saturation severity framing
    severity = "CRITICAL" if worst.rho >= 0.85 else "WARNING"
    pct_to_collapse = round((0.90 - worst.rho) / 0.90 * 100, 1)
    # Translate λ/μ into business language
    overload_units = round((worst.lambda_rate - worst.mu) * 0.75)  # excess per 45min window
    overload_str   = f"{abs(overload_units):,} shipments over capacity" if overload_units > 0 else "approaching limit"

    msg = (
        f"🔴 [{severity}] Hub {worst.name.upper()} is heading for a blockage.\n"
        f"\n"
        f"Right now it's processing at {worst.rho*100:.1f}% of max capacity — "
        f"anything above 85% starts causing late deliveries across the network.\n"
        f"\n"
        f"If nothing changes in the next 45 minutes, "
        f"you'll have {overload_str} backing up and rippling into downstream hubs.\n"
        f"\n"
        f"What to do: Reroute inbound shipments away from Hub {worst.name.upper()} now. "
        f"Your diversion window is open — act before it closes.\n"
        f"\n"
        f"— SITI Intelligence | {now.strftime('%d %b %Y, %H:%M UTC')} | Ref #{_alert_state['alert_count']:04d}"
    )
    logger.warning(f"[ALERT] Hub {worst.name} rho={worst.rho:.4f} severity={severity}")
    whatsapp_sent = _send_whatsapp(msg)   # LIVE — pure urllib, no SDK

    _alert_state["last_alert_rho"]  = worst.rho
    _alert_state["alert_count"]    += 1
    _alert_state["last_alert_time"] = now
    return {
        "sent":           True,
        "whatsapp_fired": whatsapp_sent,
        "message":        msg,
        "hub":            worst.name,
        "rho":            round(worst.rho, 4),
        "alert_count":    _alert_state["alert_count"],
        "cooldown_min":   cooldown_sec // 60,
    }


# ─── REQUEST MODELS ───────────────────────────────────────────────────────────
class MuUpdate(BaseModel):
    mu: float

# ─── ROUTES ───────────────────────────────────────────────────────────────────

@api_router.get("/")
async def root():
    return {
        "service":  "SITI Intelligence — MIMI Kernel v4.0 Diamond-Final (v8 Enterprise)",
        "status":   "operational",
        "security": "X-API-KEY required on protected endpoints",
        "docs":     "/docs",
    }


@api_router.get("/kernel/state")
async def get_kernel_state(api_key: str = Header(alias="X-API-KEY", default=None)):
    """Protected: requires X-API-KEY header."""
    require_api_key(api_key)
    _session["api_requests"] += 1

    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")

    effective_lambdas, cascade_events = _compute_cascade(mimi.hubs)

    hub_states = []
    for name in list(_hub_block_map.keys()):   # DIAMOND: dynamic iteration
        if name not in mimi.hubs:
            continue
        hub      = mimi.hubs[name]
        eff_lam  = effective_lambdas.get(name, mimi.hubs[name].lambda_rate)
        # DIAMOND PROTOCOL 1: eff_rho passed directly — ZERO noise injection.
        # Kalman Q=diag(0.002,0.001) and R=[[0.005]] encode real process/measurement uncertainty.
        eff_rho  = float(np.clip(eff_lam / hub.mu, 0.0, 1.5)) if hub.mu > 0 else 1.0
        kalman   = hub.kalman_step_2d(eff_rho)

        ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
        hub.rho_history.append({"time": ts, "rho": round(eff_rho, 4),
                                 "t1": kalman["rho_t1"], "t3": kalman["rho_t3"]})
        if len(hub.rho_history) > 30:
            hub.rho_history.pop(0)

        hub_states.append({
            "name":             name,
            "blocks":            _get_hub_blocks(name),
            "lambda_rate":      round(hub.lambda_rate, 2),
            "effective_lambda": round(eff_lam, 2),
            "mu":               round(hub.mu, 2),
            "rho":              round(eff_rho, 4),
            "rho_exact":        round(eff_rho, 4),
            "kalman":           kalman,
            "rho_history":      hub.rho_history[-30:],
            "cascade_risk":     any(e["to_hub"] == name for e in cascade_events),
            "cascade_source":   any(e["from_hub"] == name for e in cascade_events),
            "saturation_protocol": hub.saturation_protocol,
        })

    total_eff  = sum(effective_lambdas.values())
    total_mu   = sum(h.mu for h in mimi.hubs.values())
    g_rho_val  = float(np.clip(total_eff / total_mu, 0.0, 1.5)) if total_mu > 0 else 1.0
    # DIAMOND PROTOCOL 1: g_rho_val is the true aggregate signal — zero artificial jitter
    g_rho_meas = g_rho_val   # direct pass — Kalman R encodes measurement uncertainty

    phi_val  = mimi.phi(g_rho_meas)
    irp      = mimi.inverse_reliability()
    alpha_k  = hub_states[0]["kalman"] if hub_states else {}

    ts = datetime.now(timezone.utc).strftime("%H:%M:%S")
    _session["rho_history"].append({
        "time": ts, "rho": round(g_rho_meas, 4),
        "t1": alpha_k.get("rho_t1", 0), "t3": alpha_k.get("rho_t3", 0),
    })
    if len(_session["rho_history"]) > 30:
        _session["rho_history"].pop(0)

    critical_hub = max(hub_states, key=lambda h: h["rho"])
    rho_t3_max   = critical_hub["kalman"]["rho_t3"]
    rho_dot_max  = critical_hub["kalman"]["rho_dot"]

    # Commander message — dynamic, no hardcoded statistics
    if cascade_events:
        ev = cascade_events[0]
        commander_msg   = (f"CASCADE DIVERSION ACTIVE: {ev['from_hub']} → {ev['to_hub']} "
                          f"({ev['excess_lambda']:.1f} units/hr).\n"
                          f"MONITOR {ev['to_hub']} FOR SECONDARY STRAIN.")
        commander_level = "critical"
    elif rho_t3_max >= 0.85:
        commander_msg   = (f"CRITICAL: HUB {critical_hub['name'].upper()} SATURATION IMMINENT.\n"
                          f"INITIATE PREEMPTIVE DIVERSION PROTOCOL.")
        commander_level = "critical"
    elif rho_t3_max < 0.40:
        commander_msg   = "EFFICIENCY GAP: NETWORK UNDER-UTILIZED.\nACCELERATE INBOUND INGESTION."
        commander_level = "efficiency"
    else:
        # FIXED: no hardcoded "CERTAINTY 99.2%" — dynamic state description
        state_label = "CRITICAL" if g_rho_meas > 0.80 else "NOMINAL"
        commander_msg   = (f"SYSTEM STATE: {state_label} — "
                          f"ρ {g_rho_meas:.4f} — "
                          f"VELOCITY {rho_dot_max:+.6f}")
        commander_level = "stable"

    any_saturation = any(h["saturation_protocol"] for h in hub_states)
    if any_saturation:
        sat_hub       = next(h for h in hub_states if h["saturation_protocol"])
        commander_msg = (f"THUNDERING HERD: HUB {sat_hub['name'].upper()}.\n"
                        f"IMMEDIATE SATURATION PROTOCOL ENGAGED.")
        commander_level = "critical"

    catastrophe = g_rho_meas > 0.80
    collapse    = g_rho_meas >= 0.85
    alert       = trigger_critical_alert(g_rho_meas, mimi.hubs)

    # Write to MongoDB via async buffer — never blocks state response
    _asyncio.create_task(persist_telemetry(hub_states, g_rho_meas, cascade_events, alert))

    # V7 P1: atomic fetch — consistent across all 50 workers
    _live_metrics = await get_global_metrics()

    return {
        "rho":            round(g_rho_meas, 4),
        "global_rho":     round(g_rho_meas, 4),
        "mu":             round(mimi.mu, 2),
        "total_lambda":   round(total_eff, 2),
        "phi":            phi_val,
        "critical_rho":   mimi.critical_rho,
        "k_decay":        mimi.K_DECAY,
        "n_total":        mimi.n_total,
        "failure_rate":   mimi.failure_rate(),
        "wq":             mimi.wq(g_rho_meas),
        "hubs":           hub_states,
        "cascade_events": cascade_events,
        "kalman":         alpha_k,
        "rho_t3":         rho_t3_max,
        "pvi":            alpha_k.get("pvi", 0),
        "pvi_alert":      alpha_k.get("pvi", 0) > 15.0,
        "commander_message": commander_msg,
        "commander_level":   commander_level,
        "inverse_reliability": irp,
        "warehouse_metrics": mimi.warehouse_metrics(),
        "mode_metrics":      mimi.mode_metrics(),
        "red_zone_importance": mimi.red_zone_importance(),
        "routing":           mimi.routing_logic_rho(),
        "catastrophe":       catastrophe,
        "collapse":          collapse,
        "catastrophe_predicted": rho_t3_max > 0.80,
        "collapse_predicted":    rho_t3_max >= 0.85,
        "alert":             alert,
        "rho_history":       _session["rho_history"][-30:],
        "annualized_exposure": mimi.annualized_exposure,
        "leakage_seed":      mimi.LEAKAGE_SEED,
        "diverted_units":    _live_metrics["diverted_units"],
        "revenue_saved":     round(_live_metrics["revenue_saved"], 2),
        "refresh_count":     _session["refresh_count"],
        "dataset_name":      _session["dataset_name"],
        "api_requests":      _session["api_requests"],
        "secure":            True,
    }


@api_router.get("/kernel/history")
async def get_kernel_history(
    limit: int = 100,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Fetch last N telemetry states from MongoDB.
    Returns historical hub trajectories for trend analysis.
    Protected: requires X-API-KEY header.
    """
    require_api_key(api_key)
    try:
        cursor = telemetry_col.find(
            {},
            {"_id": 0, "timestamp": 1, "global_rho": 1,
             "hub_states": 1, "cascade_active": 1}
        ).sort("timestamp", -1).limit(limit)
        docs = await cursor.to_list(length=limit)
        # Convert timestamps to ISO strings for JSON
        for d in docs:
            if isinstance(d.get("timestamp"), datetime):
                d["timestamp"] = d["timestamp"].isoformat()
        return {
            "count":   len(docs),
            "records": list(reversed(docs)),  # chronological order
            "source":  "mongodb:telemetry_logs",
        }
    except Exception as e:
        logger.error(f"History fetch failed: {e}")
        raise HTTPException(status_code=500, detail=f"History unavailable: {str(e)}")


@api_router.post("/kernel/tick")
async def kernel_tick(api_key: str = Header(alias="X-API-KEY", default=None)):
    """Protected: requires X-API-KEY header."""
    require_api_key(api_key)

    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")

    effective_lambdas, cascade_events = _compute_cascade(mimi.hubs)
    diverted = mimi.diversion_units_calculated(effective_lambdas, cascade_events)

    cost_per      = _settings_cache.get("cost_per_failure", mimi.LEAKAGE_SEED)
    revenue_delta = round(diverted * cost_per, 2)
    _session["refresh_count"] += 1

    g_rho      = mimi.global_rho()
    alert_sent = trigger_critical_alert(g_rho, mimi.hubs)

    if diverted > 0:
        # V7 P1: atomic $inc — 50 workers, one consistent number, never jumps backward
        _asyncio.create_task(atomic_inc_metrics(diverted, revenue_delta))
        try:
            await diversion_col.insert_one({
                "timestamp":      datetime.now(timezone.utc),
                "diverted_units": diverted,
                "cascade_events": cascade_events,
                "revenue_saved":  revenue_delta,
                "global_rho":     round(g_rho, 4),
            })
        except Exception as e:
            logger.warning(f"Diversion persist failed: {e}")

    metrics = await get_global_metrics()
    return {
        "diverted":         diverted,
        "total_diverted":   metrics["diverted_units"],
        "revenue_saved":    metrics["revenue_saved"],
        "refresh_count":    _session["refresh_count"],
        "alert_sent":       alert_sent,
        "diversion_method": "calculated_atomic_v7",
    }


@api_router.post("/kernel/upload")
async def upload_dataset(
    file: UploadFile = File(...),
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """Upload real CSV data. Protected: requires X-API-KEY header."""
    require_api_key(api_key)
    try:
        content = await file.read()
        df      = _parse_csv_resilient(content)
        df      = _fuzzy_map_columns(df)

        if 'Reached.on.Time_Y.N' not in df.columns:
            raise HTTPException(status_code=400, detail={
                "type": "SCHEMA_MISMATCH",
                "found_columns": list(df.columns),
                "required": ["Reached.on.Time_Y.N"],
                "message": "SCHEMA MISMATCH: Cannot map delivery status column",
            })

        col = df['Reached.on.Time_Y.N']
        if col.dtype == object:
            df['Reached.on.Time_Y.N'] = col.map(
                lambda x: 1 if str(x).strip().upper() in ['Y', 'YES', '1', 'TRUE'] else 0
            ).astype(int)
        else:
            df['Reached.on.Time_Y.N'] = pd.to_numeric(col, errors='coerce').fillna(0).astype(int)

        if 'ID' not in df.columns:
            df['ID'] = range(1, len(df) + 1)
        for cat, default in [('Warehouse_block','A'),('Mode_of_Shipment','Ship'),
                              ('Product_importance','Medium'),('Gender','M')]:
            if cat not in df.columns:
                df[cat] = default

        df = _sanitize_numeric_columns(df)
        df = _fill_missing_with_means(df)

        new_kernel     = MIMIKernel(df, _session.get("mu", 150.0))
        # GAP 3 FIX: checkpoint=False forces cold fit on new customer data.
        # Without this, uploading Blue Dart data would silently load the
        # Safexpress model from mimi_kernel_v1.joblib — a silent data fraud.
        new_crit_rho   = new_kernel.fit_lr(checkpoint=False)

        _session["mimi"]         = new_kernel
        _session["refresh_count"] = 0
        _session["rho_history"]   = []
        _session["dataset_name"]  = file.filename or "UPLOADED_DATASET"
        # V7: Reset atomic counters on new dataset upload
        try:
            await metrics_col.replace_one(
                {"_id": "counters"},
                {"_id": "counters", "diverted_units": 0, "revenue_saved": 0.0,
                 "reset_at": datetime.now(timezone.utc)},
                upsert=True
            )
        except Exception as e:
            logger.warning(f"Metrics reset failed: {e}")

        g_rho = new_kernel.global_rho()
        return {
            "success":          True,
            "n_total":          len(df),
            "new_rho":          round(g_rho, 4),
            "new_critical_rho": new_crit_rho,
            "message":          f"MIMI Kernel reinitialized. ρ={g_rho:.4f}, ρ_c={new_crit_rho:.4f}",
            "dataset_name":     _session["dataset_name"],
        }
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upload error: {e}")
        raise HTTPException(status_code=400, detail=f"CSV parse error: {str(e)}")


@api_router.post("/kernel/stream-batch")
async def stream_batch(
    n: int = 100,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Demo shipment batch injection — DIAMOND AUDIT NOTE:
    RNG below is isolated to this demo endpoint only.
    The Kalman kernel (get_kernel_state, v1/intercept) receives only
    deterministic eff_rho — zero random input. Search 'DIAMOND PROTOCOL 1'.
    """
    require_api_key(api_key)
    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")

    # Demo RNG — generates synthetic arrivals for dashboard stress testing only
    rng        = np.random.default_rng()
    rho_base   = mimi.failure_rate()
    late_prob  = float(np.clip(rho_base + rng.normal(0, 0.018), 0.55, 0.98))

    new_rows = pd.DataFrame({
        'ID':                  range(mimi.n_total + 1, mimi.n_total + n + 1),
        'Warehouse_block':     rng.choice(['A','B','C','D','F'], n, p=[0.25,0.20,0.15,0.15,0.25]),
        'Mode_of_Shipment':    rng.choice(['Ship','Flight','Road'], n, p=[0.55,0.33,0.12]),
        'Customer_care_calls': rng.integers(1, 8, n).astype(int),
        'Customer_rating':     rng.integers(1, 6, n).astype(int),
        'Cost_of_the_Product': rng.integers(96, 310, n).astype(int),
        'Prior_purchases':     rng.integers(2, 8, n).astype(int),
        'Product_importance':  rng.choice(['Low','Medium','High'], n, p=[0.60,0.25,0.15]),
        'Gender':              rng.choice(['F','M'], n),
        'Discount_offered':    rng.integers(0, 66, n).astype(int),
        'Weight_in_gms':       rng.integers(1000, 7100, n).astype(int),
        'Reached.on.Time_Y.N': rng.choice([0, 1], n, p=[late_prob, 1.0 - late_prob]).astype(int),
    })

    mimi.df      = pd.concat([mimi.df, new_rows], ignore_index=True)
    mimi.n_total = len(mimi.df)
    mimi.recalculate_lambdas()

    new_rho = mimi.global_rho()
    eff_s, casc_s = _compute_cascade(mimi.hubs)
    diverted      = mimi.diversion_units_calculated(eff_s, casc_s)
    cost_per = _settings_cache.get("cost_per_failure", mimi.LEAKAGE_SEED)
    if diverted > 0:
        # V7 P1: atomic $inc — worker-safe
        _asyncio.create_task(atomic_inc_metrics(diverted, round(diverted * cost_per, 2)))
    _session["refresh_count"] += 1

    metrics = await get_global_metrics()
    return {
        "success":        True,
        "injected":       n,
        "new_n_total":    mimi.n_total,
        "new_rho":        round(new_rho, 4),
        "diverted":       diverted,
        "total_diverted": metrics["diverted_units"],
        "revenue_saved":  metrics["revenue_saved"],
    }


@api_router.post("/kernel/set-mu")
async def set_mu(
    data: MuUpdate,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    require_api_key(api_key)
    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")
    if not (10 <= data.mu <= 1000):
        raise HTTPException(status_code=400, detail="μ must be between 10 and 1000")
    mimi.update_mu(data.mu)
    _session["mu"] = data.mu
    # FIX: persist μ so it survives server restart
    try:
        await settings_col.update_one(
            {"_id": "global"},
            {"$set": {"mu": data.mu, "updated_at": datetime.now(timezone.utc)}},
            upsert=True
        )
    except Exception as e:
        logger.warning(f"μ persist failed (non-fatal): {e}")
    return {"success": True, "mu": data.mu, "new_global_rho": round(mimi.global_rho(), 4)}


# ─── ENTERPRISE INTEGRATION API ──────────────────────────────────────────────

class ShipmentRecord(BaseModel):
    id:                  str
    warehouse_block:     str = "A"
    mode_of_shipment:    str = "Ship"
    weight_gms:          float = 3000
    cost:                float = 200
    product_importance:  str = "Medium"
    customer_care_calls: int = 3

class InterceptPayload(BaseModel):
    shipments: List[ShipmentRecord] = []
    config: dict = {}

@api_router.post("/v1/intercept")
async def intercept_endpoint(
    payload: InterceptPayload,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Enterprise interception endpoint — SAP/Oracle ERP integration.
    ACTUALLY PROCESSES incoming shipment data:
      1. Parses shipment list → derives arrival rate λ
      2. Feeds λ into 2D Kalman per hub
      3. Returns per-hub ρ prediction + DIVERSION_REQUIRED boolean
    Protected: requires X-API-KEY header.
    """
    require_api_key(api_key)
    _session["api_requests"] += 1

    mimi: MIMIKernel = _session["mimi"]
    if mimi is None:
        raise HTTPException(status_code=503, detail="MIMI Kernel not initialized")

    # ── Parse payload & derive λ ──────────────────────────────────────
    shipments    = payload.shipments
    config       = payload.config
    mu_override  = float(config.get("mu", mimi.mu))
    threshold    = float(config.get("threshold", mimi.critical_rho))

    if shipments:
        # Count shipments per block — uses live _all_blocks (dynamic topology)
        block_counts = {b: 0 for b in _all_blocks}
        for s in shipments:
            blk = s.warehouse_block.upper()
            if blk in block_counts:
                block_counts[blk] += 1

        window_hours = max(float(config.get("window_hours", 0.25)), 0.01)

        # Derive λ per hub from live _hub_block_map — works for any number of hubs
        derived_lambdas = {
            hub_name: sum(block_counts.get(b, 0) for b in blocks) / window_hours
            for hub_name, blocks in _hub_block_map.items()
        }

        hub_predictions = []
        for name in list(_hub_block_map.keys()):
            hub       = mimi.hubs[name]
            new_lam   = derived_lambdas[name]
            eff_rho   = new_lam / mu_override if mu_override > 0 else 0
            # Feed real derived ρ into Kalman — this is live payload-driven prediction
            kalman    = hub.kalman_step_2d(float(np.clip(eff_rho, 0.0, 1.5)))
            hub_predictions.append({
                "hub":              name,
                "blocks":            _get_hub_blocks(name),
                "shipments_in_batch": sum(block_counts.get(b, 0) for b in _get_hub_blocks(name)),
                "derived_lambda":   round(new_lam, 2),
                "mu":               round(mu_override, 2),
                "rho_current":      round(eff_rho, 4),
                "rho_t1_15min":     kalman["rho_t1"],
                "rho_t3_45min":     kalman["rho_t3"],
                "rho_dot":          kalman["rho_dot"],
                "diversion_required": eff_rho > threshold,
                "saturation_risk":  kalman["rho_t3"] >= threshold,
            })

        diversion_required = any(h["diversion_required"] for h in hub_predictions)
        highest_rho_hub    = max(hub_predictions, key=lambda h: h["rho_current"])
        n_shipments        = len(shipments)

    else:
        # No shipments in payload — return current network state
        effective, cascade = _compute_cascade(mimi.hubs)
        hub_predictions = [{
            "hub": name, "rho_current": round(effective[name] / mimi.hubs[name].mu, 4),
            "derived_lambda": round(effective[name], 2), "diversion_required": False,
        } for name in list(_hub_block_map.keys()) if name in mimi.hubs]
        diversion_required = mimi.global_rho() > threshold
        highest_rho_hub    = max(hub_predictions, key=lambda h: h["rho_current"])
        n_shipments        = 0

    # Log to MongoDB
    try:
        await api_log_col.insert_one({
            "timestamp":    datetime.now(timezone.utc),
            "endpoint":     "/v1/intercept",
            "n_shipments":  n_shipments,
            "diversion_req": diversion_required,
            "api_key_prefix": api_key[:8] + "..." if api_key else "unknown",
        })
    except Exception as e:
        logger.warning(f"API log persist failed: {e}")

    return {
        "status":              "collapse" if highest_rho_hub["rho_current"] >= 0.85
                               else "critical" if highest_rho_hub["rho_current"] > 0.80
                               else "nominal",
        "shipments_processed": n_shipments,
        "window_hours":        float(config.get("window_hours", 0.25)),
        "hub_predictions":     hub_predictions,
        "network": {
            "diversion_required": diversion_required,
            "recommended_action": "DIVERT" if diversion_required else
                                  "MONITOR" if any(h["saturation_risk"] for h in hub_predictions if "saturation_risk" in h)
                                  else "NOMINAL",
            "worst_hub":          highest_rho_hub["hub"],
            "worst_rho":          highest_rho_hub["rho_current"],
        },
        "kalman_method":       "2D_state_vector_rho_rhodot",
        "traceable_to":        "Wankhede_2026_IEEE_CaseNo02028317",
        "timestamp":           datetime.now(timezone.utc).isoformat(),
    }


@api_router.get("/v1/intercept/schema")
async def intercept_schema():
    return {
        "endpoint":    "/api/v1/intercept",
        "method":      "POST",
        "description": "Real-time shipment interception. Parses incoming data, derives λ, runs 2D Kalman, returns per-hub ρ prediction.",
        "auth":        "X-API-KEY header required",
        "request_schema": {
            "shipments": [{"id": "string", "warehouse_block": "A|B|C|D|F",
                           "mode_of_shipment": "Ship|Flight|Road",
                           "weight_gms": "number", "cost": "number",
                           "product_importance": "Low|Medium|High",
                           "customer_care_calls": "number (1-7)"}],
            "config": {"mu": "number (default: 150)", "threshold": "number (default: 0.85)",
                       "window_hours": "number (default: 0.25 = 15min)"},
        },
        "response_schema": {
            "status": "nominal|critical|collapse",
            "shipments_processed": "number",
            "hub_predictions": [{
                "hub": "string", "rho_current": "number", "rho_t1_15min": "number",
                "rho_t3_45min": "number", "diversion_required": "boolean",
            }],
            "network": {"diversion_required": "boolean", "recommended_action": "NOMINAL|MONITOR|DIVERT"},
        },
        "rate_limit":  "Enterprise Tier SLA - Tiered by API Key",
        "sla":         "P99 < 200ms",
    }


# ─── HUMAN-IN-THE-LOOP DECISION ENDPOINT ─────────────────────────────────────

class DecisionPayload(BaseModel):
    alert_id:    str = ""
    hub:         str
    rho:         float
    action:      str           # "APPROVED" | "DISMISSED"
    directive:   str = ""      # text of the directive that was acted on
    operator_id: str = "ops"   # future: real user identity

@api_router.post("/decisions/log")
async def log_decision(
    payload: DecisionPayload,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Human-in-the-loop audit trail.
    Every APPROVE or DISMISS action is timestamped and written to MongoDB.
    Builds institutional trust — auditors can replay every decision made.
    Protected: requires X-API-KEY header.
    """
    key = require_api_key(api_key)
    require_role(key, {"ADMIN", "OPERATOR"}, "POST /decisions/log")
    ts = datetime.now(timezone.utc)
    doc = {
        "timestamp":   ts,
        "hub":         payload.hub,
        "rho_at_decision": round(payload.rho, 4),
        "action":      payload.action,       # APPROVED or DISMISSED
        "directive":   payload.directive,
        "operator_id": payload.operator_id,
        "alert_id":    payload.alert_id,
        "dataset":     _session.get("dataset_name", "SAFEXPRESS_CASE_02028317"),
    }
    try:
        result = await decisions_col.insert_one(doc)
        inserted_id = str(result.inserted_id)
    except Exception as e:
        logger.error(f"Decision log failed: {e}")
        raise HTTPException(status_code=500, detail="Decision could not be persisted")

    logger.info(f"[DECISION] {payload.action} by {payload.operator_id} on Hub {payload.hub} (ρ={payload.rho:.4f})")
    return {
        "logged":     True,
        "action":     payload.action,
        "hub":        payload.hub,
        "timestamp":  ts.isoformat(),
        "record_id":  inserted_id,
        "message":    f"Decision '{payload.action}' recorded for Hub {payload.hub} at ρ={payload.rho:.4f}",
    }


@api_router.get("/decisions/history")
async def get_decision_history(
    limit: int = 50,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """Return last N human decisions for audit display."""
    require_api_key(api_key)
    try:
        cursor = decisions_col.find(
            {}, {"_id": 0}
        ).sort("timestamp", -1).limit(limit)
        docs = await cursor.to_list(length=limit)
        for d in docs:
            if isinstance(d.get("timestamp"), datetime):
                d["timestamp"] = d["timestamp"].isoformat()
        return {"count": len(docs), "decisions": list(reversed(docs))}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ─── USER SETTINGS / COST CONFIGURATOR ───────────────────────────────────────

class CostSettings(BaseModel):
    cost_per_failure:   float   # ₹ per high-importance delivery failure
    truck_transit_cost: float   # ₹ per unit truck transit/diversion cost

@api_router.get("/settings")
async def get_settings(api_key: str = Header(alias="X-API-KEY", default=None)):
    """Return current cost configuration."""
    require_api_key(api_key)
    return {
        "cost_per_failure":   _settings_cache["cost_per_failure"],
        "truck_transit_cost": _settings_cache["truck_transit_cost"],
        "leakage_seed":       _settings_cache["cost_per_failure"],  # alias for frontend
    }

@api_router.post("/settings")
async def update_settings(
    data: CostSettings,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Update cost parameters — changes take effect immediately.
    The $X.XXM hero metric and revenue_saved calculations use these values
    on the very next /kernel/state call.
    Protected: requires X-API-KEY header.
    """
    require_api_key(api_key)
    if not (0.01 <= data.cost_per_failure <= 10000):
        raise HTTPException(status_code=400, detail="cost_per_failure must be between 0.01 and 10000")
    if not (0.01 <= data.truck_transit_cost <= 10000):
        raise HTTPException(status_code=400, detail="truck_transit_cost must be between 0.01 and 10000")

    _settings_cache["cost_per_failure"]   = data.cost_per_failure
    _settings_cache["truck_transit_cost"] = data.truck_transit_cost

    # Persist to MongoDB so settings survive restarts
    try:
        await settings_col.replace_one(
            {"_id": "global"},
            {"_id": "global", **_settings_cache, "updated_at": datetime.now(timezone.utc)},
            upsert=True
        )
    except Exception as e:
        logger.warning(f"Settings persist failed (non-fatal): {e}")

    # Recompute current annualized exposure with new cost
    mimi = _session.get("mimi")
    new_exposure = mimi.annualized_exposure if mimi else 0

    logger.info(f"[SETTINGS] cost_per_failure={data.cost_per_failure}, truck_transit_cost={data.truck_transit_cost}")
    return {
        "updated":            True,
        "cost_per_failure":   data.cost_per_failure,
        "truck_transit_cost": data.truck_transit_cost,
        "new_annualized_exposure": new_exposure,
        "message":            f"Cost config updated. New annualized exposure: ₹{new_exposure:,.0f}",
    }




@api_router.get("/metrics")
async def get_metrics(api_key: str = Header(alias="X-API-KEY", default=None)):
    """
    V7: Atomic global metrics — consistent across all workers.
    Revenue Saved and Diverted Units read from MongoDB, not RAM.
    """
    require_api_key(api_key)
    m = await get_global_metrics()
    return {
        "diverted_units": m["diverted_units"],
        "revenue_saved":  m["revenue_saved"],
        "source":         "mongodb:global_metrics (atomic)",
        "workers":        "consistent — $inc operations",
    }

# ─── DIAMOND PROTOCOL 3: DYNAMIC TOPOLOGY MANAGEMENT API ─────────────────────

class HubConfig(BaseModel):
    name:   str
    blocks: List[str]
    mu:     float = 150.0
    order:  int   = 99

@api_router.get("/network/hubs")
async def list_hubs(api_key: str = Header(alias="X-API-KEY", default=None)):
    """Return current hub topology from MongoDB network_config."""
    require_api_key(api_key)
    try:
        cursor = network_col.find({}, {"_id": 1, "blocks": 1, "mu": 1, "order": 1})
        docs   = await cursor.to_list(length=50)
        hubs   = [{"name": d["_id"], "blocks": d.get("blocks", []),
                   "mu": d.get("mu", 150.0), "order": d.get("order", 99)} for d in docs]
        hubs.sort(key=lambda h: h["order"])
        return {"hub_count": len(hubs), "hubs": hubs, "source": "mongodb:network_config",
                "live_map": _hub_block_map}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@api_router.post("/network/hubs")
async def add_hub(
    data: HubConfig,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """
    Add or update a hub. Hot-reloads into live kernel immediately.
    If a 4th hub is added here, the dashboard renders it on the next poll.
    """
    key = require_api_key(api_key)
    require_role(key, {"ADMIN", "OPERATOR"}, "POST /network/hubs")
    if not data.name or not data.blocks:
        raise HTTPException(status_code=400, detail="name and blocks are required")
    cleaned_blocks = [b.upper().strip() for b in data.blocks if b.strip()]
    if not cleaned_blocks:
        raise HTTPException(status_code=400, detail="at least one block required")

    doc = {"_id": data.name, "blocks": cleaned_blocks, "mu": data.mu,
           "order": data.order, "created_at": datetime.now(timezone.utc)}
    try:
        await network_col.replace_one({"_id": data.name}, doc, upsert=True)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

    global _hub_block_map, _all_blocks
    _hub_block_map[data.name] = cleaned_blocks
    _all_blocks = sorted(set(b for blocks in _hub_block_map.values() for b in blocks))

    mimi: MIMIKernel = _session.get("mimi")
    if mimi and data.name not in mimi.hubs:
        hub_df = mimi.df[mimi.df['Warehouse_block'].isin(cleaned_blocks)]
        lambda_rate = len(hub_df) / T_OPERATIONAL
        mimi.hubs[data.name] = HubNode(data.name, lambda_rate, data.mu)

    logger.info(f"[TOPOLOGY] Hub '{data.name}' added/updated: blocks={cleaned_blocks}")
    return {"saved": True, "name": data.name, "blocks": cleaned_blocks,
            "mu": data.mu, "effect": "immediate", "hub_count": len(_hub_block_map)}

@api_router.delete("/network/hubs/{hub_name}")
async def delete_hub(
    hub_name: str,
    api_key: str = Header(alias="X-API-KEY", default=None)
):
    """Remove a hub from topology. Minimum 1 hub enforced."""
    key = require_api_key(api_key)
    require_role(key, {"ADMIN"}, "DELETE /network/hubs/{hub_name}")
    if len(_hub_block_map) <= 1:
        raise HTTPException(status_code=400, detail="Cannot delete last hub")
    try:
        await network_col.delete_one({"_id": hub_name})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    global _hub_block_map, _all_blocks
    _hub_block_map.pop(hub_name, None)
    _all_blocks = sorted(set(b for blocks in _hub_block_map.values() for b in blocks))
    mimi = _session.get("mimi")
    if mimi: mimi.hubs.pop(hub_name, None)
    return {"deleted": True, "name": hub_name, "remaining_hubs": list(_hub_block_map.keys())}

# ─── APP SETUP ────────────────────────────────────────────────────────────────

app.include_router(api_router)

# SECURITY: CORS restricted to FRONTEND_URL env var — no wildcard
_allowed_origins = [
    o.strip()
    for o in os.environ.get(
        "FRONTEND_URL",
        "http://localhost:3000,http://localhost:3001"
    ).split(",")
    if o.strip()
]
logger.info(f"CORS allowed origins: {_allowed_origins}")

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=_allowed_origins,
    allow_methods=["GET", "POST", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


@app.on_event("startup")
async def init_kernel():
    import asyncio
    global _buffer_lock

    # Initialise the async lock (must happen inside event loop)
    _buffer_lock = asyncio.Lock()

    # Start background telemetry flush loop
    asyncio.create_task(_telemetry_flush_loop())
    logger.info("Async telemetry buffer started (flush every 8s or 10 docs)")

    # Ensure MongoDB indexes for performance
    try:
        await telemetry_col.create_index([("timestamp", -1)])
        await alerts_col.create_index([("timestamp", -1)])
        await diversion_col.create_index([("timestamp", -1)])
        await api_log_col.create_index([("timestamp", -1)])
        await decisions_col.create_index([("timestamp", -1)])
        await settings_col.create_index([("_id", 1)])
        logger.info("MongoDB indexes created")
    except Exception as e:
        logger.warning(f"Index creation failed (non-fatal): {e}")

    # Load persisted cost settings if they exist
    try:
        saved = await settings_col.find_one({"_id": "global"})
        if saved:
            _settings_cache["cost_per_failure"]   = saved.get("cost_per_failure", 3.94)
            _settings_cache["truck_transit_cost"]  = saved.get("truck_transit_cost", 1.20)
            # FIX: restore μ from MongoDB so restart preserves operator-set throughput
            if saved.get("mu"):
                _session["mu"] = float(saved["mu"])
            logger.info(f"Cost settings loaded: cost_per_failure={_settings_cache['cost_per_failure']} mu={_session['mu']}")
    except Exception as e:
        logger.warning(f"Settings load failed (using defaults): {e}")


    # ── DIAMOND PROTOCOL 3: Load dynamic topology from MongoDB ────────────────
    try:
        cursor    = network_col.find({})
        topo_docs = await cursor.to_list(length=100)
        if topo_docs:
            topo_docs.sort(key=lambda d: d.get("order", 99))
            _hub_block_map.update({d["_id"]: d.get("blocks", []) for d in topo_docs})
            logger.info(f"[TOPOLOGY] Loaded {len(_hub_block_map)} hubs from MongoDB: {list(_hub_block_map.keys())}")
        else:
            for doc in DEFAULT_TOPOLOGY:
                await network_col.replace_one({"_id": doc["_id"]}, doc, upsert=True)
            _hub_block_map.update({d["_id"]: d["blocks"] for d in DEFAULT_TOPOLOGY})
            logger.info(f"[TOPOLOGY] Seeded default topology: {list(_hub_block_map.keys())}")
    except Exception as e:
        logger.warning(f"[TOPOLOGY] Load failed, using defaults: {e}")
        _hub_block_map.update({d["_id"]: d["blocks"] for d in DEFAULT_TOPOLOGY})

    _all_blocks[:] = sorted(set(b for blocks in _hub_block_map.values() for b in blocks))
    logger.info(f"[TOPOLOGY] Active blocks: {_all_blocks}")

    df = build_forensic_baseline()
    _session["mimi"] = MIMIKernel(df)
    _session["mu"]   = 150.0
    logger.info(f"MIMI Kernel v4.0 Diamond-Final initialized: n={len(df)}, ρ={_session['mimi'].global_rho():.4f}")
    for name, hub in _session["mimi"].hubs.items():
        logger.info(f"  Hub {name}: λ={hub.lambda_rate:.1f}/hr  μ={hub.mu:.0f}/hr  ρ={hub.rho:.4f}")

    # V7 PROTOCOL 3: Warm Start — load checkpoint if available
    import time as _startup_time
    t_fit = _startup_time.monotonic()
    loop  = asyncio.get_event_loop()
    await loop.run_in_executor(None, lambda: _session["mimi"].fit_lr(checkpoint=True))
    elapsed_fit = _startup_time.monotonic() - t_fit
    logger.info(f"[WARM START] ρ_c={_session['mimi'].critical_rho:.4f} — ready in {elapsed_fit:.2f}s")

    # ── V7 PROTOCOL 1: Initialise atomic counters — read from global_metrics ────
    try:
        await metrics_col.create_index([("_id", 1)])
        existing = await metrics_col.find_one({"_id": "counters"})
        if existing:
            logger.info(
                f"[ATOMIC] Counters live: "
                f"{int(existing.get('diverted_units',0)):,} units diverted · "
                f"₹{float(existing.get('revenue_saved',0.0)):,.2f} saved"
            )
        else:
            # Migrate: seed from diversion_events aggregate on first V7 run
            pipeline = [{"$group": {"_id": None,
                                    "total_diverted": {"$sum": "$diverted_units"},
                                    "total_revenue":  {"$sum": "$revenue_saved"}}}]
            cursor  = diversion_col.aggregate(pipeline)
            results = await cursor.to_list(length=1)
            seed_units   = int(results[0].get("total_diverted", 0)) if results else 0
            seed_revenue = float(results[0].get("total_revenue", 0.0)) if results else 0.0
            await metrics_col.insert_one({
                "_id": "counters",
                "diverted_units": seed_units,
                "revenue_saved":  seed_revenue,
                "migrated_from":  "diversion_events",
                "last_updated":   datetime.now(timezone.utc),
            })
            logger.info(f"[ATOMIC] Counters seeded from history: {seed_units:,} units · ₹{seed_revenue:,.2f}")
    except Exception as e:
        logger.warning(f"[ATOMIC] Counter init failed: {e}")

    logger.info("V8 ENTERPRISE ACTIVE — Atomic state · Live WhatsApp · Warm start · RBAC · 1k-WPS buffer")
    role_summary = {r: sum(1 for v in _KEY_ROLE_MAP.values() if v == r) for r in _VALID_ROLES if r in _KEY_ROLE_MAP.values()}
    logger.info(f"[RBAC] {len(VALID_API_KEYS)} key(s) active: {role_summary}")
    logger.info(f"CORS: {_allowed_origins}")


@app.on_event("shutdown")
async def shutdown_db_client():
    await _flush_telemetry_buffer()   # drain buffer before disconnect
    client.close()
