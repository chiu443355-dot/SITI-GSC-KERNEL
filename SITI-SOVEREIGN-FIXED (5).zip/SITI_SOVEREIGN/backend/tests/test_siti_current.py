"""
SITI Intelligence — Current Server Test Suite
Tests written against the ACTUAL server.py (v3 MIMI Kernel).
Run: pytest tests/test_siti_current.py -v --tb=short

Requirements: server running at BASE_URL with a valid ADMIN key.
Set environment: export SITI_TEST_KEY=your-admin-key
"""
import os
import requests
import pytest

BASE_URL = os.getenv("SITI_BASE_URL", "http://localhost:8000")
API_KEY  = os.getenv("SITI_TEST_KEY", "siti-admin-key-001")
HEADERS  = {"X-API-KEY": API_KEY}


# ══════════════════════════════════════════════════════
# 1. HEALTH & AUTH
# ══════════════════════════════════════════════════════

class TestHealthAndAuth:
    def test_root_is_public(self):
        r = requests.get(f"{BASE_URL}/api")
        assert r.status_code == 200
        assert "SITI Intelligence" in r.json().get("service", "")

    def test_protected_endpoint_requires_key(self):
        r = requests.get(f"{BASE_URL}/api/kernel/state")
        assert r.status_code in (401, 403), "Should reject without API key"

    def test_invalid_key_rejected(self):
        r = requests.get(f"{BASE_URL}/api/kernel/state",
                         headers={"X-API-KEY": "bad-key-000"})
        assert r.status_code == 403

    def test_valid_key_accepted(self):
        r = requests.get(f"{BASE_URL}/api/kernel/state", headers=HEADERS)
        assert r.status_code == 200

    def test_jwt_login_returns_token(self):
        r = requests.post(f"{BASE_URL}/api/auth/login",
                          json={"api_key": API_KEY})
        assert r.status_code == 200
        data = r.json()
        assert "token" in data
        assert "role" in data
        assert "expires_in" in data
        assert data["expires_in"] == 28800  # 8 hours

    def test_jwt_verify_works(self):
        token = requests.post(f"{BASE_URL}/api/auth/login",
                              json={"api_key": API_KEY}).json()["token"]
        r = requests.post(f"{BASE_URL}/api/auth/verify",
                          headers={"Authorization": f"Bearer {token}"})
        assert r.status_code == 200
        assert r.json()["valid"] is True


# ══════════════════════════════════════════════════════
# 2. KERNEL STATE — field completeness
# ══════════════════════════════════════════════════════

class TestKernelState:
    @pytest.fixture(scope="class")
    def state(self):
        return requests.get(f"{BASE_URL}/api/kernel/state",
                            headers=HEADERS).json()

    def test_top_level_fields(self, state):
        required = [
            "rho", "global_rho", "phi", "wq", "lq", "l",
            "n_total", "failure_rate", "critical_rho", "k_decay",
            "annualized_exposure", "hubs", "kalman", "rho_history",
            "inverse_reliability", "warehouse_metrics", "mode_metrics",
            "routing", "commander_message", "commander_level",
            "rho_t3", "pvi", "pvi_alert", "dataset_name",
        ]
        missing = [f for f in required if f not in state]
        assert not missing, f"Missing top-level fields: {missing}"

    def test_rho_in_range(self, state):
        assert 0.0 <= state["rho"] <= 1.5, f"rho={state['rho']} out of range"

    def test_wq_is_hours_not_dimensionless(self, state):
        """Wq should be a small number in hours, not a large queue length."""
        wq = state["wq"]
        assert isinstance(wq, float)
        # At any reasonable rho, Wq in hours should be < 1hr
        # (rho/(mu*(1-rho)) with mu=150 is always < 1 for rho < 0.99)
        assert wq < 1.0 or wq == 99.9999, f"wq={wq} looks like L not Wq (should be hours)"

    def test_lq_and_l_present(self, state):
        assert "lq" in state, "Lq (mean queue length) missing"
        assert "l"  in state, "L (mean system length) missing"
        # L should always be >= Lq
        if state["rho"] < 1.0:
            assert state["l"] >= state["lq"], "L must be >= Lq (L = Lq + rho)"

    def test_annualized_exposure_positive(self, state):
        exp = state["annualized_exposure"]
        assert isinstance(exp, (int, float))
        assert exp > 0
        assert 100_000 <= exp <= 5_000_000_000, f"Exposure out of sanity range: {exp}"

    def test_n_total_positive(self, state):
        assert state["n_total"] > 0

    def test_hubs_structure(self, state):
        hubs = state["hubs"]
        assert isinstance(hubs, list)
        assert len(hubs) >= 1
        for hub in hubs:
            assert "name" in hub
            assert "rho" in hub
            assert "lambda_rate" in hub
            assert "mu" in hub
            assert 0 <= hub["rho"] <= 1.5

    def test_commander_level_valid(self, state):
        assert state["commander_level"] in ("stable", "critical", "efficiency", "collapse")

    def test_rho_history_structure(self, state):
        hist = state["rho_history"]
        assert isinstance(hist, list)
        if hist:
            entry = hist[-1]
            assert "time" in entry
            assert "rho" in entry
            assert "t1" in entry
            assert "t3" in entry

    def test_pvi_alert_consistent(self, state):
        pvi       = state.get("pvi", 0)
        pvi_alert = state.get("pvi_alert", False)
        if pvi > 15.0:
            assert pvi_alert is True, "pvi_alert should be True when pvi > 15"
        else:
            assert pvi_alert is False, "pvi_alert should be False when pvi <= 15"


# ══════════════════════════════════════════════════════
# 3. IRP — Inverse Reliability Paradox
# ══════════════════════════════════════════════════════

class TestIRP:
    @pytest.fixture(scope="class")
    def irp(self):
        state = requests.get(f"{BASE_URL}/api/kernel/state", headers=HEADERS).json()
        return state["inverse_reliability"]

    def test_irp_required_fields(self, irp):
        required = [
            "failure_count", "total_high", "failure_rate",
            "overall_fail_rate", "irp_gap_pp", "ci_95", "at_risk_flag",
            "leakage_total", "clv_loss", "recovery_value", "records",
        ]
        missing = [f for f in required if f not in irp]
        assert not missing, f"IRP missing fields: {missing}"

    def test_irp_gap_pp_is_real_number(self, irp):
        """irp_gap_pp must be a real computed number, not always 0."""
        gap = irp["irp_gap_pp"]
        assert isinstance(gap, float), f"irp_gap_pp should be float, got {type(gap)}"
        # If gap is exactly 0.0 something is wrong — it would be astronomically
        # unlikely for high-imp failure rate to exactly equal overall rate
        assert gap != 0.0, "irp_gap_pp is 0.0 — likely not being computed"

    def test_ci_95_is_range_string(self, irp):
        ci = irp["ci_95"]
        assert isinstance(ci, str)
        assert "%" in ci
        assert "–" in ci or "-" in ci, f"ci_95 format unexpected: {ci}"

    def test_at_risk_flag_valid(self, irp):
        flag = irp["at_risk_flag"]
        valid = {"RED — Inverse Paradox Active",
                 "AMBER — Elevated High-Value Risk",
                 "GREEN — Within tolerance"}
        assert flag in valid, f"Unexpected at_risk_flag: {flag}"

    def test_failure_rate_in_range(self, irp):
        assert 0.0 <= irp["failure_rate"] <= 1.0
        assert 0.0 <= irp["overall_fail_rate"] <= 1.0

    def test_leakage_uses_cost_not_hardcode(self, irp):
        """leakage_total = failure_count × cost_per_failure (not always × 3.94)."""
        n_fail  = irp["failure_count"]
        leakage = irp["leakage_total"]
        if n_fail > 0:
            implied_cost = leakage / n_fail
            # Should be ~107 (default), not 3.94
            assert implied_cost > 10, f"Implied cost={implied_cost:.2f} — looks like old $3.94 seed"

    def test_records_structure(self, irp):
        records = irp["records"]
        assert isinstance(records, list)
        if records:
            r = records[0]
            assert "id" in r
            assert "hub" in r
            assert "mode" in r


# ══════════════════════════════════════════════════════
# 4. KALMAN FILTER
# ══════════════════════════════════════════════════════

class TestKalman:
    @pytest.fixture(scope="class")
    def kalman(self):
        state = requests.get(f"{BASE_URL}/api/kernel/state", headers=HEADERS).json()
        return state["kalman"]

    def test_kalman_required_fields(self, kalman):
        required = ["x_hat", "rho_dot", "P", "K", "rho_t1", "rho_t3",
                    "pvi", "A", "A3", "saturation_protocol"]
        missing = [f for f in required if f not in kalman]
        assert not missing, f"Kalman missing fields: {missing}"

    def test_rho_t3_in_range(self, kalman):
        assert 0.0 <= kalman["rho_t3"] <= 1.5

    def test_rho_t1_in_range(self, kalman):
        assert 0.0 <= kalman["rho_t1"] <= 1.5

    def test_pvi_non_negative(self, kalman):
        assert kalman["pvi"] >= 0

    def test_A_in_clip_range(self, kalman):
        """A must be clipped to [0.97, 1.06] as per the formula."""
        A = kalman["A"]
        assert 0.97 <= A <= 1.06, f"A={A} outside clip range [0.97, 1.06]"

    def test_A3_equals_A_cubed(self, kalman):
        A  = kalman["A"]
        A3 = kalman["A3"]
        assert abs(A3 - A**3) < 1e-4, f"A3={A3} != A^3={A**3}"

    def test_P_positive(self, kalman):
        """Trace of P covariance should be positive (P is positive definite)."""
        assert kalman["P"] > 0, "Kalman covariance trace should be positive"

    def test_K_is_list_of_two(self, kalman):
        K = kalman["K"]
        assert isinstance(K, list) and len(K) == 2


# ══════════════════════════════════════════════════════
# 5. M/M/1 QUEUE MATH
# ══════════════════════════════════════════════════════

class TestQueueMath:
    @pytest.fixture(scope="class")
    def state(self):
        return requests.get(f"{BASE_URL}/api/kernel/state", headers=HEADERS).json()

    def test_littles_law(self, state):
        """L = λ × W must hold. L = lq + rho (approx for M/M/1)."""
        rho = state["rho"]
        l   = state.get("l", None)
        lq  = state.get("lq", None)
        if l is not None and lq is not None and rho < 1.0:
            # L = Lq + rho (mean in service = rho for M/M/1)
            assert abs((lq + rho) - l) < 0.01, \
                f"Little's law violated: L={l}, Lq+rho={lq+rho:.4f}"

    def test_wq_smaller_than_w(self, state):
        """Wq (wait in queue) must be less than W (time in system)."""
        wq  = state["wq"]
        mu  = state.get("mu", 150.0)
        w   = wq + 1/mu if mu > 0 else wq
        assert wq <= w, "Wq cannot exceed W"

    def test_global_rho_matches_hubs(self, state):
        """Global rho should equal total_lambda / total_mu."""
        hubs = state["hubs"]
        if hubs:
            total_lam = sum(h["lambda_rate"] for h in hubs)
            total_mu  = sum(h["mu"] for h in hubs)
            expected  = total_lam / total_mu if total_mu > 0 else 0
            actual    = state["rho"]
            assert abs(actual - expected) < 0.01, \
                f"Global rho={actual:.4f} != Σλ/Σμ={expected:.4f}"


# ══════════════════════════════════════════════════════
# 6. RATE LIMITING
# ══════════════════════════════════════════════════════

class TestRateLimiting:
    def test_upload_rate_limit_returns_429(self):
        """Upload endpoint should 429 after 10 requests/minute."""
        # Send 12 rapid requests — at least some should hit the limit
        responses = []
        for _ in range(12):
            r = requests.post(
                f"{BASE_URL}/api/kernel/upload",
                headers=HEADERS,
                files={"file": ("test.csv", b"a,b\n1,2", "text/csv")}
            )
            responses.append(r.status_code)
        # At least one should be rate-limited or a valid response
        has_429 = 429 in responses
        has_200_or_400 = any(s in (200, 400) for s in responses)
        assert has_429 or has_200_or_400, f"Unexpected responses: {set(responses)}"

    def test_upload_rejects_oversized_file(self):
        """Files > 50MB must return 413."""
        big = b"a,b\n" + b"1,2\n" * 100  # small test — real 50MB not practical in tests
        r = requests.post(
            f"{BASE_URL}/api/kernel/upload",
            headers=HEADERS,
            files={"file": ("big.csv", big, "text/csv")}
        )
        # Should either succeed (small file) or return 400 (schema mismatch) — not crash
        assert r.status_code in (200, 400, 413), f"Unexpected: {r.status_code}"


# ══════════════════════════════════════════════════════
# 7. SECURITY
# ══════════════════════════════════════════════════════

class TestSecurity:
    def test_razorpay_webhook_requires_secret(self):
        """Webhook should reject if RAZORPAY_WEBHOOK_SECRET not configured."""
        r = requests.post(
            f"{BASE_URL}/api/payments/razorpay-webhook",
            json={"event": "payment.captured", "payload": {}},
            headers={"x-razorpay-signature": "fakesig"}
        )
        # Either 400 (bad sig) or 503 (secret not configured) — never 200
        assert r.status_code in (400, 503), \
            f"Webhook should reject unsigned requests, got {r.status_code}"

    def test_admin_endpoint_requires_admin_role(self):
        """Create-key requires ADMIN role."""
        r = requests.post(
            f"{BASE_URL}/api/admin/create-key",
            headers=HEADERS,
            json={"client_name": "test-client", "role": "READONLY", "notes": "test"}
        )
        # ADMIN key should succeed; non-admin should get 403
        assert r.status_code in (200, 403)

    def test_no_stack_trace_in_error(self):
        """Error responses must not expose internal stack traces."""
        r = requests.get(
            f"{BASE_URL}/api/kernel/state",
            headers={"X-API-KEY": "invalid-key-xyz"}
        )
        body = r.text
        assert "Traceback" not in body, "Stack trace exposed to client"
        assert "File \"" not in body, "Internal path exposed to client"
        assert r.status_code == 403

    def test_cors_null_origin_rejected(self):
        """null origin must not be in CORS allow list."""
        r = requests.get(
            f"{BASE_URL}/api/kernel/state",
            headers={**HEADERS, "Origin": "null"}
        )
        # Server shouldn't echo back 'null' as allowed origin
        cors_header = r.headers.get("Access-Control-Allow-Origin", "")
        assert cors_header != "null", "null origin should not be allowed"
