import React from "react";
import Marquee from "react-fast-marquee";

function SITILogo({ size = 34 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg"
      title="SITI — We control the curve">
      <path d="M 24 7 C 30 7, 30 15, 17 17 C 4 19, 4 27, 10 27"
        stroke="#FFB340" strokeWidth="2.2" strokeLinecap="round" fill="none" />
      <circle cx="24" cy="7" r="2.4" fill="#FFB340" />
      <circle cx="10" cy="27" r="2.4" fill="#FFB340" opacity="0.7" />
      <circle cx="17" cy="17" r="1.2" fill="#FFB34055" />
    </svg>
  );
}

export default function ExecutiveHUD({ kState, ticker, catastrophe, isStreaming, isGhostMode, authStatus }) {
  const networkRho = kState?.rho ?? 0;
  const hubs = kState?.hubs ?? [];

  const criticalHub = hubs.reduce((worst, h) => ((h.rho > (worst?.rho ?? 0)) ? h : worst), null);
  const worstRho = criticalHub?.rho ?? networkRho;
  const worstHubName = criticalHub?.name ?? "";
  const anyHubCritical = worstRho > 0.80;

  const headlineStatus = worstRho >= 0.85
    ? `COLLAPSE: ${worstHubName.toUpperCase()}`
    : worstRho > 0.80
    ? `CRITICAL: ${worstHubName.toUpperCase()}`
    : networkRho > 0.75 ? "WARNING" : "NOMINAL";

  const headlineColor = worstRho > 0.80 ? "#FF3B30" : networkRho > 0.75 ? "#FFB340" : "#32D74B";
  const isPulsing = worstRho > 0.80;

  const tickerItems = [
    { label: "ρ_NET",       value: kState?.global_rho?.toFixed(4) ?? "---",    color: anyHubCritical ? "#FF3B30" : "#FFB340" },
    { label: "Φ(ρ)",        value: kState?.phi?.toFixed(4) ?? "---",            color: "#64D2FF" },
    { label: "T+3 45m",     value: kState?.kalman?.rho_t3?.toFixed(4) ?? "---", color: kState?.collapse_predicted ? "#FF3B30" : "#32D74B" },
    { label: "ρ_DOT",       value: kState?.kalman?.rho_dot?.toFixed(6) ?? "---", color: (kState?.kalman?.rho_dot ?? 0) > 0 ? "#FF9F0A" : "#64D2FF" },
    { label: "W_q",         value: kState?.wq?.toFixed(3) ?? "---",             color: "#64D2FF" },
    { label: "λ_TOT",       value: `${kState?.total_lambda?.toFixed(1) ?? "---"}/hr`, color: "#64D2FF" },
    { label: "μ/HUB",       value: `${kState?.mu?.toFixed(0) ?? "150"}/hr`,     color: "#32D74B" },
    { label: "FAIL",        value: kState?.inverse_reliability?.failure_count?.toLocaleString() ?? "---", color: "#FF9F0A" },
    { label: "HI-IMP",
      value: kState?.inverse_reliability?.failure_rate != null
        ? `${(kState.inverse_reliability.failure_rate * 100).toFixed(1)}%`
        : "---",
      color: "#FF3B30" },
    { label: "SAVED",       value: `₹${ticker?.revenue_saved?.toLocaleString("en-IN", { minimumFractionDigits: 2 }) ?? "0.00"}`, color: "#32D74B" },
    { label: "EXPOSURE",
      value: kState?.annualized_exposure != null
        ? `₹${(kState.annualized_exposure / 1_000_000).toFixed(2)}M`
        : "---",
      color: "#FF3B30" },
    { label: "REC",         value: kState?.n_total?.toLocaleString() ?? "---",  color: "#A1A1AA" },
    { label: "ρ_c",         value: kState?.critical_rho?.toFixed(4) ?? "0.8500", color: "#FF9F0A" },
    { label: "ALERT",       value: kState?.alert?.sent ? `HUB ${(kState?.alert?.hub ?? "").toUpperCase()} #${kState?.alert?.alert_count ?? 0}` : "NOMINAL", color: kState?.alert?.sent ? "#FF6B00" : "#32D74B" },
  ];

  const authColor  = authStatus === "SECURE" ? "#32D74B" : authStatus === "FAILED" ? "#FF3B30" : "#FFB340";
  const authBg     = authStatus === "SECURE" ? "#001A05" : authStatus === "FAILED" ? "#1A0000" : "#0D0D00";
  const authLabel  = authStatus === "SECURE" ? "SECURE" : authStatus === "FAILED" ? "AUTH FAIL" : "CONNECTING";

  return (
    <div data-testid="executive-hud" className="hud-root"
      style={{
        background: "#080808",
        borderBottom: `1px solid ${anyHubCritical ? "#FF3B3066" : "#1F1F1F"}`,
        display: "flex", flexDirection: "column",
        position: "sticky", top: 0, zIndex: 100,
        animation: isPulsing ? "crisis-bg-pulse 1.4s ease-in-out infinite" : "none",
        /* Critical: prevents HUD from causing horizontal page scroll */
        overflow: "hidden",
        maxWidth: "100vw",
      }}>
      <style>{`
        @keyframes crisis-bg-pulse {
          0%   { background-color: #080808; }
          50%  { background-color: #1C0000; }
          100% { background-color: #080808; }
        }

        /* ── HUD header: single row on desktop, two rows on mobile ── */
        .hud-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 8px 16px;
          border-bottom: 1px solid #141414;
          gap: 8px;
          min-width: 0;
        }

        /* Left cluster: logo + title + decorative labels */
        .hud-left {
          display: flex;
          align-items: center;
          gap: 10px;
          min-width: 0;
          flex-shrink: 1;
        }
        .hud-title-block { min-width: 0; }
        .hud-title {
          font-family: Chivo, sans-serif;
          font-weight: 900;
          font-size: 15px;
          color: #FFB340;
          letter-spacing: 0.18em;
          white-space: nowrap;
        }
        .hud-subtitle {
          font-size: 9px;
          color: #555;
          letter-spacing: 0.1em;
          margin-top: 1px;
          white-space: nowrap;
        }
        /* Decorative items — hidden on small phones */
        .hud-divider { width: 1px; height: 28px; background: #1F1F1F; margin: 0 4px; flex-shrink: 0; }
        .hud-case-label { font-size: 9px; letter-spacing: 0.1em; white-space: nowrap; }
        .hud-tagline { font-size: 8px; color: #3A3A3A; letter-spacing: 0.12em; font-style: italic; white-space: nowrap; }

        /* Right cluster: status badges + numbers */
        .hud-right {
          display: flex;
          align-items: center;
          gap: 12px;
          flex-shrink: 0;
          min-width: 0;
        }
        .hud-auth-badge {
          display: flex;
          align-items: center;
          gap: 5px;
          font-family: JetBrains Mono, monospace;
          font-size: 9px;
          font-weight: 700;
          letter-spacing: 0.12em;
          padding: 3px 8px;
          white-space: nowrap;
          border-radius: 2px;
        }
        .hud-auth-dot {
          display: inline-block;
          width: 6px; height: 6px;
          border-radius: 50%;
          flex-shrink: 0;
        }
        .hud-exposure-block { text-align: right; }
        .hud-exposure-label { font-size: 9px; color: #888; letter-spacing: 0.1em; white-space: nowrap; }
        .hud-exposure-value { font-size: 16px; color: #FF3B30; font-weight: 700; letter-spacing: 0.05em; white-space: nowrap; }
        .hud-status-block { text-align: right; }
        .hud-status-label { font-size: 9px; letter-spacing: 0.1em; white-space: nowrap; }
        .hud-status-value { display: flex; align-items: center; gap: 5px; justify-content: flex-end; }

        /* ── MOBILE: ≤600px ─────────────────────────────────── */
        @media (max-width: 600px) {
          .hud-header {
            flex-direction: column;
            align-items: flex-start;
            padding: 6px 10px;
            gap: 5px;
          }
          .hud-left { gap: 8px; }
          /* Hide decorative elements that don't add value on phone */
          .hud-divider, .hud-case-label, .hud-tagline { display: none; }
          .hud-title { font-size: 13px; letter-spacing: 0.12em; }
          .hud-subtitle { display: none; }

          .hud-right {
            width: 100%;
            justify-content: space-between;
            gap: 6px;
          }
          /* Show short auth label on mobile */
          .hud-auth-full  { display: none; }
          .hud-auth-short { display: inline; }

          .hud-exposure-value { font-size: 13px; }
          .hud-exposure-label { font-size: 8px; }
          .hud-status-block { display: none; }  /* status in ticker */
        }

        /* ── DESKTOP: show full text ──────────────────────── */
        @media (min-width: 601px) {
          .hud-auth-short { display: none; }
          .hud-auth-full  { display: inline; }
        }

        /* ── Ticker: ensure it never overflows ──────────────── */
        .hud-ticker-row {
          background: #060606;
          border-top: 1px solid #111;
          padding: 4px 0;
          overflow: hidden;
          max-width: 100%;
        }
        .hud-ticker-item {
          display: flex;
          align-items: center;
          gap: 5px;
          padding: 0 14px;
          white-space: nowrap;
        }
        .hud-ticker-label {
          color: #555;
          font-size: 9px;
          letter-spacing: 0.1em;
          text-transform: uppercase;
        }
        .hud-ticker-value {
          font-size: 11px;
          font-weight: 700;
          letter-spacing: 0.05em;
        }
        .hud-ticker-sep { color: #2A2A2A; font-size: 11px; }

        @media (max-width: 600px) {
          .hud-ticker-item  { padding: 0 10px; }
          .hud-ticker-label { font-size: 8px; }
          .hud-ticker-value { font-size: 10px; }
        }
      `}</style>

      {/* ── HEADER ROW ─────────────────────────────────────────────── */}
      <div className="hud-header">

        {/* LEFT: Logo + title (+ decorative on desktop) */}
        <div className="hud-left">
          <SITILogo size={28} />
          <div className="hud-title-block">
            <div className="hud-title">SITI INTELLIGENCE</div>
            <div className="hud-subtitle">REAL-TIME LEAKAGE DETECTION FOR LOGISTICS</div>
          </div>
          <div className="hud-divider" />
          <div className="hud-case-label">
            <span style={{ color: "#555" }}>CASE </span>
            <span style={{ color: "#64D2FF" }}>#02028317</span>
          </div>
          <div className="hud-divider" />
          <div className="hud-tagline">Stop the leak before it costs you.</div>
        </div>

        {/* RIGHT: Status indicators */}
        <div className="hud-right">

          {/* Auth badge */}
          <div data-testid="secure-connection-badge" className="hud-auth-badge"
            style={{ background: authBg, border: `1px solid ${authColor}`, color: authColor }}>
            <span className="hud-auth-dot"
              style={{ background: authColor, boxShadow: authStatus === "SECURE" ? `0 0 6px ${authColor}` : "none" }} />
            <span className="hud-auth-full">
              {authStatus === "SECURE" ? "SECURE CONNECTION ACTIVE"
               : authStatus === "FAILED" ? "AUTH FAILED — CHECK API KEY"
               : "CONNECTING..."}
            </span>
            <span className="hud-auth-short">{authLabel}</span>
          </div>

          {/* Live inference badge */}
          {(isGhostMode || isStreaming) && (
            <div className="live-inference-badge" data-testid="live-inference-badge"
              style={{ background: "#001A05", border: "1px solid #39FF14", color: "#39FF14",
                fontFamily: "JetBrains Mono", fontSize: 9, fontWeight: 700, letterSpacing: "0.15em",
                padding: "3px 8px", display: "flex", alignItems: "center", gap: 5,
                whiteSpace: "nowrap", borderRadius: 2 }}>
              <span style={{ display: "inline-block", width: 6, height: 6, borderRadius: "50%", background: "#39FF14", flexShrink: 0 }} />
              <span className="hud-auth-full">LIVE INFERENCE</span>
              <span className="hud-auth-short">LIVE</span>
            </div>
          )}

          {/* Annualized exposure */}
          <div className="hud-exposure-block">
            <div className="hud-exposure-label">EXPOSURE</div>
            <div className="hud-exposure-value">
              {kState?.annualized_exposure != null
                ? `₹${Number(kState.annualized_exposure).toLocaleString("en-IN")}`
                : "---"}
            </div>
          </div>

          {/* Hub status — hidden on mobile (visible in ticker) */}
          <div className="hud-status-block">
            <div className="hud-status-label"
              style={{ color: anyHubCritical ? "#FF3B3099" : "#555" }}>
              {anyHubCritical ? "⚠ HUB ALERT" : "HUB STATUS"}
            </div>
            <div className="hud-status-value">
              <span className={`status-dot ${worstRho > 0.80 ? "red" : networkRho > 0.75 ? "amber" : "green"}`} />
              <span style={{
                fontSize: anyHubCritical ? 10 : 12, fontWeight: 700,
                color: headlineColor, letterSpacing: "0.07em", whiteSpace: "nowrap",
                textShadow: isPulsing ? `0 0 10px ${headlineColor}99` : "none",
              }}>
                {headlineStatus}
              </span>
            </div>
            {anyHubCritical && (
              <div style={{ fontSize: 8, color: "#444", letterSpacing: "0.07em", marginTop: 1 }}>
                ρ_avg = {networkRho.toFixed(4)}
              </div>
            )}
          </div>

          {/* Refresh count */}
          <div style={{ textAlign: "right", flexShrink: 0 }}>
            <div style={{ fontSize: 9, color: "#555", letterSpacing: "0.1em" }}>REF</div>
            <div style={{ fontSize: 12, color: "#A1A1AA" }}>#{ticker?.refresh_count ?? 0}</div>
          </div>

        </div>
      </div>

      {/* ── TICKER ROW ─────────────────────────────────────────────── */}
      <div className="hud-ticker-row">
        <Marquee speed={40} gradient={false} pauseOnHover>
          <div style={{ display: "flex", alignItems: "center" }}>
            {tickerItems.map((item, i) => (
              <React.Fragment key={i}>
                <div className="hud-ticker-item">
                  <span className="hud-ticker-label">{item.label}</span>
                  <span className="hud-ticker-value" style={{ color: item.color }}>{item.value}</span>
                </div>
                <span className="hud-ticker-sep">|</span>
              </React.Fragment>
            ))}
          </div>
        </Marquee>
      </div>
    </div>
  );
}
