// v3 — all 9 missing features implemented
import React, { useState, useEffect, useCallback, useRef } from "react";
import axios from "axios";
import Dashboard from "./components/Dashboard";
import LoginScreen from "./components/LoginScreen";
import OnboardingWizard from "./components/OnboardingWizard";
import AdminDashboard from "./components/AdminDashboard";
import ErrorBoundary from "./components/ErrorBoundary";
import DecisionView from "./components/DecisionView";
import "./App.css";

// Guard: fail loudly at startup if the required env var isn't set.
// Without this, API becomes "undefined/api" and every network call fails
// silently with a cryptic CORS or 404 error.
const _BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
if (!_BACKEND_URL) {
  // In development, show a clear error in console and UI
  console.error(
    "[SITI] REACT_APP_BACKEND_URL is not set.\n" +
    "Create a .env file in the frontend/ directory with:\n" +
    "  REACT_APP_BACKEND_URL=http://localhost:8000\n" +
    "Or set it in your Vercel dashboard under Environment Variables."
  );
}
const API = `${_BACKEND_URL || "http://localhost:8000"}/api`;

// SECURITY: No hardcoded fallback key. If REACT_APP_API_KEY is not set in
// your Vercel environment variables, users must log in via the Login screen.
// Never ship a real key baked into the JS bundle — it's visible to anyone in devtools.
const DEFAULT_KEY = process.env.REACT_APP_API_KEY || null;

// ── Auth-aware axios factory (rebuilt on login) ───────────────────────────────
function makeApi(apiKey) {
  return axios.create({
    baseURL: API,
    headers: { "X-API-KEY": apiKey },
  });
}

function App() {
  // ── Auth state ──────────────────────────────────────────────────────────────
  const [session, setSession]     = useState(null);
  const [viewMode, setViewMode]   = useState("decision"); // "decision" | "full" // {token, role, apiKey, mode}
  const [showOnboard, setOnboard] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);

  // Determine active API key: from session or env fallback
  const activeKey = session?.apiKey || DEFAULT_KEY;
  const api       = makeApi(activeKey);

  // ── Kernel state ────────────────────────────────────────────────────────────
  const [kState, setKState]   = useState(null);
  const [ticker, setTicker]   = useState({ total_diverted: 0, revenue_saved: 0, refresh_count: 0 });
  const [loading, setLoading] = useState(true);
  const [authStatus, setAuthStatus]       = useState("CONNECTING");
  const [isCalibrating, setIsCalibrating] = useState(false);
  const [isStreaming, setIsStreaming]     = useState(false);
  const [isGhostMode, setIsGhostMode]    = useState(false);
  const [ghostEndingSoon, setGhostEndingSoon] = useState(false);
  const [ghostComplete, setGhostComplete]     = useState(false);
  const [mu, setMu]         = useState(150);
  const [activeTab, setActiveTab] = useState("network");
  const streamRef     = useRef(null);
  const ghostRef      = useRef(null);
  const ghostCountRef = useRef(0);

  const fetchState = useCallback(async () => {
    const _api = makeApi(activeKey);
    try {
      const [stateRes, tickRes] = await Promise.all([
        _api.get("/kernel/state"),
        _api.post("/kernel/tick"),
      ]);
      const merged = {
        ...stateRes.data,
        total_diverted: tickRes.data.total_diverted,
        revenue_saved:  tickRes.data.revenue_saved,
        refresh_count:  tickRes.data.refresh_count,
        alert_sent:     tickRes.data.alert_sent,
        secure:         true,
      };
      setKState(merged);
      setTicker(tickRes.data);
      if (stateRes.data?.mu) setMu(stateRes.data.mu);
      setAuthStatus("SECURE");
      setLoading(false);
    } catch (e) {
      if (e.response?.status === 401 || e.response?.status === 403) {
        setAuthStatus("FAILED");
      } else {
        console.error("MIMI Kernel fetch error:", e);
      }
      setLoading(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeKey]);

  const handleMuChange = useCallback(async (newMu) => {
    setMu(newMu);
    try {
      await makeApi(activeKey).post("/kernel/set-mu", { mu: newMu });
      await fetchState();
    } catch (e) { console.error("Set mu error:", e); }
  }, [fetchState, activeKey]);

  const startLiveStream = useCallback(async () => {
    setIsStreaming(true);
    const push = async () => {
      try {
        await makeApi(activeKey).post("/kernel/stream-batch?n=100");
        await fetchState();
      } catch (e) { console.error("Stream error:", e); }
    };
    await push();
    streamRef.current = setInterval(push, 10000);
  }, [fetchState, activeKey]);

  const stopLiveStream = useCallback(() => {
    setIsStreaming(false);
    if (streamRef.current) { clearInterval(streamRef.current); streamRef.current = null; }
  }, []);

  const startGhostMode = useCallback(async () => {
    if (streamRef.current) { clearInterval(streamRef.current); streamRef.current = null; setIsStreaming(false); }
    setIsGhostMode(true);
    ghostCountRef.current = 0;
    const push = async () => {
      ghostCountRef.current += 1;
      if (ghostCountRef.current === 80) {
        setGhostEndingSoon(true);
      }
      if (ghostCountRef.current > 90) {
        setIsGhostMode(false);
        setGhostEndingSoon(false);
        setGhostComplete(true);
        setTimeout(() => setGhostComplete(false), 4000);
        if (ghostRef.current) { clearInterval(ghostRef.current); ghostRef.current = null; }
        return;
      }
      try {
        await makeApi(activeKey).post("/kernel/stream-batch?n=50");
        await fetchState();
      } catch (e) { console.error("Ghost trigger error:", e); }
    };
    await push();
    ghostRef.current = setInterval(push, 1000);
  }, [fetchState, activeKey]);

  const stopGhostMode = useCallback(() => {
    setIsGhostMode(false);
    ghostCountRef.current = 0;
    if (ghostRef.current) { clearInterval(ghostRef.current); ghostRef.current = null; }
  }, []);

  useEffect(() => {
    fetchState();
    const id = setInterval(fetchState, 4000);
    return () => clearInterval(id);
  }, [fetchState]);

  useEffect(() => () => {
    if (streamRef.current) clearInterval(streamRef.current);
    if (ghostRef.current)  clearInterval(ghostRef.current);
  }, []);

  // ── Show login if no session and no env key is configured ───────────────────
  // With DEFAULT_KEY=null (no hardcoded fallback), unauthenticated users always
  // see the login screen. If REACT_APP_API_KEY is set in Vercel env vars,
  // it acts as a passthrough key (e.g. for internal/demo deployments).
  const requireLogin = !session && !DEFAULT_KEY;
  if (requireLogin) {
    return (
      <LoginScreen apiBase={API} onLogin={(s) => setSession(s)} />
    );
  }

  return (
    <div className="App">
      {showAdmin && (
        <AdminDashboard
          apiBase={API}
          apiKey={activeKey}
          onClose={() => setShowAdmin(false)}
        />
      )}
      {showOnboard && (
        <OnboardingWizard
          apiBase={API}
          apiKey={activeKey}
          onComplete={() => { setOnboard(false); fetchState(); }}
          onClose={() => setOnboard(false)}
        />
      )}
      <Dashboard
        kState={kState}
        ticker={ticker}
        loading={loading}
        apiBase={API}
        apiKey={activeKey}
        authStatus={authStatus}
        onRefresh={fetchState}
        isCalibrating={isCalibrating}
        setCalibrating={setIsCalibrating}
        isStreaming={isStreaming}
        onStreamStart={startLiveStream}
        onStreamStop={stopLiveStream}
        isGhostMode={isGhostMode}
        ghostEndingSoon={ghostEndingSoon}
        ghostComplete={ghostComplete}
        onGhostStart={startGhostMode}
        onGhostStop={stopGhostMode}
        mu={mu}
        onMuChange={handleMuChange}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        sessionRole={session?.role || "ADMIN"}
        onOpenOnboarding={() => setOnboard(true)}
        onOpenAdmin={() => setShowAdmin(true)}
        onLogout={() => { setSession(null); setKState(null); }}
      />
    </div>
  );
}

export default App;
